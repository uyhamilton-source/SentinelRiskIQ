from collections import defaultdict
from statistics import mean

CRITICALITY_WEIGHT = {"Low": 1.0, "Medium": 1.2, "High": 1.5, "Critical": 2.0}

REMEDIATION_LIBRARY = {
    "PR_MFA": {
        "csf_category": "PR.AA",
        "title": "Implement Multi-Factor Authentication",
        "description": "Enable MFA for all privileged and remote access accounts.",
        "priority": "High",
        "effort": "Medium",
        "timeline": "0-30 days"
    },
    "PR_PATCH": {
        "csf_category": "PR.IP",
        "title": "Establish Patch Management Program",
        "description": "Ensure all systems are updated regularly to reduce vulnerability exposure.",
        "priority": "High",
        "effort": "Medium",
        "timeline": "0-30 days"
    },
    "DE_LOGGING": {
        "csf_category": "DE.CM",
        "title": "Enable Centralized Logging and Monitoring",
        "description": "Integrate systems into SIEM for continuous monitoring.",
        "priority": "Medium",
        "effort": "High",
        "timeline": "30-60 days"
    },
    "RS_PLAN": {
        "csf_category": "RS.RP",
        "title": "Develop Incident Response Plan",
        "description": "Create and test a formal incident response plan.",
        "priority": "High",
        "effort": "Medium",
        "timeline": "0-30 days"
    },
    "RC_BACKUP": {
        "csf_category": "RC.RP",
        "title": "Implement Backup and Recovery Testing",
        "description": "Ensure backups are regularly tested and recoverable.",
        "priority": "Medium",
        "effort": "Medium",
        "timeline": "30-60 days"
    }
}

# HELPERS
# formats the given response to determine if it is true or not (removes whitespace and changes to lowercase)
def yes(value):
    return str(value).strip().lower() == "yes"

# casts the given value into an int (if an error is thrown, return the default value which is 0)
def safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

# CALCULATIONS (specific compliance categories)
def risk_band(score):
    if score >= 85:
        return "Critical"
    if score >= 65:
        return "High"
    if score >= 40:
        return "Medium"
    return "Low"

def score_govern(row):
    score = 0
    if not str(row.get("owner","")).strip():
        score += 15
    if row.get("policy_status", "Not Aligned") != "Aligned":
        score += 10
    if row.get("compliance_status", "Partial") != "Compliant":
        score += 15
    return min(score, 100)

def score_identify(row):
    score = 0
    if row.get("asset_inventory", "No") != "Yes":
        score += 20
    if row.get("classification", "Unknown") == "Unknown":
        score += 15
    return min(score, 100)

def score_protect(row):
    score = 0
    if not yes(row.get("mfa_enabled", "No")):
        score += 20
    if row.get("patch_status", "Unknown") != "Current":
        score += 20
    if yes(row.get("unsupported_os", "No")):
        score += 25
    return min(score, 100)

def score_detect(row):
    score = 0
    if row.get("logging_enabled", "No") != "Yes":
        score += 20
    if row.get("siem_integrated", "No") != "Yes":
        score += 20
    if row.get("monitoring_level", "Low") == "Low":
        score += 15
    return min(score, 100)

def score_respond(row):
    score = 0
    if row.get("incident_response_plan", "No") != "Yes":
        score += 20
    if row.get("response_tested", "No") != "Yes":
        score += 15
    return min(score, 100)

def score_recover(row):
    score = 0
    if row.get("backup_enabled", "No") != "Yes":
        score += 25
    if row.get("recovery_tested", "No") != "Yes":
        score += 15
    return min(score, 100)

# calculates overall risk for the given asset (csf_toolkit)
def calculate_asset_risk(row):
    # calculating vulnerability score (safe_int essentially casts the value into an int before calculating)
    vuln_score = (
        safe_int(row.get("vuln_critical")) * 12
        + safe_int(row.get("vuln_high")) * 7
        + safe_int(row.get("vuln_medium")) * 3
        + safe_int(row.get("vuln_low")) * 1
    )

    # internet_exposed == "yes" ? exposure = 1.4 : exposure = 1.0 (this is essentially what's happening)
    exposure = 1.4 if yes(row.get("internet_exposed", "No")) else 1.0

    # getting the criticality metric based on text value in the .csv file (text) and using the corresponding value from CRITICALITY_WEIGHT object (enum)
    criticality_weight = CRITICALITY_WEIGHT.get(row.get("criticality", "Medium"), 1.2)

    # Calculating different scores for compliance bas
    gv = score_govern(row)
    idf = score_identify(row)
    pr = score_protect(row)
    de = score_detect(row)
    rs = score_respond(row)
    rc = score_recover(row)

    csf_avg = mean([gv, idf, pr, de, rs, rc])
    raw_score = (vuln_score * exposure * criticality_weight) + csf_avg
    final_score = min(round(raw_score, 2), 100) # score can't exceed 100 so take lesser of the two values

    # returning the calculated results for the given row
    return {
        "asset_id": row.get("asset_id", ""),
        "hostname": row.get("hostname", ""),
        "ip_address": row.get("ip_address", ""),
        "business_unit": row.get("business_unit", ""),
        "owner": row.get("owner", ""),
        "criticality": row.get("criticality", ""),
        "internet_exposed": row.get("internet_exposed", ""),
        "risk_score": final_score,
        "risk_band": risk_band(final_score),
        "GV_score": gv,
        "ID_score": idf,
        "PR_score": pr,
        "DE_score": de,
        "RS_score": rs,
        "RC_score": rc,
    }