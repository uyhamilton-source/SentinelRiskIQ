from fastapi import FastAPI, UploadFile, Request
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware
import csv
import io
from collections import defaultdict
from statistics import mean
from datetime import datetime, timezone

from csf_engine import calculate_asset_risk
from compliance_readiness import (
    load_control_intake, 
    prepare_controls, 
    calculate_soc2_readiness, 
    calculate_hipaa_readiness, 
    calculate_combined_readiness
)
from pdf_report import build_pdf

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Risk report and summary generation (Dashboard - csf toolkit implementation)
@app.post("/api/process/toolkit")
async def process_upload(file_upload: UploadFile):
    results = []
    function_scores = defaultdict(list) 
    band_counts = defaultdict(int)      

    raw_data = await file_upload.read()                 # read raw csv data
    csv_file = io.StringIO(raw_data.decode("utf-8"))    # wrapping the string in a file-like object
    reader = csv.DictReader(csv_file)                   # creating DictReader object

    for row in reader:
        result = calculate_asset_risk(row)      # calculating the asset risk for the given row
        results.append(result)                  # appending the single asset risk results to the overall risk results
        band_counts[result["risk_band"]] += 1   # updating the histogram based on the asset's classification (Critical, High, Medium, or Low)

        for func in ["GV", "ID", "PR", "DE", "RS", "RC"]:
            function_scores[func].append(result[f"{func}_score"])
        
    results.sort(key=lambda x: x["risk_score"], reverse=True)

    # creating a summary object for the analysis
    summary = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "total_assets": len(results),
        "risk_band_counts": dict(band_counts),
        "average_scores_by_function": {k: round(mean(v), 2) for k, v in function_scores.items()},
        "top_10_highest_risk_assets": results[:10],
    }

    return {"risk_report": results, "risk_summary": summary }

# Combined intake file processing (risk navigator upgrade)
@app.post("/api/process/navigator")
async def process_combined_upload(file_upload: UploadFile):
    raw_data = await file_upload.read()  # read raw file data
    name = file_upload.filename.lower()

    raw_df = load_control_intake(raw_data, name) # converts raw data into dataframe
    controls_df = prepare_controls(raw_df)

    soc2_readiness = calculate_soc2_readiness(controls_df)
    hipaa_readiness = calculate_hipaa_readiness(controls_df)
    combined_readiness = calculate_combined_readiness(controls_df)
    
    return [ soc2_readiness, hipaa_readiness, combined_readiness, controls_df.to_dict(orient="list") ]

# Executive report generation (risk navigator upgrade)
@app.post("/api/process/report")
async def generate_executive_report(request: Request):
    data = await request.json() # converts data into dictionary
    pdf_bytes = build_pdf(data) # generating pdf bytes

    return Response (
        content=pdf_bytes,
        media_type="application/pdf"
    )