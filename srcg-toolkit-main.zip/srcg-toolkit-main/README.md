# Overview
This is the **RiskNavigator** implementation of the SRCG risk analysis program which allows the user to calculate and obtain the analysis data using the **compliance_readiness** engine. The results are destructured and displayed to the UI in a dashboard overview where three different compliance views can be toggled (SOC2, HIPAA, Combined). This implementation also includes navigation tabs which allows the user to get a more in-depth look at the findings for each view.

## Build Instructions
This project was developed in **VS Code** so I would recommend using the same IDE to keep things consistent. 

### Python Environment Setup
First an foremost, ensure Python is installed on your machine using the `python --version` command.
1. Create virtual environment using command palette in VS Code (open using `CTRL + SHIFT + P`). Search for `"Python:Create Environment"`, select the environment type (venv), and the interpreter which is the latest version of Python you have installed (mine is 3.9.6).
2. Activate your environment using the `.\.venv\Scripts\python.exe` command and refresh the terminal. You should now see **(.venv)** at the start of your command prompt.
3. Now, install all of the Python dependencies for the project using the **requirements.txt** file which can be found in the **\src\backend** folder.
   * Command: `pip install -r \src\backend\requirements.txt`  

### Running the Program
Once the environment is set up, you should be able to run the following commands (in two separate terminals) to start the application.
* Start React/Vite server - `npm run dev`  
* Start FastAPI uvicorn Server - `fastapi dev .\backend\main.py`

#### A Quick Note (Potential Issues)
* `Python Environment Setup:` If the project isn't being build correctly due to having the frontend and backend within the same project folder, you may have to split them into two separate project folders (e.g., one folder for the React portion and another for the Python backend).
* `Installing Dependencies:` When compiling the source code, I was having a little trouble installing the dependencies directly from the requirements file. Some went through while others didn't so I ended up having to do some manually. That may not be the case for you, but it is something to keep in mind!

## Application Component Organization (Frontend)
There is a **Dashboard** component (for the CSF Toolkit implementation) and a **CombinedDashboard** component (for the RiskNavigator implementation) included with the project. If you go to the **App.jsx** file, the CombinedDashboard is what's being shown, but if you also wanted to look at the original dashboard you have that option as well.

### RiskNavigator Implementation
App
* Combined Dashboard
  * FrameworkView (SOC2, HIPAA, Combined)
    * ReadinessMeter
    * Navigation Tabs
      * ExecutiveSummary
      * AreaScores
      * TopActions
      * TopBlockers
      * GapAnalysis
      * FrameworkMapping
      * Remediation
      * ControlDetail
      * Downloads

### CSF Toolkit Implementation
App
* Dashboard

There is also a separate **helpers.js** file located in the `\src\utils\` folder that contains functions that are reused in different components throughout the program.

## API
All files having to do with the Python API are in the `\backend` folder. Some parts of the code pertaining to the engine have been moved to the main routing file for better organization and functionality, but no changes have been made to the original logic.
* `main.py:` FastAPI routing file
* `compliance_readiness.py:` Analysis engine for the **RiskNavigator Upgrade**
* `csf_engine.py:` Analysis engine for the **CSF Toolkit**
* `pdf_report.py:` Generates pdf reports used in **Downloads** tab in the **CombinedDashboard**.