import './App.css'
// import Dashboard from './components/Dashboard'
import CombinedDashboard from './components/CombinedDashboard'

function App() {
  return <CombinedDashboard />
}

export default App
