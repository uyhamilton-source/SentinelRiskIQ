import { useState, useEffect } from "react";
import Card from "./Card";
import ReadinessMeter from "./ReadinessMeter";
import ExecutiveSummary from "./ExecutiveSummary";
import AreaScores from "./AreaScores";
import TopActions from "./TopActions";
import TopBlockers from "./TopBlockers";
import GapAnalysis from "./GapAnalysis";
import FrameworkMapping from "./FrameworkMapping";
import Remediation from "./Remediation";
import ControlDetail from "./ControlDetail";
import Downloads from "./Downloads";

const FrameworkView = ({view = "soc2", data, controls}) => {
    const [activeTab, setActiveTab] = useState("executive-summary");

    const handleTabChange = (e) =>  { // onChange handler - updates active tab
        e.preventDefault();
        document.querySelector(`[value="${activeTab}"]`).classList.remove("active");
        document.querySelector(`[value="${e.target.value}"]`).classList.add("active");
        setActiveTab(e.target.value); 
    }

    useEffect(() => document.querySelector(`[value="${activeTab}"]`).classList.add("active"), []);

  return (
    <>
        <div className="cards">
            <Card title="Overall Score" value={data.overall_score} subtitle="Weighted readiness estimate" />
            <Card title="Readiness Band" value={data.readiness_band} subtitle="Client-friendly maturity label" />
            <Card title="In-Scope Controls" value={data.counts.in_scope} subtitle="Controls marked in scope" />
            <Card title="Priority Gaps" value={data.counts.missing} subtitle="Controls scoring below 50" />
        </div>

        <div>
            <small>Readiness Meter</small>
            <ReadinessMeter readiness={data.overall_score} />
        </div>

        <nav className="tabs">
            <button onClick={handleTabChange} value="executive-summary">Executive Summary</button>
            <button onClick={handleTabChange} value="area-scores">Area Scores</button>
            <button onClick={handleTabChange} value="top-actions">Top Actions</button>
            <button onClick={handleTabChange} value="top-blockers">Top Blockers</button>
            <button onClick={handleTabChange} value="gap-analysis">Gap Analysis</button>
            <button onClick={handleTabChange} value="framework-mapping">Framework Mapping</button>
            <button onClick={handleTabChange} value="remediation">Remediation</button>
            <button onClick={handleTabChange} value="control-detail">Control Detail</button>
            <button onClick={handleTabChange} value="downloads">Downloads</button>
        </nav>

        {activeTab == "executive-summary" && <ExecutiveSummary summary={data.executive_summary} />}
        {activeTab == "area-scores" && <AreaScores scores={data.area_scores}/>}
        {activeTab == "top-actions" && <TopActions actions={data.recommendations}/>}
        {activeTab == "top-blockers" && <TopBlockers blockers={data.top_gaps} />}
        {activeTab == "gap-analysis" && <GapAnalysis gaps={data.gaps}/>}
        {activeTab == "framework-mapping" && <FrameworkMapping gaps={data.gaps} />}
        {activeTab == "remediation" && <Remediation gaps={data.gaps} />}
        {activeTab == "control-detail" && <ControlDetail view={view} controls={controls} />}
        {activeTab == "downloads" && <Downloads view={view} data={data} controls={controls}/>}
    </>
  )
}

export default FrameworkView