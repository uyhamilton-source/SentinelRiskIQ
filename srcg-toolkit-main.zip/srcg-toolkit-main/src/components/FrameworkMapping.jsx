import Table from "./Table";

const FrameworkMapping = ({gaps}) => {
  const headers = ["framework", "control", "design_gap", "citation", "priority"];

  return (
    <>
      <section>
        <h2>Framework Mapping</h2>
        <Table headers={headers} tableData={gaps} />
      </section>
    </>
  )
}

export default FrameworkMapping