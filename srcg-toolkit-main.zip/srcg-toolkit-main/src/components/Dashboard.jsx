import { useState, useEffect } from "react";
import BarChart from "./Bar";
import Table from "./Table";
import { generateBarChartData, calculateHighestAssetScore, calculateCriticalHighAssets } from "../utils/helpers";

const FileForm = () => {
    const [file, setFile] = useState(null);         // stores data for uploaded file
    const [feedback, setFeedback] = useState("");
    const [riskReport, setRiskReport ] = useState(null);
    const [riskSummary, setRiskSummary ] = useState(null);

    // bar graph data
    const [avgScoreData, setAvgScoreData] = useState(null);
    const [riskBandData, setRiskBandData] = useState(null);

    // overview data
    const [critHighCount, setCritHighCount] = useState(0);
    const [highestAssetScore, setHighestAssetScore] = useState(0);

    const handleFileInputChange = (e) => setFile(e.target.files[0]); // onChange handler - updates uploaded file

    // onSubmit handler - processes the given file and return the risk report and summary data
    const handleSubmit = async (e) => {
        e.preventDefault(); // stop page refresh upon submit

        // building FormData object to send to FastAPI; sending as key-value pair, file_upload-file (notice the key matches the parameter name for the API)
        const formData = new FormData();
        formData.append("file_upload", file);

        try {
            const endpoint = "http://localhost:8000/api/process/toolkit"; 

            // making an HTTP request to the FastAPI server endpoint; contains the request type and the payload
            const res = await fetch(endpoint, {
                method: "POST",
                body: formData
            });

            if (res.ok) {
                const data = await res.json();
                setFeedback("File processed successfully");
                setRiskReport(data.risk_report);
                setRiskSummary(data.risk_summary);

                // setting overview data
                setHighestAssetScore(calculateHighestAssetScore(data.risk_report));
                setCritHighCount(calculateCriticalHighAssets(data.risk_report));

                // setting bar graph data
                setAvgScoreData(generateBarChartData(data.risk_summary.average_scores_by_function));
                setRiskBandData(generateBarChartData(data.risk_summary.risk_band_counts));

                // testing
                console.log(data)

            }
            else {
                setFeedback("Failed to process file");
                console.error("Failed to process file");
            }

        } catch (err) {
            console.error(err);
        }
    };

    return (
        <>
            <h1>RiskNavigator Compliance Dashboard</h1>
            <small>Client-ready SOC 2 + HIPAA scoring, blockers, and recommended next actions.</small>

            <div>
                <h2>File Upload</h2>
                <form onSubmit={handleSubmit}>
                    <input type="file" onChange={handleFileInputChange}/>
                    <button type="submit">Process</button>
                </form>

                { file && <small>Loaded Source: {file.name}</small> }  {/* if file is provided and/or updated, display the name */}
                <p>{feedback}</p>
            </div>
            
            
            <div style={{width: "70%", margin: "0 auto"}}>
            { riskSummary && (
                <div style={{display: "flex", flexWrap:"wrap", justifyContent: "space-around", margin: "0 auto", border: "2px black"}}>
                    <h2 style={{flexBasis: "100%"}}>Risk Analysis Summary</h2>
                    <div>
                        <h3>Assets Assessed</h3>
                        <p>{riskSummary.total_assets}</p>
                    </div>
                    <div>
                        <h3>Highest Asset Score</h3>
                        <p>{highestAssetScore}</p>
                    </div>
                    <div>
                        <h3>Critical/High Assets</h3>
                        <p>{critHighCount}</p>
                    </div>
                </div>
            )}

            { riskBandData && (
                <div>
                    <h2>Risk Band Distribution</h2>
                    <BarChart data={riskBandData}/>  {/* if data is provided and/or updated, display it in a bar graph */}
                </div> 
            )}

            { avgScoreData && (
                <div>
                    <h2>Average Score by CSF Function</h2>
                    <BarChart data={avgScoreData}/>  {/* if data is provided and/or updated, display it in a bar graph */}
                </div> 
            )}

            { riskSummary && (
                <>
                    <div>
                        <h2>Top 10 Highest Risk Assets</h2>
                        <Table tableData={riskSummary.top_10_highest_risk_assets}/>
                    </div>

                    <div>
                        <h2>Detailed Findings</h2>
                        <Table headers={Object.keys(riskSummary.top_10_highest_risk_assets[0])} tableData={riskReport}/>
                    </div>
                </>
            )}
            </div>
        
        </>
    )
}

export default FileForm