const Card = ({title, value, subtitle}) => {
  return (
    <div className="card">
        <h2>{title}</h2>
        <p>{value}</p>
        <small>{subtitle}</small>
    </div>
  )
}

export default Card