const Remediation = ({gaps}) => {
  const highItems = gaps.filter(gap => gap.priority == "High");
  const medItems = gaps.filter(gap => gap.priority == "Medium");

  return (
    <>
      <section>
        <h2>Prioritized Remediation Plan</h2>
        <div className="priority-items">

          {/* High Priority */}
          <div>
            <h3>0 - 30 Days</h3>
            <ul>
              {highItems.length != 0 ? (
                highItems.map((item, index) => {
                  return (<li key={index}>Establish and document <span style={{fontWeight: "600"}}>{item.control}</span>  requirements.</li>)
                })
              ) : (<li>No immediate high-priority actions identified.</li>)}
            </ul>
          </div>

          {/* Medium Priority */}
          <div>
            <h3>30 - 60 Days</h3>
            <ul>
              {medItems.length != 0 ? (
                medItems.map((item, index) => {
                  return (<li key={index}>Standardize execution and evidence for <span style={{fontWeight: "600"}}>{item.control}</span>.</li>)
                })
              ) : (<li>Validate evidence and support materials</li>)}
            </ul>
          </div>
          
          {/* Low Priority */}
          <div>
            <h3>60 - 90 Days</h3>
            <ul>
              <li>Confirm operating effectiveness through testing.</li>
              <li>Prepare walkthrough evidence and support materials.</li>
            </ul>
          </div>
        </div>
      </section>
    </>
  )
}

export default Remediation