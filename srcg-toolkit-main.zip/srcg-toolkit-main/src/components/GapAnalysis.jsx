import Table from "./Table";

const GapAnalysis = ({gaps}) => {
  const headers = ["control_id", "framework", "control_area", "control", "design_gap", "implementation_gap"];
  return (
    <>
      <section>
        <h2>Design v. Implementation Gaps</h2>
        <Table headers={headers} tableData={gaps} />
      </section>
      
    </>
  )
}

export default GapAnalysis