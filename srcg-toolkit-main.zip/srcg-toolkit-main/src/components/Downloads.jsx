import { formatEntries, triggerDownload } from "../utils/helpers";
import { Parser } from "@json2csv/plainjs/index.js";

const Downloads = ({view, data, controls}) => {

  const downloadCSV = () => { // onclick handler - converts the controls JSON to CSV and downloads it to the users machine
    const controlsJSON = formatEntries(view, controls);

    try {
      // convert JSON to CSV string and create Blob with converted string
      const parser = new Parser();
      const controlsCSV = parser.parse(controlsJSON);
      const blob = new Blob([controlsCSV], {type: "text/csv;charset=utf-8;"});

      triggerDownload(blob, `${view}_scored_controls.csv`);

    } catch (err) {
      console.error(err)
    }
  };

  const downloadJSON = () => { // onclick handler - downloads readiness JSON to the users machine
    try {
      // convert JS object to JSON string and create Blob with converted string
      const dataStr = JSON.stringify(data, null, 2); 
      const blob = new Blob([dataStr], {type: "application/json"});
      
      triggerDownload(blob, `${view}_readiness_summary.json`);
      
    } catch (err) {
      console.error(err)
    }
  };

  const downloadPDF = async () => { // onclick handler - generates executive report using API and downloads PDF to the users machine
    try {
      // generate executive report using framework data and API
      const endpoint = "http://localhost:8000/api/process/report"; 

      const res = await fetch(endpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
      });

      if (res.ok) {
        // read response as blob and convert into Blob object
        const blobData = await res.blob();
        const blob = new Blob([blobData], {type: "application/pdf"});

        triggerDownload(blob, `${view}_executive_report.pdf`);

      }
    } catch (err) {
      console.error(err)
    }
  };

  return (
    <>
      <section id="downloads">
        <h2>Downloads</h2>
        <div id="download-btns">
          <button onClick={downloadCSV}>Download scored controls CSV</button>
          <button onClick={downloadJSON}>Download readiness JSON</button>
          <button onClick={downloadPDF}>Download executive PDF</button>
        </div>
      </section>
    </>
  )
}

export default Downloads