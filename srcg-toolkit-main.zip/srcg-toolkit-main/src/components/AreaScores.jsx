import { useState, useEffect } from "react";
import { generateBarChartData } from "../utils/helpers";
import BarChart from "./Bar";

const AreaScores = ({scores}) => {
  const [areaScoresData, setAreaScoresData] = useState(null);

  useEffect(() => setAreaScoresData(generateBarChartData(scores)), []);

  return (
    <>
      <section id="area-scores">
        <h2>Area Scores</h2>
          {areaScoresData && 
          <div style={{width:"75%", margin: "0 auto"}}>
            <BarChart data={areaScoresData} />
          </div>}
      </section>
    </>
    
  )
}

export default AreaScores