const Table = ({headers = ["asset_id", "hostname", "business_unit", "criticality", "risk_score", "risk_band"], tableData}) => {
  return (
    <div style={{ overflowX: 'auto' }}>
        <table>
            <thead>
                <tr>
                    {headers.map((header, index) => (
                        <th key={index}>{header}</th>
                    ))}
                </tr>
            </thead>
            <tbody>
                {tableData.map((data, index) => (
                    <tr key={index}>
                        {headers.map((header, asset_index) => (
                            <td key={asset_index}>{data[header]}</td>
                        ))}
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
  )
}

export default Table