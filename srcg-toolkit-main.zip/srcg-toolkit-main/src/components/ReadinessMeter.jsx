const ReadinessMeter = ({readiness}) => {
  return (
    <div id="readiness-container">
        <div id="readiness-fill" style={{width: `${readiness}%`}}></div>
    </div>
  )
}

export default ReadinessMeter