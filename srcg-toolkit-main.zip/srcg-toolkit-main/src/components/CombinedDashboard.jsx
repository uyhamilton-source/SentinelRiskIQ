import { useState } from "react";
import Card from "./Card";
import FrameworkView from "./FrameworkView";

const CombinedDashboard = () => {
    const [file, setFile] = useState(null); // stores data for uploaded file
    const [status, setStatus] = useState("");

    const [controlsData, setControlsData] = useState(null);
    const [analysisData, setAnalysisData] = useState(null);
    const [selectedView, setSelectedView] = useState("soc2");

    const handleViewChange = (e) => setSelectedView(e.target.value);    // onChange handler - updates framework view
    const handleFileInputChange = (e) => setFile(e.target.files[0]);    // onChange handler - updates uploaded file

    // onSubmit handler - processes the given file and returns the soc2, hipaa, and combined framework compliance analyses
    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append("file_upload", file);

        try {
            const endpoint = "http://localhost:8000/api/process/navigator"; 

            const res = await fetch(endpoint, {
                method: "POST",
                body: formData
            });

            if (res.ok) {
                const data = await res.json();
                console.log(data)
                
                setStatus("success");
                setControlsData(data[3])
                setAnalysisData(data.slice(0,3));
            } else setStatus("failure");
        } catch (err) {
            console.error(err);
        }
    };

  return (
    <>
        <aside>
            <h2>Welcome,</h2>
            <small>Upload Control Intake (.xlsx or .csv)</small>

            <div>
                <form onSubmit={handleSubmit}>
                    <input type="file" onChange={handleFileInputChange}/>
                    <button type="submit">Process</button>
                </form>
            </div>
            
            { file && <small>Loaded Source: {file.name}</small> } 
            
            { status == "success" && <div className={status} id="process-feedback">File processed successfully</div> }
            
        </aside>

        <main>
            <div>
                <h1>RiskNavigator™ Compliance Dashboard</h1>
                <small>Client-ready SOC 2 + HIPAA scoring, blockers, and recommended next actions.</small>
            </div>
            
            { analysisData &&
                <>
                    <section>
                        <h2>Overview</h2>
                        
                        <div className="cards">
                            {analysisData.map((entry, index) => {
                                return (<Card key={index} title={entry.framework} value={entry.overall_score} subtitle={entry.readiness_band} />)
                            })}
                        </div>
                        
                        <hr />

                        <form>
                            <h4>Select Framework View:</h4>
                            <label>
                                <input type="radio" name="view" value="soc2" checked={selectedView === "soc2"} onChange={handleViewChange} />
                                SOC 2
                            </label>
                            <label>
                                <input type="radio" name="view" value="hipaa" checked={selectedView === "hipaa"} onChange={handleViewChange} />
                                HIPAA
                            </label>
                            <label>
                                <input type="radio" name="view" value="combined" checked={selectedView === "combined"} onChange={handleViewChange} />
                                Combined
                            </label>
                        </form>
                        
                        {selectedView == "soc2" && <FrameworkView view={selectedView} data={analysisData[0]} controls={controlsData} />}
                        {selectedView == "hipaa" && <FrameworkView view={selectedView} data={analysisData[1]} controls={controlsData} />}
                        {selectedView == "combined" && <FrameworkView view={selectedView} data={analysisData[2]} controls={controlsData} />}
                    </section>
                </>
            }
        </main>

    </>
  )
}

export default CombinedDashboard