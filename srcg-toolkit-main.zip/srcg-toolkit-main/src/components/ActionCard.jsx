const ActionCard = ({order, area, score, priority, recommendation}) => {
  return (
    <div className="action-card">
      <small style={{color: "#9a3412" }}>Decision {order}</small>
      <h3>{area}</h3>
      <small>Current Score: <span>{score}</span> | Priority: <span>{priority}</span></small>
      <p>{recommendation}</p>
    </div>
  )
}

export default ActionCard