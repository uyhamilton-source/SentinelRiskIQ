const ExecutiveSummary = ({summary}) => {
  return (
    <>
      <section id="executive-summary">
        <h2>Executive Summary</h2>
        <small>Generated Summary</small>
        <p>{summary}</p>
      </section>
    </>
  )
}

export default ExecutiveSummary