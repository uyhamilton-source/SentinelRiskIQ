import { useState, useEffect } from "react";
import { formatEntries } from "../utils/helpers";
import Table from "./Table"

const ControlDetail = ({view, controls}) => {
  const [entries, setEntries] = useState([]);

  useEffect(() => setEntries(formatEntries(view, controls)), []);

  return (
    <>
      <section>
        <h2>Scored Control Detail</h2>
        <Table headers={Object.keys(controls)} tableData={entries}/>
      </section>
    </>
  )
}

export default ControlDetail