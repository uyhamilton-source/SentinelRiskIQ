import Table from "./Table";

const TopBlockers = ({blockers}) => {
  return (
    <>
      <section>
        <h2>Top Blockers</h2>
        <Table headers={Object.keys(blockers[0])} tableData={blockers} />
      </section>
    </>
  )
}

export default TopBlockers