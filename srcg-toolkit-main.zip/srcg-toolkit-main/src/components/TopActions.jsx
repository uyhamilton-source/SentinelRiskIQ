import ActionCard from "./ActionCard";

const TopActions = ({actions}) => {
  return (
    <>
      <section id="top-actions">
        <h2>Top Recommended Actions</h2>
        <div className="action-cards">
          {actions.map((action, index) => {
            return (<ActionCard key={index} order={index+1} area={action.area} score={action.score} priority={action.priority} recommendation={action.recommendation} />)
          })}
        </div>
      </section>
    </>
  )
}

export default TopActions