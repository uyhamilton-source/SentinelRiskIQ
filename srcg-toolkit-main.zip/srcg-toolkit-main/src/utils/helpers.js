// formats the given data so that it can be rendered by the BarChart component
export const generateBarChartData = (rawData) => {
    const barChartData = {
        labels: Object.keys(rawData),
        datasets: [
            {
                label: "",
                data: Object.values(rawData),
                backgroundColor: [
                    "rgba(255, 99, 132, 0.2)",
                    "rgba(54, 162, 235, 0.2)",
                    "rgba(255, 206, 86, 0.2)",
                    "rgba(75, 192, 192, 0.2)",
                    "rgba(153, 102, 255, 0.2)",
                    "rgb(253, 158, 69, 0.2)",
                ],
                borderColor: [
                    "rgba(255, 99, 132, 1)",
                    "rgba(54, 162, 235, 1)",
                    "rgba(255, 206, 86, 1)",
                    "rgba(75, 192, 192, 1)",
                    "rgba(153, 102, 255, 1)",
                    "rgb(253, 158, 69, 1)",
                ],
                borderWidth: 1,
            },
        ],
    };

    return barChartData;
};

// determines the highest asset score amongst the given assets
export const calculateHighestAssetScore = (assets) => {
    let max = 0;

    for (const asset of assets) {
        if (asset.risk_score > max) max = asset.risk_score;
    }

    return max;
};

// calculates the occurrences of Critical and High assets
export const calculateCriticalHighAssets = (assets) => {
    let count = 0;

    for (const asset of assets) {
        if (asset.risk_band == "Critical" || asset.risk_band == "High") count++;
    }

    return count;
};

// reformats and filters the controls data depending on current view/framework
export const formatEntries = (view, rawData) => {
    const headers = Object.keys(rawData);
    const rows = rawData[headers[0]].length;
    let formattedRows = [];

    // constructing each entry object and appending the data to the array
    for (let index = 0; index < rows; index++) {
      let rowData = {};
      let data = headers.map((header) => rowData[header] = rawData[header][index]);
      formattedRows.push(rowData); 
    }

    // filter control data in respect to current view/framework
    if (view == "soc2") return formattedRows.filter(row => row.framework == "SOC 2");
    else if (view == "hipaa") return formattedRows.filter(row => row.framework == "HIPAA");
    else return formattedRows;
};

// creates temporary anchor element and triggers download
export const triggerDownload = (blob, fileName) => {
    const url = URL.createObjectURL(blob); // create URL for blob download

    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", fileName);
    link.style.visibility = "hidden";

    // add the link to the document, activate it (click) to trigger download, and remove it from the document (cleanup)
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link);
};