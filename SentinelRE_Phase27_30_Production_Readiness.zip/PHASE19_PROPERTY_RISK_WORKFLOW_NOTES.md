# SentinelRE Phase 19 – Property Risk Engine & Workflow Automation

## Added

### Property Risk Intelligence Engine
- Environmental risk
- Insurance risk
- Vacancy risk
- Tenant concentration risk
- Market risk
- Title/legal risk
- Document completeness risk
- Physical condition risk
- Financing risk
- Compliance risk
- Overall property risk score
- Risk action queue

### Workflow Automation Engine
- Workflow rules
- Workflow tasks
- Workflow event logging
- Closing workflow readiness
- Compliance workflow readiness
- Document workflow readiness
- Investor follow-up workflow readiness

## New Tables
- property_risk_assessment
- property_risk_action
- workflow_rule
- workflow_task
- workflow_event_log

## Included Files
- migrate_phase19_property_risk_workflow.py
- sentinelre_phase19_models.py
- sentinelre_phase19_routes.py
- templates/property_risk_dashboard.html
- templates/property_risk_new.html
- templates/workflows.html

## Deployment
1. Backup database.
2. Run: `python migrate_phase19_property_risk_workflow.py`
3. Merge models/routes into app.py if single-file architecture is used.
4. Restart the app.
