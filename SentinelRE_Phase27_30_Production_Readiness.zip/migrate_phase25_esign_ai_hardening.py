
"""
SentinelRE Phase 25 Migration – E-Signature Legal Hardening & AI Advisor Upgrade
Run from the SentinelRE application folder:
    python migrate_phase25_esign_ai_hardening.py
"""

import sqlite3
from pathlib import Path

db_path = Path("sentinelre.db")
if not db_path.exists():
    if Path("sentinelops.db").exists():
        db_path = Path("sentinelops.db")
    else:
        raise SystemExit("No sentinelre.db or sentinelops.db found.")

conn = sqlite3.connect(db_path)
cur = conn.cursor()

statements = [
"""
CREATE TABLE IF NOT EXISTS signature_certificate (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signature_request_id INTEGER,
    certificate_number VARCHAR(120),
    signer_name VARCHAR(255),
    signer_email VARCHAR(255),
    signed_at DATETIME,
    ip_address VARCHAR(100),
    user_agent TEXT,
    consent_text TEXT,
    document_hash VARCHAR(255),
    signature_hash VARCHAR(255),
    certificate_path VARCHAR(500),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS signature_identity_verification (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signature_request_id INTEGER,
    verification_method VARCHAR(120),
    signer_email VARCHAR(255),
    verification_code VARCHAR(120),
    verified BOOLEAN DEFAULT 0,
    verified_at DATETIME,
    ip_address VARCHAR(100),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS signature_email_delivery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signature_request_id INTEGER,
    recipient_email VARCHAR(255),
    email_subject VARCHAR(255),
    delivery_status VARCHAR(100) DEFAULT 'Queued',
    sent_at DATETIME,
    opened_at DATETIME,
    completed_at DATETIME,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS legal_review_item (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_title VARCHAR(255),
    item_type VARCHAR(120),
    status VARCHAR(100) DEFAULT 'Attorney Review Needed',
    assigned_to VARCHAR(120),
    reviewed_by VARCHAR(120),
    reviewed_at DATETIME,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS ai_advisor_source (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_name VARCHAR(255),
    source_type VARCHAR(120),
    source_table VARCHAR(120),
    source_description TEXT,
    enabled BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS ai_advisor_context_snapshot (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query_id INTEGER,
    snapshot_title VARCHAR(255),
    property_count INTEGER DEFAULT 0,
    open_risk_actions INTEGER DEFAULT 0,
    pending_signatures INTEGER DEFAULT 0,
    open_workflow_tasks INTEGER DEFAULT 0,
    projected_commission FLOAT DEFAULT 0,
    compliance_items_open INTEGER DEFAULT 0,
    snapshot_json TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS ai_advisor_recommendation (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query_id INTEGER,
    recommendation_title VARCHAR(255),
    recommendation_type VARCHAR(120),
    priority VARCHAR(50),
    related_type VARCHAR(120),
    related_id INTEGER,
    recommendation_text TEXT,
    status VARCHAR(100) DEFAULT 'Open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
"""
]

for stmt in statements:
    cur.execute(stmt)

conn.commit()
conn.close()
print(f"Phase 25 E-Signature & AI hardening migration complete: {db_path}")
