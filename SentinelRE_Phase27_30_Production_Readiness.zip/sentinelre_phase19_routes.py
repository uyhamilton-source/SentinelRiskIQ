
# SentinelRE Phase 19 – Property Risk Engine & Workflow Automation Routes

def calculate_property_risk_score(assessment):
    fields = [
        assessment.environmental_risk,
        assessment.insurance_risk,
        assessment.vacancy_risk,
        assessment.tenant_concentration_risk,
        assessment.market_risk,
        assessment.title_legal_risk,
        assessment.document_completeness_risk,
        assessment.physical_condition_risk,
        assessment.financing_risk,
        assessment.compliance_risk,
    ]
    score = sum([float(x or 0) for x in fields]) / len(fields)
    if score >= 75:
        level = "High"
    elif score >= 40:
        level = "Moderate"
    elif score > 0:
        level = "Low"
    else:
        level = "Not Scored"
    return round(score, 2), level


@app.route("/property-risk", methods=["GET"])
@login_required
def property_risk_dashboard():
    assessments = PropertyRiskAssessment.query.order_by(PropertyRiskAssessment.assessed_at.desc()).all()
    actions = PropertyRiskAction.query.filter(PropertyRiskAction.status != "Completed").order_by(PropertyRiskAction.due_date.asc()).all()
    return render_template("property_risk_dashboard.html", assessments=assessments, actions=actions, brand=BRAND)


@app.route("/property-risk/new", methods=["GET", "POST"])
@login_required
def property_risk_new():
    properties = Property.query.order_by(Property.created_at.desc()).all() if "Property" in globals() else []
    if request.method == "POST":
        assessment = PropertyRiskAssessment(
            property_id=int(request.form.get("property_id")),
            assessment_name=request.form.get("assessment_name"),
            environmental_risk=float(request.form.get("environmental_risk") or 0),
            insurance_risk=float(request.form.get("insurance_risk") or 0),
            vacancy_risk=float(request.form.get("vacancy_risk") or 0),
            tenant_concentration_risk=float(request.form.get("tenant_concentration_risk") or 0),
            market_risk=float(request.form.get("market_risk") or 0),
            title_legal_risk=float(request.form.get("title_legal_risk") or 0),
            document_completeness_risk=float(request.form.get("document_completeness_risk") or 0),
            physical_condition_risk=float(request.form.get("physical_condition_risk") or 0),
            financing_risk=float(request.form.get("financing_risk") or 0),
            compliance_risk=float(request.form.get("compliance_risk") or 0),
            executive_summary=request.form.get("executive_summary"),
            recommendations=request.form.get("recommendations"),
            assessed_by=current_user.username
        )
        assessment.overall_risk_score, assessment.risk_level = calculate_property_risk_score(assessment)
        assessment.assessment_status = "Completed"
        db.session.add(assessment)
        db.session.commit()

        if assessment.risk_level in ["High", "Moderate"]:
            action = PropertyRiskAction(
                property_id=assessment.property_id,
                assessment_id=assessment.id,
                action_title=f"Review {assessment.risk_level.lower()} property risk items",
                action_category="Risk Mitigation",
                priority="High" if assessment.risk_level == "High" else "Medium",
                assigned_to=current_user.username,
                notes=assessment.recommendations
            )
            db.session.add(action)
            db.session.commit()

        flash("Property risk assessment completed.")
        return redirect(url_for("property_risk_dashboard"))

    return render_template("property_risk_new.html", properties=properties, brand=BRAND)


@app.route("/workflows", methods=["GET", "POST"])
@login_required
def workflows():
    if request.method == "POST":
        rule = WorkflowRule(
            rule_name=request.form.get("rule_name"),
            workflow_type=request.form.get("workflow_type"),
            trigger_event=request.form.get("trigger_event"),
            condition_field=request.form.get("condition_field"),
            condition_operator=request.form.get("condition_operator"),
            condition_value=request.form.get("condition_value"),
            action_type=request.form.get("action_type"),
            action_owner=request.form.get("action_owner"),
            action_template=request.form.get("action_template"),
            active=True
        )
        db.session.add(rule)
        db.session.commit()
        flash("Workflow rule created.")
        return redirect(url_for("workflows"))

    rules = WorkflowRule.query.order_by(WorkflowRule.created_at.desc()).all()
    tasks = WorkflowTask.query.filter(WorkflowTask.status != "Completed").order_by(WorkflowTask.due_date.asc()).all()
    return render_template("workflows.html", rules=rules, tasks=tasks, brand=BRAND)


@app.route("/workflow-task/<int:task_id>/complete", methods=["POST"])
@login_required
def workflow_task_complete(task_id):
    task = WorkflowTask.query.get_or_404(task_id)
    task.status = "Completed"
    task.completed_at = datetime.utcnow()
    db.session.commit()
    flash("Workflow task completed.")
    return redirect(url_for("workflows"))
