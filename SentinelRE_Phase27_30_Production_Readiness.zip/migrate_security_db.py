"""
SentinelOps™ Security Database Migration
Adds Governance & Security Engine columns/tables to an existing SQLite database.

Run from the SentinelOps project folder:
    python migrate_security_db.py

Optional:
    python migrate_security_db.py --db sentinelops.db
    python migrate_security_db.py --make-admin admin
"""
import argparse
import sqlite3
from pathlib import Path
from datetime import datetime

USER_COLUMNS = {
    "email": "TEXT",
    "role": "TEXT NOT NULL DEFAULT 'Read Only'",
    "active": "BOOLEAN DEFAULT 1",
    "nda_signed": "BOOLEAN DEFAULT 0",
    "ip_agreement_signed": "BOOLEAN DEFAULT 0",
    "security_training_completed": "BOOLEAN DEFAULT 0",
    "access_approved": "BOOLEAN DEFAULT 0",
    "last_login_at": "DATETIME",
    "last_login_ip": "TEXT",
    "created_at": "DATETIME",
}

CREATE_AUDIT_LOG = """
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER NOT NULL PRIMARY KEY,
    timestamp DATETIME,
    user_id INTEGER,
    username VARCHAR(120),
    role VARCHAR(80),
    action VARCHAR(160) NOT NULL,
    object_type VARCHAR(120),
    object_id VARCHAR(120),
    old_value TEXT,
    new_value TEXT,
    ip_address VARCHAR(100),
    result VARCHAR(80) DEFAULT 'Success',
    created_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES user (id)
);
"""

CREATE_CONTRACTOR_AGREEMENT = """
CREATE TABLE IF NOT EXISTS contractor_agreement (
    id INTEGER NOT NULL PRIMARY KEY,
    user_id INTEGER,
    contractor_name VARCHAR(255) NOT NULL,
    contractor_email VARCHAR(255),
    role_requested VARCHAR(80) DEFAULT 'Operations Coordinator',
    nda_signed BOOLEAN DEFAULT 0,
    ip_agreement_signed BOOLEAN DEFAULT 0,
    non_solicitation_acknowledged BOOLEAN DEFAULT 0,
    security_training_completed BOOLEAN DEFAULT 0,
    access_approved BOOLEAN DEFAULT 0,
    approved_by VARCHAR(120),
    signed_date VARCHAR(100),
    notes TEXT,
    created_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES user (id)
);
"""

def table_exists(cur, table_name):
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
    return cur.fetchone() is not None

def columns_for(cur, table_name):
    cur.execute(f"PRAGMA table_info({table_name})")
    return {row[1] for row in cur.fetchall()}

def add_missing_columns(cur, table_name, column_defs):
    existing = columns_for(cur, table_name)
    added = []
    for col, definition in column_defs.items():
        if col not in existing:
            cur.execute(f"ALTER TABLE {table_name} ADD COLUMN {col} {definition}")
            added.append(col)
    return added

def set_defaults(cur):
    now = datetime.utcnow().isoformat(sep=" ", timespec="seconds")
    # Existing users are activated but kept least-privilege unless explicitly promoted.
    updates = [
        ("role", "'Read Only'", "role IS NULL OR role = ''"),
        ("active", "1", "active IS NULL"),
        ("nda_signed", "0", "nda_signed IS NULL"),
        ("ip_agreement_signed", "0", "ip_agreement_signed IS NULL"),
        ("security_training_completed", "0", "security_training_completed IS NULL"),
        ("access_approved", "0", "access_approved IS NULL"),
        ("created_at", f"'{now}'", "created_at IS NULL"),
    ]
    for col, value, condition in updates:
        try:
            cur.execute(f"UPDATE user SET {col} = {value} WHERE {condition}")
        except sqlite3.OperationalError:
            pass


def promote_admin(cur, username):
    cur.execute("""
        UPDATE user
        SET role='Administrator', active=1, nda_signed=1, ip_agreement_signed=1,
            security_training_completed=1, access_approved=1
        WHERE username=?
    """, (username,))
    return cur.rowcount

def seed_audit(cur, message):
    now = datetime.utcnow().isoformat(sep=" ", timespec="seconds")
    cur.execute("""
        INSERT INTO audit_log (timestamp, username, role, action, object_type, result, created_at, new_value)
        VALUES (?, 'system', 'Migration', ?, 'Database', 'Success', ?, ?)
    """, (now, message, now, message))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="sentinelops.db", help="SQLite database path. Default: sentinelops.db")
    parser.add_argument("--make-admin", default=None, help="Optional username to promote to Administrator after migration")
    args = parser.parse_args()

    db_path = Path(args.db).resolve()
    if not db_path.exists():
        raise SystemExit(f"Database not found: {db_path}\nRun this script from the project folder or pass --db path/to/sentinelops.db")

    backup_path = db_path.with_suffix(db_path.suffix + ".backup_before_security_migration")
    if not backup_path.exists():
        backup_path.write_bytes(db_path.read_bytes())
        print(f"Backup created: {backup_path}")
    else:
        print(f"Backup already exists: {backup_path}")

    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    try:
        if not table_exists(cur, "user"):
            raise SystemExit("The database does not contain a 'user' table. Confirm this is the SentinelOps database.")

        added_cols = add_missing_columns(cur, "user", USER_COLUMNS)
        cur.execute(CREATE_AUDIT_LOG)
        cur.execute(CREATE_CONTRACTOR_AGREEMENT)
        set_defaults(cur)

        if args.make_admin:
            changed = promote_admin(cur, args.make_admin)
            if changed:
                print(f"Promoted '{args.make_admin}' to Administrator.")
            else:
                print(f"No user found with username '{args.make_admin}'.")

        seed_audit(cur, "Security database migration completed")
        conn.commit()

        print("Migration complete.")
        print("Added user columns:", ", ".join(added_cols) if added_cols else "None; already present")
        print("Created/verified tables: audit_log, contractor_agreement")
        print("Next step: start Flask and log in as Administrator to review User Management and Audit Logs.")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
