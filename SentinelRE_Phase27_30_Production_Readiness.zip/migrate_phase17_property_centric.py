
import sqlite3
from pathlib import Path

db_path = Path("sentinelre.db")
if not db_path.exists():
    if Path("sentinelops.db").exists():
        db_path = Path("sentinelops.db")
    else:
        raise SystemExit("No sentinelre.db or sentinelops.db found.")

conn = sqlite3.connect(db_path)
cur = conn.cursor()

statements = [
"""
CREATE TABLE IF NOT EXISTS property (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_name VARCHAR(255) NOT NULL,
    property_type VARCHAR(120),
    address VARCHAR(255),
    city VARCHAR(120),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    county VARCHAR(120),
    owner_name VARCHAR(255),
    broker_owner VARCHAR(120),
    assigned_agent VARCHAR(120),
    operations_owner VARCHAR(120),
    square_feet FLOAT,
    units INTEGER,
    acreage FLOAT,
    year_built INTEGER,
    occupancy_rate FLOAT,
    purchase_price FLOAT,
    estimated_value FLOAT,
    noi FLOAT,
    cap_rate FLOAT,
    property_status VARCHAR(100) DEFAULT 'Active',
    risk_score FLOAT DEFAULT 0,
    compliance_score FLOAT DEFAULT 0,
    document_readiness_score FLOAT DEFAULT 0,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS property_transaction (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER,
    transaction_name VARCHAR(255) NOT NULL,
    transaction_type VARCHAR(100),
    stage VARCHAR(100) DEFAULT 'Prospect',
    buyer_name VARCHAR(255),
    seller_name VARCHAR(255),
    tenant_name VARCHAR(255),
    landlord_name VARCHAR(255),
    transaction_value FLOAT,
    commission_estimate FLOAT,
    expected_close_date DATE,
    closing_date DATE,
    compliance_status VARCHAR(100) DEFAULT 'Pending Review',
    document_status VARCHAR(100) DEFAULT 'Incomplete',
    approval_status VARCHAR(100) DEFAULT 'Draft',
    approved_by VARCHAR(120),
    approved_at DATETIME,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS lease_record (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER,
    tenant_name VARCHAR(255),
    lease_type VARCHAR(100),
    lease_status VARCHAR(100) DEFAULT 'Active',
    start_date DATE,
    end_date DATE,
    monthly_rent FLOAT,
    annual_rent FLOAT,
    square_feet_leased FLOAT,
    renewal_option VARCHAR(255),
    expiration_risk VARCHAR(100) DEFAULT 'Normal',
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS investor (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    investor_name VARCHAR(255) NOT NULL,
    entity_name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(80),
    investor_type VARCHAR(120),
    accredited_status VARCHAR(120),
    target_property_type VARCHAR(120),
    target_market VARCHAR(120),
    investment_capacity FLOAT,
    risk_tolerance VARCHAR(100),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS property_investor (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER,
    investor_id INTEGER,
    ownership_percentage FLOAT,
    investment_amount FLOAT,
    role VARCHAR(120),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS property_risk_score (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER,
    environmental_risk FLOAT DEFAULT 0,
    insurance_risk FLOAT DEFAULT 0,
    vacancy_risk FLOAT DEFAULT 0,
    tenant_risk FLOAT DEFAULT 0,
    market_risk FLOAT DEFAULT 0,
    legal_title_risk FLOAT DEFAULT 0,
    document_risk FLOAT DEFAULT 0,
    overall_property_risk FLOAT DEFAULT 0,
    risk_level VARCHAR(50) DEFAULT 'Not Scored',
    recommendations TEXT,
    scored_by VARCHAR(120),
    scored_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS property_compliance_checklist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER,
    licensing_review BOOLEAN DEFAULT 0,
    fair_housing_review BOOLEAN DEFAULT 0,
    aml_review BOOLEAN DEFAULT 0,
    disclosure_review BOOLEAN DEFAULT 0,
    escrow_review BOOLEAN DEFAULT 0,
    title_review BOOLEAN DEFAULT 0,
    inspection_review BOOLEAN DEFAULT 0,
    insurance_review BOOLEAN DEFAULT 0,
    compliance_score FLOAT DEFAULT 0,
    status VARCHAR(100) DEFAULT 'Incomplete',
    reviewed_by VARCHAR(120),
    reviewed_at DATETIME,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
"""
]

for stmt in statements:
    cur.execute(stmt)

conn.commit()
conn.close()
print(f"Phase 17 Property-Centric Data Model migration complete: {db_path}")
