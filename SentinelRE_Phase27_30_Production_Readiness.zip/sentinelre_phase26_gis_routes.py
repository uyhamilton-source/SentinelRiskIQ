
# SentinelRE Phase 26 – Interactive GIS Map Routes

@app.route("/gis-map")
@login_required
def gis_map():
    profiles = PropertyGeoProfile.query.order_by(PropertyGeoProfile.created_at.desc()).all() if "PropertyGeoProfile" in globals() else []
    markers = []
    for p in profiles:
        if p.latitude and p.longitude:
            markers.append({
                "property_id": p.property_id,
                "latitude": p.latitude,
                "longitude": p.longitude,
                "market_area": p.market_area or "",
                "neighborhood": p.neighborhood or "",
                "zoning": p.zoning or "",
                "flood_zone": p.flood_zone or "",
                "opportunity_zone": bool(p.opportunity_zone),
                "walkability_score": p.walkability_score or 0,
                "market_notes": p.market_notes or ""
            })
    return render_template("gis_map.html", markers=markers, brand=BRAND, page_title="Interactive GIS Map")


@app.route("/gis-map-data")
@login_required
def gis_map_data():
    profiles = PropertyGeoProfile.query.order_by(PropertyGeoProfile.created_at.desc()).all() if "PropertyGeoProfile" in globals() else []
    data = []
    for p in profiles:
        if p.latitude and p.longitude:
            data.append({
                "property_id": p.property_id,
                "latitude": p.latitude,
                "longitude": p.longitude,
                "market_area": p.market_area or "",
                "neighborhood": p.neighborhood or "",
                "zoning": p.zoning or "",
                "flood_zone": p.flood_zone or "",
                "opportunity_zone": bool(p.opportunity_zone),
                "walkability_score": p.walkability_score or 0,
                "market_notes": p.market_notes or ""
            })
    return {"markers": data}


@app.route("/gis-overlays", methods=["GET", "POST"])
@login_required
def gis_overlays():
    if request.method == "POST":
        overlay = MarketOverlay(
            overlay_name=request.form.get("overlay_name"),
            overlay_type=request.form.get("overlay_type"),
            market_area=request.form.get("market_area"),
            layer_color=request.form.get("layer_color"),
            risk_level=request.form.get("risk_level"),
            notes=request.form.get("notes"),
            active=True
        )
        db.session.add(overlay)
        db.session.commit()
        flash("Market overlay created.")
        return redirect(url_for("gis_overlays"))

    overlays = MarketOverlay.query.order_by(MarketOverlay.created_at.desc()).all()
    return render_template("gis_overlays.html", overlays=overlays, brand=BRAND, page_title="GIS Overlays")
