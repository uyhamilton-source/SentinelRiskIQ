
# SentinelRE Phase 27-30 Models – Production Readiness

class RouteValidationResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    route_path = db.Column(db.String(255))
    http_status = db.Column(db.Integer)
    validation_status = db.Column(db.String(50))
    validation_notes = db.Column(db.Text)
    tested_at = db.Column(db.DateTime, default=datetime.utcnow)


class LegalTemplateReview(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    template_name = db.Column(db.String(255), nullable=False)
    template_type = db.Column(db.String(120))
    legal_status = db.Column(db.String(100), default="Attorney Review Needed")
    reviewed_by = db.Column(db.String(120))
    reviewed_at = db.Column(db.DateTime)
    approved_for_use = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ESignComplianceControl(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    control_name = db.Column(db.String(255), nullable=False)
    control_area = db.Column(db.String(120))
    requirement_summary = db.Column(db.Text)
    implemented = db.Column(db.Boolean, default=False)
    attorney_review_required = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(100), default="Open")
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PortalMFAChallenge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    portal_user_id = db.Column(db.Integer)
    challenge_type = db.Column(db.String(120), default="Email OTP")
    challenge_code = db.Column(db.String(120))
    expires_at = db.Column(db.DateTime)
    verified = db.Column(db.Boolean, default=False)
    verified_at = db.Column(db.DateTime)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PortalAccessPolicy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    policy_name = db.Column(db.String(255), nullable=False)
    policy_type = db.Column(db.String(120))
    policy_description = db.Column(db.Text)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SecureDocumentToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer)
    portal_user_id = db.Column(db.Integer)
    token = db.Column(db.String(255))
    expires_at = db.Column(db.DateTime)
    used = db.Column(db.Boolean, default=False)
    used_at = db.Column(db.DateTime)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIDataClassificationRule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rule_name = db.Column(db.String(255), nullable=False)
    data_type = db.Column(db.String(120))
    classification = db.Column(db.String(120))
    ai_access_allowed = db.Column(db.Boolean, default=False)
    redaction_required = db.Column(db.Boolean, default=True)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIGovernanceSetting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    setting_name = db.Column(db.String(255), nullable=False)
    setting_value = db.Column(db.String(255))
    setting_description = db.Column(db.Text)
    updated_by = db.Column(db.String(120))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIPromptAuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(120))
    prompt_text = db.Column(db.Text)
    response_summary = db.Column(db.Text)
    data_classification = db.Column(db.String(120))
    blocked = db.Column(db.Boolean, default=False)
    block_reason = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
