
"""
SentinelRE Phase 27 – Automated Deployment & Route Validation Engine

Run from the SentinelRE application folder:
    python sentinelre_setup.py

This script:
- runs all known migrations in safe order
- optionally seeds demo data
- validates major routes using Flask test client
- writes a route validation report
"""

import os
import subprocess
import sys
from pathlib import Path
from datetime import datetime

MIGRATIONS = [
    "migrate_phase6_document_governance.py",
    "migrate_phase7_regulatory_readiness.py",
    "migrate_phase8_9_10.py",
    "migrate_phase17_property_centric.py",
    "migrate_phase18_investor_management.py",
    "migrate_phase19_property_risk_workflow.py",
    "migrate_phase20_client_portal_esign.py",
    "migrate_phase21_24_commission_reporting_gis_ai.py",
    "migrate_phase25_esign_ai_hardening.py",
    "migrate_phase26_interactive_gis.py",
    "migrate_phase27_30_production_readiness.py",
]

ROUTES_TO_TEST = [
    "/dashboard",
    "/demo-dashboard",
    "/properties",
    "/gis-map",
    "/investors",
    "/property-risk",
    "/workflows",
    "/commissions",
    "/signature-requests",
    "/ai-executive-advisor-v2",
    "/aml-governance",
]

def run_script(script):
    if not Path(script).exists():
        return "SKIPPED", f"{script} not found"
    result = subprocess.run([sys.executable, script], capture_output=True, text=True)
    if result.returncode == 0:
        return "PASS", result.stdout.strip()
    return "FAIL", (result.stderr or result.stdout).strip()

def validate_routes():
    from app import app
    results = []
    app.config["TESTING"] = True
    with app.test_client() as client:
        for route in ROUTES_TO_TEST:
            try:
                resp = client.get(route, follow_redirects=False)
                # 200, 302, and 401-style redirects to login are acceptable for protected routes
                status = "PASS" if resp.status_code in [200, 302, 301] else "FAIL"
                results.append((route, status, resp.status_code))
            except Exception as exc:
                results.append((route, "FAIL", str(exc)))
    return results

def main():
    report = []
    report.append(f"SentinelRE Setup Report - {datetime.utcnow().isoformat()} UTC")
    report.append("=" * 72)
    report.append("\nMIGRATIONS")
    for script in MIGRATIONS:
        status, output = run_script(script)
        report.append(f"{script}: {status}")
        if output:
            report.append(f"  {output[:500]}")

    if os.getenv("SEED_DEMO", "true").lower() == "true" and Path("seed_sentinelre_demo.py").exists():
        status, output = run_script("seed_sentinelre_demo.py")
        report.append(f"\nseed_sentinelre_demo.py: {status}")
        if output:
            report.append(f"  {output[:500]}")

    report.append("\nROUTE VALIDATION")
    route_results = validate_routes()
    for route, status, code in route_results:
        report.append(f"{route}: {status} ({code})")

    passed = sum(1 for _, status, _ in route_results if status == "PASS")
    report.append(f"\nRoute Summary: {passed}/{len(route_results)} routes passed")

    output_path = Path("sentinelre_setup_report.txt")
    output_path.write_text("\n".join(report), encoding="utf-8")
    print("\n".join(report))
    print(f"\nReport written to {output_path}")

if __name__ == "__main__":
    main()
