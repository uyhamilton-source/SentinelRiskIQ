
"""
SentinelRE Phase 18 Migration – Investor Management
Run from the SentinelRE application folder:
    python migrate_phase18_investor_management.py
"""

import sqlite3
from pathlib import Path

db_path = Path("sentinelre.db")
if not db_path.exists():
    if Path("sentinelops.db").exists():
        db_path = Path("sentinelops.db")
    else:
        raise SystemExit("No sentinelre.db or sentinelops.db found.")

conn = sqlite3.connect(db_path)
cur = conn.cursor()

statements = [
"""
CREATE TABLE IF NOT EXISTS investor_contact (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    investor_id INTEGER,
    contact_name VARCHAR(255),
    title VARCHAR(120),
    email VARCHAR(255),
    phone VARCHAR(80),
    preferred_contact_method VARCHAR(80),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS investor_interaction (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    investor_id INTEGER,
    interaction_type VARCHAR(120),
    subject VARCHAR(255),
    notes TEXT,
    follow_up_required BOOLEAN DEFAULT 0,
    follow_up_date DATE,
    completed BOOLEAN DEFAULT 0,
    created_by VARCHAR(120),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS investor_preference (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    investor_id INTEGER,
    target_markets TEXT,
    target_property_types TEXT,
    min_investment FLOAT,
    max_investment FLOAT,
    preferred_hold_period VARCHAR(120),
    risk_profile VARCHAR(120),
    return_target VARCHAR(120),
    financing_preference VARCHAR(120),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS investor_opportunity_match (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    investor_id INTEGER,
    property_id INTEGER,
    transaction_id INTEGER,
    match_score FLOAT DEFAULT 0,
    readiness_status VARCHAR(100) DEFAULT 'Review Needed',
    recommended_action VARCHAR(255),
    matched_by VARCHAR(120),
    matched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
)
""",
"""
CREATE TABLE IF NOT EXISTS investor_report (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    investor_id INTEGER,
    property_id INTEGER,
    report_title VARCHAR(255),
    report_type VARCHAR(120),
    report_status VARCHAR(100) DEFAULT 'Draft',
    prepared_by VARCHAR(120),
    approved_by VARCHAR(120),
    approved_at DATETIME,
    file_path VARCHAR(500),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS investor_document (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    investor_id INTEGER,
    property_id INTEGER,
    filename VARCHAR(255),
    document_type VARCHAR(120),
    category VARCHAR(120),
    status VARCHAR(100) DEFAULT 'Uploaded',
    uploaded_by VARCHAR(120),
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    file_path VARCHAR(500),
    notes TEXT
)
"""
]

for stmt in statements:
    cur.execute(stmt)

conn.commit()
conn.close()
print(f"Phase 18 Investor Management migration complete: {db_path}")
