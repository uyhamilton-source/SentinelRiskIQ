SentinelRE™ Flask Starter

What this is
- An internal real estate advisory operations platform for SentinelRE / Sentinel Risk Compliance Group
- Converted from the SentinelRE Flask starter into SentinelRE™
- Supports pipeline tracking, opportunity management, revenue visibility, advisory revenue tracking, and opportunity qualification briefs

Default users
- admin / Admin123!
- advisor / Realtor / Agent123!

Core modules
- Operations Center dashboard
- Pipeline & Client Lifecycle Manager
- Opportunity Qualification Brief
- Branded PDF opportunity brief
- Monthly advisory revenue and salary replacement tracking

Recommended use
- Keep SentinelRE™ as the client-facing Executive Risk Intelligence platform
- Use SentinelRE™ internally to manage leads, discovery calls, proposals, clients, advisory retainers, renewals, and business growth

How to run locally
1. Create a virtual environment
2. Install dependencies:
   pip install -r requirements.txt
3. Start:
   flask --app app run

Initialize database manually if needed
- flask --app app init-db

Production start example
- gunicorn -w 2 -b 0.0.0.0:8000 wsgi:app

Important production notes
- Change SECRET_KEY immediately
- Change default passwords immediately
- Use a managed database for larger deployments
- Put the app behind Nginx or another reverse proxy
- Add CSRF protection, password reset flow, edit/delete records, audit logging, and database migrations before public launch


SentinelRE Opportunity Engine Update
------------------------------------
This build adds a dedicated Opportunity model and Opportunity Management page. Leads remain early-stage records, while Opportunities now track qualified revenue opportunities with service type, stage, proposal status, estimated value, probability, weighted value, expected close date, monthly retainer potential, owner, next step, and notes.

Recommended workflow:
Lead -> Qualified -> Discovery -> Opportunity -> Proposal -> Won Client -> Agent Advisory Retainer -> Renewal.

SentinelRE Proposal Engine Update
----------------------------------
This build adds a branded Proposal Engine for real estate advisory revenue conversion. It includes a Proposal model, proposal management page, opportunity-to-proposal linking, branded PDF proposal generation, proposal status tracking, one-time fee, monthly retainer, first-year value, payment terms, valid-until tracking, and acceptance/signature language.

Recommended workflow:
Lead -> Discovery -> Opportunity -> Proposal -> Client -> Assessment -> Agent Advisory Retainer -> Renewal.


SentinelRE™ Client Lifecycle Manager Update
------------------------------------------
This build adds a complete client lifecycle layer for managing the post-proposal real estate advisory relationship:
- Dedicated Client model
- Client Lifecycle Manager page
- Lead / Opportunity / Proposal linkage
- Proposal-to-client conversion route
- Assessment due date, report due date, roadmap review, advisory session, and renewal tracking
- Monthly retainer and contract value tracking
- Dashboard lifecycle watch table

Lifecycle standard:
Lead -> Discovery -> Snapshot -> Proposal -> Client -> Assessment -> Roadmap -> Agent Advisory -> Renewal

SentinelRE™ Agent Advisory Revenue Tracking Update
--------------------------------------------
This build adds a dedicated Agent Advisory Revenue Tracking module for managing recurring advisory income:
- Agent AdvisoryEngagement model
- Agent Advisory Revenue Tracker page
- Client-to-advisory linkage
- Monthly recurring revenue (MRR) tracking
- Annual recurring revenue (ARR) calculation
- Billing status tracking
- Next invoice, next review, and renewal dates
- Client health status and open action tracking
- Dashboard advisory revenue metrics
- Salary replacement progress from actual advisory revenue

Purpose:
This module separates projected advisory revenue from actual advisory revenue so Sentinel Risk Compliance Group can manage stable monthly income, renewal timing, billing risk, and advisory client health.

Recommended workflow:
Assessment -> Roadmap Review -> Agent Advisory Offer -> Active Retainer -> Monthly/Quarterly Review -> Renewal.


SentinelRE™ Renewal Engine Update
----------------------------------
Added RenewalRecord model and /renewals workflow to manage client retention, advisory renewals, renewal dates, reminder dates, renewal probability, weighted renewal value, renewal risk level, next steps, and expansion opportunities.

Lifecycle now supports:
Lead → Opportunity → Proposal → Client → Agent Advisory → Renewal → Retained Revenue / Expansion

Primary renewal metrics:
- Open Renewals
- Renewal Pipeline Value
- Weighted Renewal Value
- At-Risk Renewals
- Retained MRR
- Open Renewal MRR

SentinelRE™ Activity Tracking + KPI Dashboard Update
-----------------------------------------------------
This build adds the operational visibility layer needed to manage a real estate advisory business.

New capabilities:
- ActivityLog model for calls, emails, LinkedIn activity, discovery meetings, proposal follow-ups, advisory reviews, renewal check-ins, internal notes, and tasks.
- Activity Tracker page at /activities.
- KPI Dashboard at /kpis.
- Activity linkage to leads, opportunities, proposals, clients, and advisory engagements.
- Open follow-up tracking.
- KPI visibility for leads, A-tier leads, opportunities, pipeline value, weighted pipeline, proposal value, advisory MRR/ARR, salary replacement progress, open renewals, activity volume, meetings scheduled, proposal requests, and close rate.
- Dashboard integration for activity and KPI summary metrics.

Purpose:
SentinelRE now supports the operating rhythm of Sentinel Risk Compliance Group by helping track business development activity, client follow-up, revenue health, advisory revenue, renewals, and salary replacement progress.

SentinelRE Revenue Forecast Engine™ Update
------------------------------------------
Added Revenue Forecast Engine™ to project expected revenue from:
- Weighted open opportunities
- Proposal status and one-time fees
- Active advisory monthly recurring revenue
- Renewal probability and renewal value

New outputs include:
- 30-day revenue forecast
- 90-day revenue forecast
- 12-month run-rate forecast
- Projected 90-day MRR
- Projected 90-day ARR
- Projected salary replacement progress
- Projected salary replacement gap

New page:
/forecast

Dashboard and KPI Dashboard now display forecast cards and link to the detailed forecast view.

SentinelRE™ Client Health Engine™ Update
-----------------------------------------
This build adds client health intelligence to help Sentinel Risk Compliance Group protect recurring revenue and identify accounts needing attention.

Added capabilities:
- Client Health Engine™
- Average client health score
- Healthy / Stable / Watchlist / At-Risk classification
- At-risk MRR visibility
- Client health register
- Top client health risks
- Health flags based on billing, advisory status, open actions, renewal risk, review dates, follow-ups, and lifecycle status
- Dashboard integration
- KPI dashboard integration
- Client Health page

Purpose:
The Client Health Engine supports advisory retention, renewal protection, and founder-level visibility into which clients need attention before revenue is lost.


SentinelRE Workflow Automation Engine™
- Converts accepted proposals into client lifecycle records.
- Creates advisory engagement records for clients with monthly retainers.
- Creates renewal records from client/advisory renewal dates.
- Converts A-tier leads into opportunities.
- Creates proposal follow-up and advisory review tasks.
- Includes automation preview, manual run button, dashboard integration, and automation run history.

SentinelRE™ Email Automation Engine
------------------------------------
This build adds a review-first Email Automation Engine for internal business development operations.

Included:
- Discovery invite email drafts for A-tier leads
- Proposal follow-up email drafts for sent proposals
- Agent Advisory review reminder drafts for active advisory clients
- Renewal check-in drafts for open renewal records
- Email queue with mailto launch links
- Mark Sent workflow that logs an Activity record
- Skip workflow for drafts that should not be sent
- Dashboard and navigation integration

Important: This version does not automatically send external email. It creates branded drafts for review to protect sender reputation and allow founder approval before outreach.

SentinelRE Governance & Security Engine™ Update
-------------------------------------------------
This build adds production-readiness protections for remote contractors and VAs:

1. User Roles & Permissions Engine™
   - Owner (Broker)
   - Operations Coordinator
   - Realtor / Agent
   - Read Only
   - Role-based navigation and route-level access checks
   - Least-privilege access model for VA/contractor use

2. Audit Logging Engine™
   - Logs successful logins, failed logins, blocked logins, logouts, permission denials, record creation, email actions, report exports, and contractor agreement records.
   - Admin-only audit log page: /admin/audit-logs

3. Export Restrictions
   - Report exports require export_reports permission.
   - Operations Coordinator and Read Only roles do not receive bulk export permissions.
   - Export attempts are audit logged.

4. NDA/IP Agreement Workflow
   - Admin-only contractor agreement page: /admin/contractor-agreements
   - Tracks NDA signed, IP agreement signed, non-solicitation acknowledgment, security training completed, and access approval.
   - User accounts can be blocked until onboarding is complete.

5. Least-Privilege Access
   - New users should be created with only the role required for their work.
   - Operations Coordinator is recommended for VA use.
   - Owner (Broker) is reserved for Dr. Clarke/system owner.

Important database note:
If you are running this over an old SQLite database, new security columns/tables may not exist. For clean testing, delete the old sentinelops.db file and rerun the app, or perform a proper database migration before production deployment.

SECURITY DATABASE MIGRATION
---------------------------
If you are upgrading from an older SentinelRE database, run:

    python migrate_security_db.py

If your admin username is admin, run:

    python migrate_security_db.py --make-admin admin

This script will:
- Back up sentinelops.db before changes
- Add new User security columns
- Create audit_log table
- Create contractor_agreement table
- Preserve existing CRM, pipeline, proposal, client, advisory, and renewal data

