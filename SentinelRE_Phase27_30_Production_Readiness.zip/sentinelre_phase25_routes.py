
# SentinelRE Phase 25 – E-Signature Legal Hardening & AI Advisor Upgrade Routes

def create_signature_certificate(signature_request):
    import hashlib, uuid
    consent_text = (
        "I consent to use electronic records and electronic signatures. "
        "I understand that typing my name and submitting this form represents my electronic signature."
    )
    cert_number = f"SRE-CERT-{uuid.uuid4().hex[:10].upper()}"
    raw = f"{signature_request.id}|{signature_request.signer_email}|{signature_request.signed_at}|{signature_request.signature_ip}|{signature_request.signature_hash}"
    document_hash = hashlib.sha256(raw.encode()).hexdigest()

    cert = SignatureCertificate(
        signature_request_id=signature_request.id,
        certificate_number=cert_number,
        signer_name=signature_request.signed_by,
        signer_email=signature_request.signer_email,
        signed_at=signature_request.signed_at,
        ip_address=signature_request.signature_ip,
        user_agent=request.headers.get("User-Agent"),
        consent_text=consent_text,
        document_hash=document_hash,
        signature_hash=signature_request.signature_hash
    )
    db.session.add(cert)
    db.session.commit()
    return cert


@app.route("/signature-certificate/<int:signature_id>")
@login_required
def signature_certificate(signature_id):
    req = SignatureRequest.query.get_or_404(signature_id)
    cert = SignatureCertificate.query.filter_by(signature_request_id=signature_id).first()
    logs = SignatureAuditLog.query.filter_by(signature_request_id=signature_id).order_by(SignatureAuditLog.created_at.asc()).all()
    return render_template("signature_certificate.html", req=req, cert=cert, logs=logs, brand=BRAND)


@app.route("/legal-review")
@login_required
def legal_review_queue():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    items = LegalReviewItem.query.order_by(LegalReviewItem.created_at.desc()).all()
    return render_template("legal_review_queue.html", items=items, brand=BRAND)


@app.route("/legal-review/create-defaults", methods=["POST"])
@login_required
def legal_review_create_defaults():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    defaults = [
        ("Attorney review of e-sign consent language", "E-Signature"),
        ("Attorney review of ESIGN/UETA compliance process", "E-Signature"),
        ("Attorney review of real estate contract signature use cases", "Real Estate Legal"),
        ("Attorney review of document retention and audit certificate", "Records Retention"),
        ("Attorney review of identity verification process", "Identity Controls"),
    ]
    for title, item_type in defaults:
        item = LegalReviewItem(item_title=title, item_type=item_type, assigned_to="Broker / Counsel")
        db.session.add(item)
    db.session.commit()
    flash("Legal review checklist created.")
    return redirect(url_for("legal_review_queue"))


@app.route("/signature-email/<int:signature_id>/queue", methods=["POST"])
@login_required
def queue_signature_email(signature_id):
    req = SignatureRequest.query.get_or_404(signature_id)
    delivery = SignatureEmailDelivery(
        signature_request_id=req.id,
        recipient_email=req.signer_email,
        email_subject=f"Signature Requested: {req.document_title}",
        delivery_status="Queued",
        notes="Email delivery foundation created. Connect SMTP/provider before production use."
    )
    db.session.add(delivery)
    db.session.commit()
    flash("Signature email queued. Configure SMTP/provider before sending externally.")
    return redirect(url_for("signature_requests"))


@app.route("/ai-executive-advisor-v2", methods=["GET", "POST"])
@login_required
def ai_executive_advisor_v2():
    response_summary = None
    recommendations = []

    # Gather live platform context where models exist
    property_count = Property.query.count() if "Property" in globals() else 0
    open_risk_actions = PropertyRiskAction.query.filter(PropertyRiskAction.status != "Completed").count() if "PropertyRiskAction" in globals() else 0
    pending_signatures = SignatureRequest.query.filter(SignatureRequest.status != "Signed").count() if "SignatureRequest" in globals() else 0
    open_workflow_tasks = WorkflowTask.query.filter(WorkflowTask.status != "Completed").count() if "WorkflowTask" in globals() else 0
    projected_commission = 0
    if "CommissionRecord" in globals():
        projected_commission = sum([c.gross_commission or 0 for c in CommissionRecord.query.all()])

    if request.method == "POST":
        query_text = request.form.get("query_text")
        q = (query_text or "").lower()

        if "risk" in q:
            response_summary = f"There are {open_risk_actions} open risk actions across {property_count} properties. Prioritize high-risk property actions, document gaps, insurance issues, and title/legal exceptions."
            recommendations.append(("Review High-Risk Properties", "Risk", "High", "Open the Property Risk dashboard and resolve high-priority mitigation tasks."))
        elif "signature" in q or "sign" in q:
            response_summary = f"There are {pending_signatures} pending signature requests. Review unsigned documents and queued email delivery before closing milestones."
            recommendations.append(("Clear Pending Signature Requests", "E-Signature", "High", "Queue reminders for pending signature requests and verify identity controls."))
        elif "workflow" in q or "task" in q:
            response_summary = f"There are {open_workflow_tasks} open workflow tasks. Prioritize tasks tied to closing, probate, investor follow-up, and compliance deadlines."
            recommendations.append(("Prioritize Workflow Queue", "Operations", "Medium", "Assign due dates and owners for open workflow tasks."))
        elif "commission" in q or "revenue" in q:
            response_summary = f"Projected gross commission in the system is approximately ${projected_commission:,.2f}. Review payout status and expected close dates."
            recommendations.append(("Review Commission Forecast", "Revenue", "Medium", "Confirm projected commissions and deal close probabilities."))
        else:
            response_summary = (
                f"Current platform snapshot: {property_count} properties, {open_risk_actions} open risk actions, "
                f"{pending_signatures} pending signatures, {open_workflow_tasks} open workflow tasks, and "
                f"${projected_commission:,.2f} projected gross commission."
            )
            recommendations.append(("Review Executive Dashboard", "Executive", "Medium", "Start with risk, signatures, workflow tasks, and commission forecast."))

        query = AIAdvisorQuery(
            user_name=current_user.username,
            query_text=query_text,
            response_summary=response_summary,
            query_category="Context-Aware Advisor",
            confidence_note="Phase 25 context-aware advisor. It uses live database counts and rule-based reasoning; external LLM integration can be added later."
        )
        db.session.add(query)
        db.session.commit()

        import json
        snapshot = AIAdvisorContextSnapshot(
            query_id=query.id,
            snapshot_title="Live SentinelRE Context Snapshot",
            property_count=property_count,
            open_risk_actions=open_risk_actions,
            pending_signatures=pending_signatures,
            open_workflow_tasks=open_workflow_tasks,
            projected_commission=projected_commission,
            snapshot_json=json.dumps({
                "property_count": property_count,
                "open_risk_actions": open_risk_actions,
                "pending_signatures": pending_signatures,
                "open_workflow_tasks": open_workflow_tasks,
                "projected_commission": projected_commission
            })
        )
        db.session.add(snapshot)

        for title, rtype, priority, text in recommendations:
            rec = AIAdvisorRecommendation(
                query_id=query.id,
                recommendation_title=title,
                recommendation_type=rtype,
                priority=priority,
                recommendation_text=text
            )
            db.session.add(rec)

        db.session.commit()

    recent_queries = AIAdvisorQuery.query.order_by(AIAdvisorQuery.created_at.desc()).limit(10).all()
    recent_recs = AIAdvisorRecommendation.query.order_by(AIAdvisorRecommendation.created_at.desc()).limit(10).all()
    return render_template(
        "ai_executive_advisor_v2.html",
        response_summary=response_summary,
        recent_queries=recent_queries,
        recent_recs=recent_recs,
        property_count=property_count,
        open_risk_actions=open_risk_actions,
        pending_signatures=pending_signatures,
        open_workflow_tasks=open_workflow_tasks,
        projected_commission=projected_commission,
        brand=BRAND
    )
