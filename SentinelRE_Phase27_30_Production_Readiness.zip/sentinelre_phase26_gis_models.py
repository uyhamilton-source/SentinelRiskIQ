
# SentinelRE Phase 26 – Interactive GIS Map Models

class MapView(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    view_name = db.Column(db.String(255), nullable=False)
    view_type = db.Column(db.String(120))
    default_latitude = db.Column(db.Float, default=26.1224)
    default_longitude = db.Column(db.Float, default=-80.1373)
    default_zoom = db.Column(db.Integer, default=10)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MapMarkerNote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer)
    marker_type = db.Column(db.String(120))
    note_title = db.Column(db.String(255))
    note_text = db.Column(db.Text)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MarketOverlay(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    overlay_name = db.Column(db.String(255), nullable=False)
    overlay_type = db.Column(db.String(120))
    market_area = db.Column(db.String(255))
    layer_color = db.Column(db.String(50))
    risk_level = db.Column(db.String(50))
    notes = db.Column(db.Text)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
