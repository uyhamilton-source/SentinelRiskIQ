"""
SentinelRE Phase 6 - Document Governance Engine migration.
Run from the SentinelRE app directory:
    python migrate_phase6_documents.py
"""
from app import app, db, DocumentCategory, DOCUMENT_CATEGORIES

with app.app_context():
    db.create_all()
    for name in DOCUMENT_CATEGORIES:
        existing = DocumentCategory.query.filter_by(name=name).first()
        if not existing:
            db.session.add(DocumentCategory(name=name, description=f"{name} document category"))
    db.session.commit()
    print("SentinelRE Phase 6 Document Governance Engine migration complete.")
