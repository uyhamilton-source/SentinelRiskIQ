
# SentinelRE Phase 20 – Client Portal & E-Signature Models

class PortalUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(255))
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(80), default="Client")
    client_name = db.Column(db.String(255))
    investor_id = db.Column(db.Integer)
    property_id = db.Column(db.Integer)
    active = db.Column(db.Boolean, default=True)
    access_approved = db.Column(db.Boolean, default=False)
    last_login_at = db.Column(db.DateTime)
    last_login_ip = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class PortalMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    portal_user_id = db.Column(db.Integer, db.ForeignKey("portal_user.id"))
    sender = db.Column(db.String(120))
    subject = db.Column(db.String(255))
    message = db.Column(db.Text)
    status = db.Column(db.String(100), default="Unread")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PortalAccessLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    portal_user_id = db.Column(db.Integer, db.ForeignKey("portal_user.id"))
    event_type = db.Column(db.String(120))
    event_details = db.Column(db.Text)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SignatureRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    signer_name = db.Column(db.String(255))
    signer_email = db.Column(db.String(255))
    document_title = db.Column(db.String(255))
    document_type = db.Column(db.String(120))
    file_path = db.Column(db.String(500))
    status = db.Column(db.String(100), default="Pending Signature")
    requested_by = db.Column(db.String(120))
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    signed_by = db.Column(db.String(255))
    signed_at = db.Column(db.DateTime)
    signature_text = db.Column(db.String(255))
    signature_ip = db.Column(db.String(100))
    signature_hash = db.Column(db.String(255))
    notes = db.Column(db.Text)


class SignatureAuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signature_request_id = db.Column(db.Integer, db.ForeignKey("signature_request.id"))
    event_type = db.Column(db.String(120))
    event_details = db.Column(db.Text)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
