
"""
SentinelRE Demo Seed Script
Creates a clean demo database with sample brokers, agents, properties,
investors, documents, transactions, risk records, workflow tasks,
commission records, and reports.

Run from the SentinelRE application folder:
    python seed_sentinelre_demo.py
"""

from datetime import datetime, date, timedelta
from werkzeug.security import generate_password_hash
from app import app, db

with app.app_context():
    db.create_all()

    # Helper: get model safely from app globals
    import app as appmod

    User = getattr(appmod, "User", None)
    Property = getattr(appmod, "Property", None)
    PropertyTransaction = getattr(appmod, "PropertyTransaction", None)
    LeaseRecord = getattr(appmod, "LeaseRecord", None)
    Investor = getattr(appmod, "Investor", None)
    PropertyInvestor = getattr(appmod, "PropertyInvestor", None)
    PropertyRiskAssessment = getattr(appmod, "PropertyRiskAssessment", None)
    PropertyRiskAction = getattr(appmod, "PropertyRiskAction", None)
    WorkflowTask = getattr(appmod, "WorkflowTask", None)
    CommissionRecord = getattr(appmod, "CommissionRecord", None)
    RealEstateReport = getattr(appmod, "RealEstateReport", None)
    PropertyGeoProfile = getattr(appmod, "PropertyGeoProfile", None)
    AIAdvisorInsight = getattr(appmod, "AIAdvisorInsight", None)

    # Avoid duplicate seeding
    if Property and Property.query.first():
        print("Demo data already appears to exist. No new demo records created.")
        raise SystemExit(0)

    # Users
    if User:
        demo_users = [
            ("broker_owner", "broker@sentinelre-demo.com", "Owner/Broker", "BrokerDemo2026!"),
            ("ops_coordinator", "ops@sentinelre-demo.com", "Operations Coordinator", "OpsDemo2026!"),
            ("agent_mia", "mia.agent@sentinelre-demo.com", "Realtor/Agent", "AgentDemo2026!"),
            ("agent_carlos", "carlos.agent@sentinelre-demo.com", "Realtor/Agent", "AgentDemo2026!"),
            ("readonly_demo", "readonly@sentinelre-demo.com", "Read Only", "ReadOnly2026!")
        ]
        for username, email, role, password in demo_users:
            if not User.query.filter_by(username=username).first():
                u = User(username=username, email=email, role=role, active=True)
                if hasattr(u, "access_approved"):
                    u.access_approved = True
                if hasattr(u, "nda_signed"):
                    u.nda_signed = True
                if hasattr(u, "ip_agreement_signed"):
                    u.ip_agreement_signed = True
                if hasattr(u, "security_training_completed"):
                    u.security_training_completed = True
                if hasattr(u, "set_password"):
                    u.set_password(password)
                else:
                    u.password_hash = generate_password_hash(password)
                db.session.add(u)
        db.session.commit()

    # Properties
    property_records = []
    if Property:
        samples = [
            dict(property_name="Harbor Pointe Retail Center", property_type="Retail", address="2450 Harbor Pointe Blvd", city="Fort Lauderdale", state="FL", zip_code="33316", county="Broward", owner_name="Harbor Pointe Holdings LLC", broker_owner="broker_owner", assigned_agent="agent_mia", operations_owner="ops_coordinator", square_feet=48500, units=18, year_built=2009, occupancy_rate=92, purchase_price=8650000, estimated_value=9400000, noi=705000, cap_rate=7.5, risk_score=42, compliance_score=84, document_readiness_score=78, notes="Strong neighborhood retail asset with lease rollover risk in 18 months."),
            dict(property_name="Cypress Creek Office Plaza", property_type="Commercial Office", address="6100 Cypress Creek Rd", city="Fort Lauderdale", state="FL", zip_code="33309", county="Broward", owner_name="Cypress Professional Partners", broker_owner="broker_owner", assigned_agent="agent_carlos", operations_owner="ops_coordinator", square_feet=124000, units=42, year_built=1998, occupancy_rate=76, purchase_price=14250000, estimated_value=15100000, noi=980000, cap_rate=6.49, risk_score=61, compliance_score=73, document_readiness_score=66, notes="Office repositioning candidate with moderate vacancy and insurance review needed."),
            dict(property_name="Vero Logistics Park", property_type="Industrial", address="900 Aviation Blvd", city="Vero Beach", state="FL", zip_code="32960", county="Indian River", owner_name="Vero Industrial Group", broker_owner="broker_owner", assigned_agent="agent_mia", operations_owner="ops_coordinator", square_feet=210000, units=6, year_built=2018, occupancy_rate=100, purchase_price=28500000, estimated_value=30250000, noi=2100000, cap_rate=6.94, risk_score=28, compliance_score=91, document_readiness_score=88, notes="Stabilized industrial asset with strong tenant profile."),
            dict(property_name="Probate Estate Duplex Portfolio", property_type="Probate Property", address="Multiple Addresses", city="Hollywood", state="FL", zip_code="33020", county="Broward", owner_name="Estate of R. Thompson", broker_owner="broker_owner", assigned_agent="agent_carlos", operations_owner="ops_coordinator", square_feet=9800, units=8, year_built=1974, occupancy_rate=75, purchase_price=1850000, estimated_value=2200000, noi=132000, cap_rate=6.0, risk_score=68, compliance_score=62, document_readiness_score=51, notes="Probate sale requires court filing, title review, beneficiary communication, and document cleanup.")
        ]
        for data in samples:
            p = Property(**data)
            db.session.add(p)
            property_records.append(p)
        db.session.commit()

    # Transactions
    if PropertyTransaction and property_records:
        txs = [
            dict(property_id=property_records[0].id, transaction_name="Harbor Pointe Sale Advisory", transaction_type="Disposition", stage="Due Diligence", buyer_name="Suncoast Retail Fund", seller_name="Harbor Pointe Holdings LLC", transaction_value=9400000, commission_estimate=282000, expected_close_date=date.today()+timedelta(days=58), compliance_status="In Review", document_status="Partial", approval_status="Broker Review", notes="Buyer requested updated rent roll and insurance documentation."),
            dict(property_id=property_records[1].id, transaction_name="Cypress Creek Lease-Up Strategy", transaction_type="Lease", stage="Offer / LOI", tenant_name="Regional Medical Billing Group", landlord_name="Cypress Professional Partners", transaction_value=1850000, commission_estimate=74000, expected_close_date=date.today()+timedelta(days=35), compliance_status="Pending Review", document_status="Incomplete", approval_status="Draft", notes="LOI under review. ADA and insurance items need review."),
            dict(property_id=property_records[2].id, transaction_name="Vero Logistics Investor Review", transaction_type="Acquisition", stage="Under Review", buyer_name="Atlantic Industrial Investors", seller_name="Vero Industrial Group", transaction_value=30250000, commission_estimate=907500, expected_close_date=date.today()+timedelta(days=75), compliance_status="Clear", document_status="Complete", approval_status="Approved", notes="Investor package ready."),
            dict(property_id=property_records[3].id, transaction_name="Probate Duplex Court Sale", transaction_type="Probate Sale", stage="Escrow", buyer_name="Broward Housing Partners", seller_name="Estate of R. Thompson", transaction_value=2200000, commission_estimate=66000, expected_close_date=date.today()+timedelta(days=44), compliance_status="High Attention", document_status="Missing Items", approval_status="Broker Review", notes="Court order and beneficiary acknowledgment pending.")
        ]
        for t in txs:
            db.session.add(PropertyTransaction(**t))
        db.session.commit()

    # Leases
    if LeaseRecord and property_records:
        leases = [
            dict(property_id=property_records[0].id, tenant_name="Coastal Fitness", lease_type="Retail", lease_status="Expiring Soon", start_date=date(2021,7,1), end_date=date.today()+timedelta(days=92), monthly_rent=18500, annual_rent=222000, square_feet_leased=7200, renewal_option="One 5-year option", expiration_risk="Moderate"),
            dict(property_id=property_records[1].id, tenant_name="Broward Legal Services", lease_type="Office", lease_status="Active", start_date=date(2023,1,15), end_date=date.today()+timedelta(days=480), monthly_rent=24000, annual_rent=288000, square_feet_leased=12000, renewal_option="Two 3-year options", expiration_risk="Normal"),
            dict(property_id=property_records[2].id, tenant_name="Atlantic Cold Storage", lease_type="Industrial", lease_status="Active", start_date=date(2022,4,1), end_date=date.today()+timedelta(days=1020), monthly_rent=91000, annual_rent=1092000, square_feet_leased=120000, renewal_option="One 10-year option", expiration_risk="Low")
        ]
        for l in leases:
            db.session.add(LeaseRecord(**l))
        db.session.commit()

    # Investors
    investor_records = []
    if Investor:
        investors = [
            dict(investor_name="Atlantic Industrial Investors", entity_name="Atlantic Industrial Fund I LP", email="acquisitions@atlanticindustrial.example", phone="954-555-0188", investor_type="Fund", accredited_status="Accredited", target_property_type="Industrial", target_market="South Florida / Treasure Coast", investment_capacity=50000000, risk_tolerance="Moderate", notes="Prefers stabilized industrial assets with strong tenant profile."),
            dict(investor_name="Suncoast Retail Fund", entity_name="Suncoast Retail Partners LLC", email="deals@suncoastretail.example", phone="305-555-0144", investor_type="Family Office", accredited_status="Accredited", target_property_type="Retail", target_market="Broward / Palm Beach", investment_capacity=15000000, risk_tolerance="Moderate", notes="Interested in neighborhood retail and grocery-anchored centers."),
            dict(investor_name="Broward Housing Partners", entity_name="BHP Acquisitions LLC", email="info@bhp.example", phone="954-555-0122", investor_type="Private Investor Group", accredited_status="Review Needed", target_property_type="Multifamily / Probate", target_market="Broward County", investment_capacity=5000000, risk_tolerance="High", notes="Looks for probate and value-add residential assets.")
        ]
        for data in investors:
            inv = Investor(**data)
            db.session.add(inv)
            investor_records.append(inv)
        db.session.commit()

    if PropertyInvestor and property_records and investor_records:
        links = [
            dict(property_id=property_records[2].id, investor_id=investor_records[0].id, ownership_percentage=0, investment_amount=30250000, role="Prospective Buyer"),
            dict(property_id=property_records[0].id, investor_id=investor_records[1].id, ownership_percentage=0, investment_amount=9400000, role="Prospective Buyer"),
            dict(property_id=property_records[3].id, investor_id=investor_records[2].id, ownership_percentage=0, investment_amount=2200000, role="Prospective Buyer")
        ]
        for link in links:
            db.session.add(PropertyInvestor(**link))
        db.session.commit()

    # Risk assessments and actions
    if PropertyRiskAssessment and property_records:
        risks = [
            dict(property_id=property_records[0].id, assessment_name="Retail Lease Rollover Review", environmental_risk=15, insurance_risk=40, vacancy_risk=48, tenant_concentration_risk=35, market_risk=28, title_legal_risk=20, document_completeness_risk=35, physical_condition_risk=30, financing_risk=22, compliance_risk=26, overall_risk_score=29.9, risk_level="Low", executive_summary="Stable retail asset with moderate lease rollover exposure.", recommendations="Update rent roll and prioritize renewal discussions.", assessed_by="broker_owner"),
            dict(property_id=property_records[1].id, assessment_name="Office Repositioning Risk Review", environmental_risk=20, insurance_risk=64, vacancy_risk=74, tenant_concentration_risk=58, market_risk=66, title_legal_risk=25, document_completeness_risk=52, physical_condition_risk=48, financing_risk=55, compliance_risk=42, overall_risk_score=50.4, risk_level="Moderate", executive_summary="Moderate risk due to vacancy, office market conditions, and insurance review.", recommendations="Create lease-up plan and review insurance cost exposure.", assessed_by="broker_owner"),
            dict(property_id=property_records[3].id, assessment_name="Probate Transaction Risk Review", environmental_risk=35, insurance_risk=50, vacancy_risk=65, tenant_concentration_risk=30, market_risk=45, title_legal_risk=82, document_completeness_risk=80, physical_condition_risk=70, financing_risk=45, compliance_risk=78, overall_risk_score=58, risk_level="Moderate", executive_summary="Probate property has elevated title, document, and compliance risk.", recommendations="Resolve court documentation, title issues, and beneficiary communications.", assessed_by="broker_owner")
        ]
        for r in risks:
            db.session.add(PropertyRiskAssessment(**r))
        db.session.commit()

    if PropertyRiskAction and property_records:
        actions = [
            dict(property_id=property_records[1].id, action_title="Review office insurance premium exposure", action_category="Insurance", priority="High", status="Open", assigned_to="ops_coordinator", due_date=date.today()+timedelta(days=7), notes="Collect updated insurance quotes."),
            dict(property_id=property_records[3].id, action_title="Obtain probate court order and beneficiary acknowledgment", action_category="Probate Governance", priority="High", status="Open", assigned_to="agent_carlos", due_date=date.today()+timedelta(days=5), notes="Required before closing package can be approved."),
            dict(property_id=property_records[0].id, action_title="Request updated tenant sales and rent roll", action_category="Due Diligence", priority="Medium", status="Open", assigned_to="agent_mia", due_date=date.today()+timedelta(days=10), notes="Buyer requested updated diligence package.")
        ]
        for a in actions:
            db.session.add(PropertyRiskAction(**a))
        db.session.commit()

    # Workflow tasks
    if WorkflowTask:
        tasks = [
            dict(related_type="Property", related_id=1, task_title="Upload updated rent roll", task_type="Document", priority="Medium", status="Open", assigned_to="ops_coordinator", due_date=date.today()+timedelta(days=3), created_by="broker_owner", notes="Needed for retail sale due diligence."),
            dict(related_type="Transaction", related_id=4, task_title="Confirm probate closing checklist", task_type="Probate", priority="High", status="Open", assigned_to="agent_carlos", due_date=date.today()+timedelta(days=2), created_by="broker_owner", notes="Court and estate documents pending."),
            dict(related_type="Investor", related_id=1, task_title="Send investor package for Vero Logistics", task_type="Investor Follow-Up", priority="High", status="Open", assigned_to="agent_mia", due_date=date.today()+timedelta(days=1), created_by="broker_owner", notes="Investor requested executive summary.")
        ]
        for t in tasks:
            db.session.add(WorkflowTask(**t))
        db.session.commit()

    # Commissions
    if CommissionRecord:
        commissions = [
            dict(transaction_id=1, property_id=1, agent_name="agent_mia", broker_name="broker_owner", gross_commission=282000, broker_amount=84600, agent_amount=169200, operations_amount=14100, referral_amount=0, net_company_revenue=98700, payout_status="Projected", notes="Projected on disposition close."),
            dict(transaction_id=3, property_id=3, agent_name="agent_mia", broker_name="broker_owner", gross_commission=907500, broker_amount=272250, agent_amount=544500, operations_amount=45375, referral_amount=0, net_company_revenue=317625, payout_status="Projected", notes="Investor acquisition commission forecast.")
        ]
        for c in commissions:
            db.session.add(CommissionRecord(**c))
        db.session.commit()

    # Reports
    if RealEstateReport:
        reports = [
            dict(report_title="Harbor Pointe Executive Deal Summary", report_type="Investor Report", related_type="Property", related_id=1, report_status="Draft", prepared_by="ops_coordinator", executive_summary="Retail asset with strong occupancy and moderate lease rollover exposure."),
            dict(report_title="Cypress Creek Risk & Lease-Up Report", report_type="Property Performance", related_type="Property", related_id=2, report_status="Broker Review", prepared_by="agent_carlos", executive_summary="Office repositioning opportunity requiring lease-up strategy and insurance review."),
            dict(report_title="Probate Duplex Closing Readiness Report", report_type="Probate Governance", related_type="Property", related_id=4, report_status="Action Required", prepared_by="ops_coordinator", executive_summary="Court and title documentation are the main closing blockers.")
        ]
        for r in reports:
            db.session.add(RealEstateReport(**r))
        db.session.commit()

    # GIS
    if PropertyGeoProfile and property_records:
        geos = [
            dict(property_id=property_records[0].id, latitude=26.1224, longitude=-80.1373, neighborhood="Harbor Shops", market_area="Fort Lauderdale", flood_zone="AE", zoning="B-1", opportunity_zone=False, census_tract="12011041600", traffic_count="32,000 AADT", walkability_score=78, market_notes="Strong retail corridor near port and residential density."),
            dict(property_id=property_records[1].id, latitude=26.2021, longitude=-80.1664, neighborhood="Cypress Creek", market_area="North Fort Lauderdale Office", flood_zone="X", zoning="B-3", opportunity_zone=False, census_tract="12011050400", traffic_count="54,000 AADT", walkability_score=52, market_notes="Office corridor with repositioning potential."),
            dict(property_id=property_records[2].id, latitude=27.6503, longitude=-80.3973, neighborhood="Airport Industrial", market_area="Vero Beach", flood_zone="X", zoning="Industrial", opportunity_zone=True, census_tract="12061050800", traffic_count="18,000 AADT", walkability_score=38, market_notes="Logistics location near regional airport.")
        ]
        for g in geos:
            db.session.add(PropertyGeoProfile(**g))
        db.session.commit()

    # AI insights
    if AIAdvisorInsight:
        insights = [
            dict(insight_title="Probate deal requires immediate document attention", insight_type="Probate Governance", priority="High", related_type="Property", related_id=4, insight_summary="Court order and beneficiary acknowledgment are pending.", recommended_action="Assign operations follow-up and broker review within 48 hours.", created_by="system"),
            dict(insight_title="Cypress Creek vacancy risk may affect pricing", insight_type="Property Risk", priority="Medium", related_type="Property", related_id=2, insight_summary="Vacancy risk and market risk are elevated.", recommended_action="Update lease-up assumptions before final investor report.", created_by="system"),
            dict(insight_title="Vero Logistics investor package is ready", insight_type="Investor", priority="High", related_type="Property", related_id=3, insight_summary="Document and compliance readiness are strong.", recommended_action="Send investor package and schedule review call.", created_by="system")
        ]
        for i in insights:
            db.session.add(AIAdvisorInsight(**i))
        db.session.commit()

    print("SentinelRE demo database created successfully.")
    print("Demo logins:")
    print("broker_owner / BrokerDemo2026!")
    print("ops_coordinator / OpsDemo2026!")
    print("agent_mia / AgentDemo2026!")
    print("agent_carlos / AgentDemo2026!")
    print("readonly_demo / ReadOnly2026!")
