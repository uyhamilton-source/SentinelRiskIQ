
"""
SentinelRE Phase 26 Migration – Interactive GIS Maps
Run from the SentinelRE application folder:
    python migrate_phase26_interactive_gis.py
"""

import sqlite3
from pathlib import Path

db_path = Path("sentinelre.db")
if not db_path.exists():
    if Path("sentinelops.db").exists():
        db_path = Path("sentinelops.db")
    else:
        raise SystemExit("No sentinelre.db or sentinelops.db found.")

conn = sqlite3.connect(db_path)
cur = conn.cursor()

statements = [
"""
CREATE TABLE IF NOT EXISTS map_view (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    view_name VARCHAR(255) NOT NULL,
    view_type VARCHAR(120),
    default_latitude FLOAT DEFAULT 26.1224,
    default_longitude FLOAT DEFAULT -80.1373,
    default_zoom INTEGER DEFAULT 10,
    active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS map_marker_note (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER,
    marker_type VARCHAR(120),
    note_title VARCHAR(255),
    note_text TEXT,
    created_by VARCHAR(120),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS market_overlay (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    overlay_name VARCHAR(255) NOT NULL,
    overlay_type VARCHAR(120),
    market_area VARCHAR(255),
    layer_color VARCHAR(50),
    risk_level VARCHAR(50),
    notes TEXT,
    active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
"""
]

for stmt in statements:
    cur.execute(stmt)

conn.commit()
conn.close()
print(f"Phase 26 Interactive GIS migration complete: {db_path}")
