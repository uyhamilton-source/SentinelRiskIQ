
# SentinelRE Phase 19 – Property Risk Engine & Workflow Automation Models

class PropertyRiskAssessment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"), nullable=False)
    assessment_name = db.Column(db.String(255))
    assessment_status = db.Column(db.String(100), default="Draft")
    environmental_risk = db.Column(db.Float, default=0)
    insurance_risk = db.Column(db.Float, default=0)
    vacancy_risk = db.Column(db.Float, default=0)
    tenant_concentration_risk = db.Column(db.Float, default=0)
    market_risk = db.Column(db.Float, default=0)
    title_legal_risk = db.Column(db.Float, default=0)
    document_completeness_risk = db.Column(db.Float, default=0)
    physical_condition_risk = db.Column(db.Float, default=0)
    financing_risk = db.Column(db.Float, default=0)
    compliance_risk = db.Column(db.Float, default=0)
    overall_risk_score = db.Column(db.Float, default=0)
    risk_level = db.Column(db.String(50), default="Not Scored")
    executive_summary = db.Column(db.Text)
    recommendations = db.Column(db.Text)
    assessed_by = db.Column(db.String(120))
    assessed_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyRiskAction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    assessment_id = db.Column(db.Integer, db.ForeignKey("property_risk_assessment.id"))
    action_title = db.Column(db.String(255), nullable=False)
    action_category = db.Column(db.String(120))
    priority = db.Column(db.String(50), default="Medium")
    status = db.Column(db.String(100), default="Open")
    assigned_to = db.Column(db.String(120))
    due_date = db.Column(db.Date)
    completed_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class WorkflowRule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rule_name = db.Column(db.String(255), nullable=False)
    workflow_type = db.Column(db.String(120))
    trigger_event = db.Column(db.String(120))
    condition_field = db.Column(db.String(120))
    condition_operator = db.Column(db.String(50))
    condition_value = db.Column(db.String(255))
    action_type = db.Column(db.String(120))
    action_owner = db.Column(db.String(120))
    action_template = db.Column(db.Text)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class WorkflowTask(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    task_title = db.Column(db.String(255), nullable=False)
    task_type = db.Column(db.String(120))
    priority = db.Column(db.String(50), default="Medium")
    status = db.Column(db.String(100), default="Open")
    assigned_to = db.Column(db.String(120))
    due_date = db.Column(db.Date)
    completed_at = db.Column(db.DateTime)
    created_by = db.Column(db.String(120))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class WorkflowEventLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workflow_rule_id = db.Column(db.Integer, db.ForeignKey("workflow_rule.id"))
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    event_name = db.Column(db.String(255))
    event_status = db.Column(db.String(100))
    event_details = db.Column(db.Text)
    executed_by = db.Column(db.String(120))
    executed_at = db.Column(db.DateTime, default=datetime.utcnow)
