
# SentinelRE Phase 21-24 Models – Commission, Reporting, Mapping/GIS, AI Executive Advisor

class CommissionPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    plan_name = db.Column(db.String(255), nullable=False)
    plan_type = db.Column(db.String(120))
    broker_split_percent = db.Column(db.Float, default=0)
    agent_split_percent = db.Column(db.Float, default=0)
    operations_split_percent = db.Column(db.Float, default=0)
    referral_fee_percent = db.Column(db.Float, default=0)
    minimum_broker_fee = db.Column(db.Float, default=0)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class CommissionRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer)
    property_id = db.Column(db.Integer)
    agent_name = db.Column(db.String(120))
    broker_name = db.Column(db.String(120))
    gross_commission = db.Column(db.Float, default=0)
    broker_amount = db.Column(db.Float, default=0)
    agent_amount = db.Column(db.Float, default=0)
    operations_amount = db.Column(db.Float, default=0)
    referral_amount = db.Column(db.Float, default=0)
    net_company_revenue = db.Column(db.Float, default=0)
    payout_status = db.Column(db.String(100), default="Pending")
    payout_date = db.Column(db.Date)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class RealEstateReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    report_title = db.Column(db.String(255), nullable=False)
    report_type = db.Column(db.String(120))
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    report_status = db.Column(db.String(100), default="Draft")
    prepared_by = db.Column(db.String(120))
    approved_by = db.Column(db.String(120))
    approved_at = db.Column(db.DateTime)
    file_path = db.Column(db.String(500))
    executive_summary = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyGeoProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    neighborhood = db.Column(db.String(255))
    market_area = db.Column(db.String(255))
    flood_zone = db.Column(db.String(120))
    zoning = db.Column(db.String(120))
    opportunity_zone = db.Column(db.Boolean, default=False)
    census_tract = db.Column(db.String(120))
    traffic_count = db.Column(db.String(120))
    walkability_score = db.Column(db.Float)
    market_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class GISLayer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    layer_name = db.Column(db.String(255), nullable=False)
    layer_type = db.Column(db.String(120))
    description = db.Column(db.Text)
    source_name = db.Column(db.String(255))
    source_url = db.Column(db.String(500))
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorQuery(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(120))
    query_text = db.Column(db.Text, nullable=False)
    response_summary = db.Column(db.Text)
    query_category = db.Column(db.String(120))
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    confidence_note = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorInsight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    insight_title = db.Column(db.String(255), nullable=False)
    insight_type = db.Column(db.String(120))
    priority = db.Column(db.String(50), default="Medium")
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    insight_summary = db.Column(db.Text)
    recommended_action = db.Column(db.Text)
    status = db.Column(db.String(100), default="Open")
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
