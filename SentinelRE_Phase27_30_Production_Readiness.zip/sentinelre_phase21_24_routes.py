
# SentinelRE Phase 21-24 Routes

def calc_commission(gross, broker_pct, agent_pct, ops_pct, referral_pct):
    gross = float(gross or 0)
    broker = gross * float(broker_pct or 0) / 100
    agent = gross * float(agent_pct or 0) / 100
    ops = gross * float(ops_pct or 0) / 100
    referral = gross * float(referral_pct or 0) / 100
    net = gross - agent - ops - referral
    return broker, agent, ops, referral, net


@app.route("/commissions", methods=["GET", "POST"])
@login_required
def commissions():
    if request.method == "POST":
        gross = float(request.form.get("gross_commission") or 0)
        broker_pct = float(request.form.get("broker_split_percent") or 0)
        agent_pct = float(request.form.get("agent_split_percent") or 0)
        ops_pct = float(request.form.get("operations_split_percent") or 0)
        referral_pct = float(request.form.get("referral_fee_percent") or 0)
        broker, agent, ops, referral, net = calc_commission(gross, broker_pct, agent_pct, ops_pct, referral_pct)

        record = CommissionRecord(
            transaction_id=request.form.get("transaction_id") or None,
            property_id=request.form.get("property_id") or None,
            agent_name=request.form.get("agent_name"),
            broker_name=request.form.get("broker_name"),
            gross_commission=gross,
            broker_amount=broker,
            agent_amount=agent,
            operations_amount=ops,
            referral_amount=referral,
            net_company_revenue=net,
            payout_status=request.form.get("payout_status") or "Pending",
            payout_date=request.form.get("payout_date") or None,
            notes=request.form.get("notes")
        )
        db.session.add(record)
        db.session.commit()
        flash("Commission record created.")
        return redirect(url_for("commissions"))

    records = CommissionRecord.query.order_by(CommissionRecord.created_at.desc()).all()
    total_gross = sum([r.gross_commission or 0 for r in records])
    total_net = sum([r.net_company_revenue or 0 for r in records])
    return render_template("commissions.html", records=records, total_gross=total_gross, total_net=total_net, brand=BRAND)


@app.route("/real-estate-reports", methods=["GET", "POST"])
@login_required
def real_estate_reports():
    if request.method == "POST":
        report = RealEstateReport(
            report_title=request.form.get("report_title"),
            report_type=request.form.get("report_type"),
            related_type=request.form.get("related_type"),
            related_id=request.form.get("related_id") or None,
            report_status=request.form.get("report_status") or "Draft",
            prepared_by=current_user.username,
            executive_summary=request.form.get("executive_summary")
        )
        db.session.add(report)
        db.session.commit()
        flash("Real estate report created.")
        return redirect(url_for("real_estate_reports"))

    reports = RealEstateReport.query.order_by(RealEstateReport.created_at.desc()).all()
    return render_template("real_estate_reports.html", reports=reports, brand=BRAND)


@app.route("/mapping-gis", methods=["GET", "POST"])
@login_required
def mapping_gis():
    if request.method == "POST":
        geo = PropertyGeoProfile(
            property_id=request.form.get("property_id") or None,
            latitude=float(request.form.get("latitude") or 0),
            longitude=float(request.form.get("longitude") or 0),
            neighborhood=request.form.get("neighborhood"),
            market_area=request.form.get("market_area"),
            flood_zone=request.form.get("flood_zone"),
            zoning=request.form.get("zoning"),
            opportunity_zone=bool(request.form.get("opportunity_zone")),
            census_tract=request.form.get("census_tract"),
            traffic_count=request.form.get("traffic_count"),
            walkability_score=float(request.form.get("walkability_score") or 0),
            market_notes=request.form.get("market_notes")
        )
        db.session.add(geo)
        db.session.commit()
        flash("Property geo profile saved.")
        return redirect(url_for("mapping_gis"))

    profiles = PropertyGeoProfile.query.order_by(PropertyGeoProfile.created_at.desc()).all()
    layers = GISLayer.query.filter_by(active=True).all()
    return render_template("mapping_gis.html", profiles=profiles, layers=layers, brand=BRAND)


@app.route("/ai-executive-advisor", methods=["GET", "POST"])
@login_required
def ai_executive_advisor():
    response_summary = None
    if request.method == "POST":
        query_text = request.form.get("query_text")
        category = "Executive Inquiry"
        # Rule-based placeholder until full AI integration is added.
        q = (query_text or "").lower()
        if "risk" in q:
            response_summary = "Review the Property Risk Intelligence dashboard for high and moderate risk properties, then prioritize open risk actions by due date and impact."
            category = "Risk"
        elif "commission" in q or "revenue" in q:
            response_summary = "Review commission records, net company revenue, open transactions, and expected closing dates to estimate short-term revenue."
            category = "Revenue"
        elif "compliance" in q:
            response_summary = "Review Regulatory Readiness, License Compliance, AML, Transaction Governance, and Document Governance queues for overdue or incomplete items."
            category = "Compliance"
        elif "investor" in q:
            response_summary = "Review investor preferences, property matches, and pending investor reports to identify priority follow-up opportunities."
            category = "Investor"
        else:
            response_summary = "Use the Executive Dashboard, Property Risk, Workflow Tasks, and Investor Management screens to identify the next best action."

        query = AIAdvisorQuery(
            user_name=current_user.username,
            query_text=query_text,
            response_summary=response_summary,
            query_category=category,
            confidence_note="Rule-based Phase 21-24 advisor response. Full LLM integration can be added later."
        )
        db.session.add(query)
        db.session.commit()

    queries = AIAdvisorQuery.query.order_by(AIAdvisorQuery.created_at.desc()).limit(10).all()
    insights = AIAdvisorInsight.query.filter(AIAdvisorInsight.status != "Closed").order_by(AIAdvisorInsight.created_at.desc()).all()
    return render_template("ai_executive_advisor.html", queries=queries, insights=insights, response_summary=response_summary, brand=BRAND)
