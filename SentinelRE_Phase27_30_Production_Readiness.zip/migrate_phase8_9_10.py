"""SentinelRE Phase 8/9/10 migration.
Creates new compliance tables for License & CE, AML/Transaction Governance, and Probate Governance.
Run: python migrate_phase8_9_10.py
"""
from app import app, db
with app.app_context():
    db.create_all()
    print("SentinelRE Phase 8/9/10 tables verified/created successfully.")
