# SentinelRE Phase 17 – Property-Centric Data Model

## Purpose
This phase moves SentinelRE from operations/client/opportunity centered workflows into a property-centered real estate platform.

## New Core Flow
Property → Transactions → Leases → Documents → Investors → Compliance → Risk → Reporting

## Added Tables
- property
- property_transaction
- lease_record
- investor
- property_investor
- property_risk_score
- property_compliance_checklist

## Recommended Navigation
Real Estate
- Properties
- Transactions
- Leases
- Investors
- Property Risk
- Property Compliance

## Deployment
1. Backup the database.
2. Run: `python migrate_phase17_property_centric.py`
3. Restart the app.

## Next UI Build
Create full CRUD screens for Properties, Transactions, Leases, Investors, Risk Scores, and Compliance Checklists.
