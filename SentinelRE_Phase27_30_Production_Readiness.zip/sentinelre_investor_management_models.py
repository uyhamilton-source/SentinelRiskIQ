
# SentinelRE Phase 18 – Investor Management Models

class InvestorContact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    contact_name = db.Column(db.String(255))
    title = db.Column(db.String(120))
    email = db.Column(db.String(255))
    phone = db.Column(db.String(80))
    preferred_contact_method = db.Column(db.String(80))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class InvestorInteraction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    interaction_type = db.Column(db.String(120))
    subject = db.Column(db.String(255))
    notes = db.Column(db.Text)
    follow_up_required = db.Column(db.Boolean, default=False)
    follow_up_date = db.Column(db.Date)
    completed = db.Column(db.Boolean, default=False)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class InvestorPreference(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    target_markets = db.Column(db.Text)
    target_property_types = db.Column(db.Text)
    min_investment = db.Column(db.Float)
    max_investment = db.Column(db.Float)
    preferred_hold_period = db.Column(db.String(120))
    risk_profile = db.Column(db.String(120))
    return_target = db.Column(db.String(120))
    financing_preference = db.Column(db.String(120))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class InvestorOpportunityMatch(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    transaction_id = db.Column(db.Integer, db.ForeignKey("property_transaction.id"))
    match_score = db.Column(db.Float, default=0)
    readiness_status = db.Column(db.String(100), default="Review Needed")
    recommended_action = db.Column(db.String(255))
    matched_by = db.Column(db.String(120))
    matched_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)


class InvestorReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    report_title = db.Column(db.String(255))
    report_type = db.Column(db.String(120))
    report_status = db.Column(db.String(100), default="Draft")
    prepared_by = db.Column(db.String(120))
    approved_by = db.Column(db.String(120))
    approved_at = db.Column(db.DateTime)
    file_path = db.Column(db.String(500))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class InvestorDocument(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    filename = db.Column(db.String(255))
    document_type = db.Column(db.String(120))
    category = db.Column(db.String(120))
    status = db.Column(db.String(100), default="Uploaded")
    uploaded_by = db.Column(db.String(120))
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    file_path = db.Column(db.String(500))
    notes = db.Column(db.Text)
