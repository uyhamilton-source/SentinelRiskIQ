
"""
SentinelRE Phase 21-24 Migration – Commission, Reporting, Mapping/GIS, AI Executive Advisor
Run from the SentinelRE application folder:
    python migrate_phase21_24_commission_reporting_gis_ai.py
"""

import sqlite3
from pathlib import Path

db_path = Path("sentinelre.db")
if not db_path.exists():
    if Path("sentinelops.db").exists():
        db_path = Path("sentinelops.db")
    else:
        raise SystemExit("No sentinelre.db or sentinelops.db found.")

conn = sqlite3.connect(db_path)
cur = conn.cursor()

statements = [
"""
CREATE TABLE IF NOT EXISTS commission_plan (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_name VARCHAR(255) NOT NULL,
    plan_type VARCHAR(120),
    broker_split_percent FLOAT DEFAULT 0,
    agent_split_percent FLOAT DEFAULT 0,
    operations_split_percent FLOAT DEFAULT 0,
    referral_fee_percent FLOAT DEFAULT 0,
    minimum_broker_fee FLOAT DEFAULT 0,
    active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS commission_record (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id INTEGER,
    property_id INTEGER,
    agent_name VARCHAR(120),
    broker_name VARCHAR(120),
    gross_commission FLOAT DEFAULT 0,
    broker_amount FLOAT DEFAULT 0,
    agent_amount FLOAT DEFAULT 0,
    operations_amount FLOAT DEFAULT 0,
    referral_amount FLOAT DEFAULT 0,
    net_company_revenue FLOAT DEFAULT 0,
    payout_status VARCHAR(100) DEFAULT 'Pending',
    payout_date DATE,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS real_estate_report (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_title VARCHAR(255) NOT NULL,
    report_type VARCHAR(120),
    related_type VARCHAR(120),
    related_id INTEGER,
    report_status VARCHAR(100) DEFAULT 'Draft',
    prepared_by VARCHAR(120),
    approved_by VARCHAR(120),
    approved_at DATETIME,
    file_path VARCHAR(500),
    executive_summary TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS property_geo_profile (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER,
    latitude FLOAT,
    longitude FLOAT,
    neighborhood VARCHAR(255),
    market_area VARCHAR(255),
    flood_zone VARCHAR(120),
    zoning VARCHAR(120),
    opportunity_zone BOOLEAN DEFAULT 0,
    census_tract VARCHAR(120),
    traffic_count VARCHAR(120),
    walkability_score FLOAT,
    market_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS gis_layer (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    layer_name VARCHAR(255) NOT NULL,
    layer_type VARCHAR(120),
    description TEXT,
    source_name VARCHAR(255),
    source_url VARCHAR(500),
    active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS ai_advisor_query (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_name VARCHAR(120),
    query_text TEXT NOT NULL,
    response_summary TEXT,
    query_category VARCHAR(120),
    related_type VARCHAR(120),
    related_id INTEGER,
    confidence_note TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS ai_advisor_insight (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    insight_title VARCHAR(255) NOT NULL,
    insight_type VARCHAR(120),
    priority VARCHAR(50) DEFAULT 'Medium',
    related_type VARCHAR(120),
    related_id INTEGER,
    insight_summary TEXT,
    recommended_action TEXT,
    status VARCHAR(100) DEFAULT 'Open',
    created_by VARCHAR(120),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
"""
]

for stmt in statements:
    cur.execute(stmt)

conn.commit()
conn.close()
print(f"Phase 21-24 migration complete: {db_path}")
