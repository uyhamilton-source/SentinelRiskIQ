
"""
SentinelRE Phase 19 Migration – Property Risk Engine & Workflow Automation
Run from the SentinelRE application folder:
    python migrate_phase19_property_risk_workflow.py
"""

import sqlite3
from pathlib import Path

db_path = Path("sentinelre.db")
if not db_path.exists():
    if Path("sentinelops.db").exists():
        db_path = Path("sentinelops.db")
    else:
        raise SystemExit("No sentinelre.db or sentinelops.db found.")

conn = sqlite3.connect(db_path)
cur = conn.cursor()

statements = [
"""
CREATE TABLE IF NOT EXISTS property_risk_assessment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER NOT NULL,
    assessment_name VARCHAR(255),
    assessment_status VARCHAR(100) DEFAULT 'Draft',
    environmental_risk FLOAT DEFAULT 0,
    insurance_risk FLOAT DEFAULT 0,
    vacancy_risk FLOAT DEFAULT 0,
    tenant_concentration_risk FLOAT DEFAULT 0,
    market_risk FLOAT DEFAULT 0,
    title_legal_risk FLOAT DEFAULT 0,
    document_completeness_risk FLOAT DEFAULT 0,
    physical_condition_risk FLOAT DEFAULT 0,
    financing_risk FLOAT DEFAULT 0,
    compliance_risk FLOAT DEFAULT 0,
    overall_risk_score FLOAT DEFAULT 0,
    risk_level VARCHAR(50) DEFAULT 'Not Scored',
    executive_summary TEXT,
    recommendations TEXT,
    assessed_by VARCHAR(120),
    assessed_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS property_risk_action (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id INTEGER,
    assessment_id INTEGER,
    action_title VARCHAR(255) NOT NULL,
    action_category VARCHAR(120),
    priority VARCHAR(50) DEFAULT 'Medium',
    status VARCHAR(100) DEFAULT 'Open',
    assigned_to VARCHAR(120),
    due_date DATE,
    completed_at DATETIME,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS workflow_rule (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_name VARCHAR(255) NOT NULL,
    workflow_type VARCHAR(120),
    trigger_event VARCHAR(120),
    condition_field VARCHAR(120),
    condition_operator VARCHAR(50),
    condition_value VARCHAR(255),
    action_type VARCHAR(120),
    action_owner VARCHAR(120),
    action_template TEXT,
    active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS workflow_task (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    related_type VARCHAR(120),
    related_id INTEGER,
    task_title VARCHAR(255) NOT NULL,
    task_type VARCHAR(120),
    priority VARCHAR(50) DEFAULT 'Medium',
    status VARCHAR(100) DEFAULT 'Open',
    assigned_to VARCHAR(120),
    due_date DATE,
    completed_at DATETIME,
    created_by VARCHAR(120),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS workflow_event_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_rule_id INTEGER,
    related_type VARCHAR(120),
    related_id INTEGER,
    event_name VARCHAR(255),
    event_status VARCHAR(100),
    event_details TEXT,
    executed_by VARCHAR(120),
    executed_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
"""
]

for stmt in statements:
    cur.execute(stmt)

conn.commit()
conn.close()
print(f"Phase 19 Property Risk Engine & Workflow Automation migration complete: {db_path}")
