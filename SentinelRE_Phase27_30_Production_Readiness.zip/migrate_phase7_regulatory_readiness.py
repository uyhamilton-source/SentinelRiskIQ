"""SentinelRE Phase 7 Regulatory Readiness migration."""
from app import app, db, RegulatoryReadinessAssessment, ComplianceActionItem

with app.app_context():
    db.create_all()
    print("Phase 7 regulatory readiness tables ensured:")
    print("- regulatory_readiness_assessment")
    print("- compliance_action_item")
