# SentinelRE Role Mapping

| SentinelOps Role | SentinelRE Role | Permission Intent |
|---|---|---|
| Administrator | Owner (Broker) | Full broker/owner authority |
| Operations Coordinator | Operations Coordinator | Operations/VA support |
| Advisor | Realtor / Agent | Realtor/agent support role |
| Read Only | Read Only | View-only access |

Owner (Broker) controls pricing, proposal approval, user management, exports, audit logs, and system settings.
Operations Coordinator can manage pipeline records, follow-ups, and draft proposal packages but should not make final pricing or broker-level approval decisions.
Realtor / Agent can support active clients, property/deal workflows, broker advisory records, and approved reporting.
