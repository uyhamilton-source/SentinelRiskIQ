# SentinelRE Role Standardization

Standard production roles:

- Owner/Broker
- Operations Coordinator
- Realtor/Agent
- Read Only
- Client Portal User

This build standardizes `Owner (Broker)` to `Owner/Broker`.
