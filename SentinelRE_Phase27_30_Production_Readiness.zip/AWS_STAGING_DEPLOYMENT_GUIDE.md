# SentinelRE AWS Staging Deployment Guide

## Target
- Domain: `re.sentinelriskcg.com`
- Path: `/home/ubuntu/SentinelRE`
- Service: `sentinelre.service`
- Port: `127.0.0.1:8010`
- Database: `sentinelre.db`

## Install

```bash
sudo mkdir -p /home/ubuntu/SentinelRE
sudo chown -R ubuntu:ubuntu /home/ubuntu/SentinelRE
cd /home/ubuntu/SentinelRE
unzip SentinelRE_Production_Security_Staging_Ready.zip
```

If files extract into a subfolder, move the app files into `/home/ubuntu/SentinelRE`.

## Environment

```bash
cp .env.example .env
nano .env
```

Replace `SENTINELRE_SECRET_KEY` with a new strong value if desired.

## Python

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 -m py_compile app.py
```

## Database migrations

Run all migrations available in the folder:

```bash
python migrate_phase17_property_centric.py
python migrate_phase18_investor_management.py
python migrate_phase19_property_risk_workflow.py
python migrate_phase20_client_portal_esign.py
python migrate_phase21_24_commission_reporting_gis_ai.py
python migrate_phase25_esign_ai_hardening.py
python migrate_phase26_interactive_gis.py
python seed_sentinelre_demo.py
```

## Service

```bash
sudo cp sentinelre.service /etc/systemd/system/sentinelre.service
sudo systemctl daemon-reload
sudo systemctl enable sentinelre
sudo systemctl start sentinelre
sudo systemctl status sentinelre
```

## Nginx

```bash
sudo cp nginx_sentinelre.conf /etc/nginx/sites-available/sentinelre
sudo ln -s /etc/nginx/sites-available/sentinelre /etc/nginx/sites-enabled/sentinelre
sudo nginx -t
sudo systemctl restart nginx
```

## SSL

After DNS A record points `re.sentinelriskcg.com` to the AWS public IP:

```bash
sudo certbot --nginx -d re.sentinelriskcg.com
```

## Test

```bash
curl http://127.0.0.1:8010/login
curl -H "Host: re.sentinelriskcg.com" http://127.0.0.1/login
```

Then browse:

`https://re.sentinelriskcg.com/login`

## Security Notes
- Do not use demo accounts for live clients.
- Change all passwords before public access.
- Keep SentinelRE separate from SentinelOps.
- Do not expose `/uploads` directly.
- Keep `.env` private.
