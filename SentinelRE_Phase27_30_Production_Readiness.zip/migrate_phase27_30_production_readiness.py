
"""
SentinelRE Phase 27-30 Migration – Production Readiness
Run:
    python migrate_phase27_30_production_readiness.py
"""

import sqlite3
from pathlib import Path

db_path = Path("sentinelre.db")
if not db_path.exists():
    if Path("sentinelops.db").exists():
        db_path = Path("sentinelops.db")
    else:
        raise SystemExit("No sentinelre.db or sentinelops.db found.")

conn = sqlite3.connect(db_path)
cur = conn.cursor()

statements = [
"""
CREATE TABLE IF NOT EXISTS route_validation_result (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    route_path VARCHAR(255),
    http_status INTEGER,
    validation_status VARCHAR(50),
    validation_notes TEXT,
    tested_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS legal_template_review (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_name VARCHAR(255) NOT NULL,
    template_type VARCHAR(120),
    legal_status VARCHAR(100) DEFAULT 'Attorney Review Needed',
    reviewed_by VARCHAR(120),
    reviewed_at DATETIME,
    approved_for_use BOOLEAN DEFAULT 0,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS esign_compliance_control (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    control_name VARCHAR(255) NOT NULL,
    control_area VARCHAR(120),
    requirement_summary TEXT,
    implemented BOOLEAN DEFAULT 0,
    attorney_review_required BOOLEAN DEFAULT 1,
    status VARCHAR(100) DEFAULT 'Open',
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS portal_mfa_challenge (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    portal_user_id INTEGER,
    challenge_type VARCHAR(120) DEFAULT 'Email OTP',
    challenge_code VARCHAR(120),
    expires_at DATETIME,
    verified BOOLEAN DEFAULT 0,
    verified_at DATETIME,
    ip_address VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS portal_access_policy (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    policy_name VARCHAR(255) NOT NULL,
    policy_type VARCHAR(120),
    policy_description TEXT,
    active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS secure_document_token (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER,
    portal_user_id INTEGER,
    token VARCHAR(255),
    expires_at DATETIME,
    used BOOLEAN DEFAULT 0,
    used_at DATETIME,
    ip_address VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS ai_data_classification_rule (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_name VARCHAR(255) NOT NULL,
    data_type VARCHAR(120),
    classification VARCHAR(120),
    ai_access_allowed BOOLEAN DEFAULT 0,
    redaction_required BOOLEAN DEFAULT 1,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS ai_governance_setting (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    setting_name VARCHAR(255) NOT NULL,
    setting_value VARCHAR(255),
    setting_description TEXT,
    updated_by VARCHAR(120),
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS ai_prompt_audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_name VARCHAR(120),
    prompt_text TEXT,
    response_summary TEXT,
    data_classification VARCHAR(120),
    blocked BOOLEAN DEFAULT 0,
    block_reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
"""
]

for stmt in statements:
    cur.execute(stmt)

# Seed required controls if empty
cur.execute("SELECT COUNT(*) FROM esign_compliance_control")
if cur.fetchone()[0] == 0:
    controls = [
        ("Electronic consent capture", "ESIGN/UETA", "Capture clear consent to electronic records and signature.", 1),
        ("Intent to sign", "ESIGN/UETA", "Capture affirmative action showing signer intent.", 1),
        ("Audit trail", "ESIGN/UETA", "Capture IP, timestamp, user agent, consent text, and signature hash.", 1),
        ("Certificate generation", "Evidence", "Generate a signature certificate for completed signatures.", 1),
        ("Attorney template review", "Legal", "Attorney review required for real estate templates before production use.", 0),
        ("Retention policy", "Records", "Define retention rules for signed records and certificates.", 0),
    ]
    cur.executemany("""
        INSERT INTO esign_compliance_control
        (control_name, control_area, requirement_summary, implemented)
        VALUES (?, ?, ?, ?)
    """, controls)

cur.execute("SELECT COUNT(*) FROM ai_data_classification_rule")
if cur.fetchone()[0] == 0:
    rules = [
        ("Block SSN", "SSN", "Restricted", 0, 1, "AI must not process SSNs."),
        ("Block bank information", "Bank Account", "Restricted", 0, 1, "AI must not process bank account or wire data."),
        ("Block attorney notes", "Attorney Notes", "Privileged", 0, 1, "AI must not process privileged legal notes."),
        ("Allow property metadata", "Property Metadata", "Internal", 1, 0, "Basic property metadata may be used for internal advisor responses."),
        ("Allow risk scores", "Risk Score", "Internal", 1, 0, "Risk scoring metadata may be used for advisor summaries."),
    ]
    cur.executemany("""
        INSERT INTO ai_data_classification_rule
        (rule_name, data_type, classification, ai_access_allowed, redaction_required, notes)
        VALUES (?, ?, ?, ?, ?, ?)
    """, rules)

cur.execute("SELECT COUNT(*) FROM ai_governance_setting")
if cur.fetchone()[0] == 0:
    settings = [
        ("AI_MODE", "Internal Context Only", "External AI disabled until privacy review is complete."),
        ("ALLOW_EXTERNAL_AI", "false", "Do not send confidential client data to external AI providers."),
        ("LOG_AI_PROMPTS", "true", "Audit AI prompts and recommendations."),
    ]
    cur.executemany("""
        INSERT INTO ai_governance_setting
        (setting_name, setting_value, setting_description)
        VALUES (?, ?, ?)
    """, settings)

conn.commit()
conn.close()
print(f"Phase 27-30 production readiness migration complete: {db_path}")
