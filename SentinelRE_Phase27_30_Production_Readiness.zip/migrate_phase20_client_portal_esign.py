
"""
SentinelRE Phase 20 Migration – Client Portal & E-Signature
Run from the SentinelRE application folder:
    python migrate_phase20_client_portal_esign.py
"""

import sqlite3
from pathlib import Path

db_path = Path("sentinelre.db")
if not db_path.exists():
    if Path("sentinelops.db").exists():
        db_path = Path("sentinelops.db")
    else:
        raise SystemExit("No sentinelre.db or sentinelops.db found.")

conn = sqlite3.connect(db_path)
cur = conn.cursor()

statements = [
"""
CREATE TABLE IF NOT EXISTS portal_user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(80) NOT NULL UNIQUE,
    email VARCHAR(255),
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(80) DEFAULT 'Client',
    client_name VARCHAR(255),
    investor_id INTEGER,
    property_id INTEGER,
    active BOOLEAN DEFAULT 1,
    access_approved BOOLEAN DEFAULT 0,
    last_login_at DATETIME,
    last_login_ip VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS portal_message (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    portal_user_id INTEGER,
    sender VARCHAR(120),
    subject VARCHAR(255),
    message TEXT,
    status VARCHAR(100) DEFAULT 'Unread',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS portal_access_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    portal_user_id INTEGER,
    event_type VARCHAR(120),
    event_details TEXT,
    ip_address VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
""",
"""
CREATE TABLE IF NOT EXISTS signature_request (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    related_type VARCHAR(120),
    related_id INTEGER,
    signer_name VARCHAR(255),
    signer_email VARCHAR(255),
    document_title VARCHAR(255),
    document_type VARCHAR(120),
    file_path VARCHAR(500),
    status VARCHAR(100) DEFAULT 'Pending Signature',
    requested_by VARCHAR(120),
    requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    signed_by VARCHAR(255),
    signed_at DATETIME,
    signature_text VARCHAR(255),
    signature_ip VARCHAR(100),
    signature_hash VARCHAR(255),
    notes TEXT
)
""",
"""
CREATE TABLE IF NOT EXISTS signature_audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signature_request_id INTEGER,
    event_type VARCHAR(120),
    event_details TEXT,
    ip_address VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
"""
]

for stmt in statements:
    cur.execute(stmt)

conn.commit()
conn.close()
print(f"Phase 20 Client Portal & E-Signature migration complete: {db_path}")
