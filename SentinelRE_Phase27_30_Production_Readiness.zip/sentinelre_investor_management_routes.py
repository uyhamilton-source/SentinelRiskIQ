
# SentinelRE Phase 18 – Investor Management Routes

@app.route("/investors", methods=["GET", "POST"])
@login_required
def investors():
    if request.method == "POST":
        investor = Investor(
            investor_name=request.form.get("investor_name"),
            entity_name=request.form.get("entity_name"),
            email=request.form.get("email"),
            phone=request.form.get("phone"),
            investor_type=request.form.get("investor_type"),
            accredited_status=request.form.get("accredited_status"),
            target_property_type=request.form.get("target_property_type"),
            target_market=request.form.get("target_market"),
            investment_capacity=float(request.form.get("investment_capacity") or 0),
            risk_tolerance=request.form.get("risk_tolerance"),
            notes=request.form.get("notes")
        )
        db.session.add(investor)
        db.session.commit()
        flash("Investor record created.")
        return redirect(url_for("investors"))

    investors = Investor.query.order_by(Investor.created_at.desc()).all()
    return render_template("investors.html", investors=investors, brand=BRAND)


@app.route("/investor/<int:investor_id>")
@login_required
def investor_detail(investor_id):
    investor = Investor.query.get_or_404(investor_id)
    contacts = InvestorContact.query.filter_by(investor_id=investor_id).all()
    interactions = InvestorInteraction.query.filter_by(investor_id=investor_id).order_by(InvestorInteraction.created_at.desc()).all()
    preferences = InvestorPreference.query.filter_by(investor_id=investor_id).first()
    matches = InvestorOpportunityMatch.query.filter_by(investor_id=investor_id).order_by(InvestorOpportunityMatch.match_score.desc()).all()
    reports = InvestorReport.query.filter_by(investor_id=investor_id).order_by(InvestorReport.created_at.desc()).all()
    documents = InvestorDocument.query.filter_by(investor_id=investor_id).order_by(InvestorDocument.uploaded_at.desc()).all()
    return render_template("investor_detail.html", investor=investor, contacts=contacts, interactions=interactions, preferences=preferences, matches=matches, reports=reports, documents=documents, brand=BRAND)


@app.route("/investor/<int:investor_id>/interaction", methods=["POST"])
@login_required
def investor_add_interaction(investor_id):
    interaction = InvestorInteraction(
        investor_id=investor_id,
        interaction_type=request.form.get("interaction_type"),
        subject=request.form.get("subject"),
        notes=request.form.get("notes"),
        follow_up_required=bool(request.form.get("follow_up_required")),
        follow_up_date=request.form.get("follow_up_date") or None,
        created_by=current_user.username
    )
    db.session.add(interaction)
    db.session.commit()
    flash("Investor interaction added.")
    return redirect(url_for("investor_detail", investor_id=investor_id))


@app.route("/investor/<int:investor_id>/preferences", methods=["POST"])
@login_required
def investor_preferences(investor_id):
    pref = InvestorPreference.query.filter_by(investor_id=investor_id).first()
    if not pref:
        pref = InvestorPreference(investor_id=investor_id)
        db.session.add(pref)
    pref.target_markets = request.form.get("target_markets")
    pref.target_property_types = request.form.get("target_property_types")
    pref.min_investment = float(request.form.get("min_investment") or 0)
    pref.max_investment = float(request.form.get("max_investment") or 0)
    pref.preferred_hold_period = request.form.get("preferred_hold_period")
    pref.risk_profile = request.form.get("risk_profile")
    pref.return_target = request.form.get("return_target")
    pref.financing_preference = request.form.get("financing_preference")
    pref.notes = request.form.get("notes")
    db.session.commit()
    flash("Investor preferences updated.")
    return redirect(url_for("investor_detail", investor_id=investor_id))
