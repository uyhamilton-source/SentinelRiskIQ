
# SentinelRE Phase 27-30 Routes – Production Readiness

@app.route("/deployment-validation")
@login_required
def deployment_validation():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    results = RouteValidationResult.query.order_by(RouteValidationResult.tested_at.desc()).limit(50).all()
    return render_template("deployment_validation.html", results=results, brand=BRAND, page_title="Deployment Validation")


@app.route("/legal-readiness")
@login_required
def legal_readiness():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    controls = ESignComplianceControl.query.order_by(ESignComplianceControl.control_area.asc()).all()
    templates = LegalTemplateReview.query.order_by(LegalTemplateReview.created_at.desc()).all()
    return render_template("legal_readiness.html", controls=controls, templates=templates, brand=BRAND, page_title="Legal Readiness")


@app.route("/client-portal-security")
@login_required
def client_portal_security():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    policies = PortalAccessPolicy.query.order_by(PortalAccessPolicy.created_at.desc()).all()
    challenges = PortalMFAChallenge.query.order_by(PortalMFAChallenge.created_at.desc()).limit(25).all()
    tokens = SecureDocumentToken.query.order_by(SecureDocumentToken.created_at.desc()).limit(25).all()
    return render_template("client_portal_security.html", policies=policies, challenges=challenges, tokens=tokens, brand=BRAND, page_title="Client Portal Security")


@app.route("/ai-governance")
@login_required
def ai_governance():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    rules = AIDataClassificationRule.query.order_by(AIDataClassificationRule.classification.asc()).all()
    settings = AIGovernanceSetting.query.order_by(AIGovernanceSetting.setting_name.asc()).all()
    audits = AIPromptAuditLog.query.order_by(AIPromptAuditLog.created_at.desc()).limit(25).all()
    return render_template("ai_governance.html", rules=rules, settings=settings, audits=audits, brand=BRAND, page_title="AI Governance")
