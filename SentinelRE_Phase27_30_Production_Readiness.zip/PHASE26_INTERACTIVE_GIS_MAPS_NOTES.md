# SentinelRE Phase 26 – Interactive GIS Map Visualization

## Purpose
Upgrades Mapping/GIS from data tracking to interactive map visualization.

## Added

- Interactive Leaflet map
- Property markers from stored latitude/longitude
- Popup details for market area, zoning, flood zone, opportunity zone, walkability, notes
- Marker color logic:
  - Gold = opportunity zone
  - Orange = flood zone attention
  - Blue = standard property marker
- JSON map data endpoint
- GIS overlay library
- Market overlay table
- Migration script

## New Routes

- `/gis-map`
- `/gis-map-data`
- `/gis-overlays`

## New Tables

- map_view
- map_marker_note
- market_overlay

## Important Notes

This uses OpenStreetMap tiles through Leaflet. For enterprise/commercial deployment, consider:
- Mapbox
- Google Maps Platform
- ArcGIS
- Self-hosted map tiles
- Licensed flood/zoning/environmental datasets

## Deployment

1. Backup database.
2. Run: `python migrate_phase26_interactive_gis.py`
3. Restart app.
4. Open `/gis-map`
