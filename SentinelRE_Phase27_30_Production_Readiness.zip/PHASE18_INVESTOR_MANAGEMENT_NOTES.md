# SentinelRE Phase 18 – Investor Management

## Purpose
Adds investor relationship management to SentinelRE so the platform can support commercial real estate investors, family offices, probate property buyers, and acquisition groups.

## New Capabilities
- Investor records
- Investor contacts
- Investor preferences
- Investor interactions and follow-ups
- Investor opportunity/property matching
- Investor reports
- Investor document associations

## New Tables
- investor_contact
- investor_interaction
- investor_preference
- investor_opportunity_match
- investor_report
- investor_document

## Included Files
- migrate_phase18_investor_management.py
- sentinelre_investor_management_models.py
- sentinelre_investor_management_routes.py
- templates/investors.html
- templates/investor_detail.html

## Deployment
1. Backup the database.
2. Run: `python migrate_phase18_investor_management.py`
3. Merge models/routes into app.py if the current build uses a single-file architecture.
4. Restart the application.

## Recommended Next Build
Add automated investor/property matching based on:
- target market
- property type
- investment capacity
- risk tolerance
- preferred hold period
- return target
