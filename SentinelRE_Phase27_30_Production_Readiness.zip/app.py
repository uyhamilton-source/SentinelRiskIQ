
import io, json, os, secrets
from datetime import datetime, date, timedelta
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False

BASE_DIR = Path(__file__).resolve().parent
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY") or os.getenv("SENTINELRE_SECRET_KEY") or secrets.token_hex(32)
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR / 'sentinelre.db'}")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# SentinelRE Production Security Configuration
app.config["ENV"] = os.getenv("FLASK_ENV", "production")
app.config["DEBUG"] = False
app.config["TESTING"] = False
app.config["MAX_CONTENT_LENGTH"] = int(os.getenv("MAX_CONTENT_LENGTH", 16 * 1024 * 1024))  # 16 MB default upload limit
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.getenv("SESSION_COOKIE_SECURE", "true").lower() == "true"
app.config["UPLOAD_FOLDER"] = os.getenv("UPLOAD_FOLDER", str(BASE_DIR / "uploads"))
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

app.config["DOCUMENT_UPLOAD_FOLDER"] = os.getenv("DOCUMENT_UPLOAD_FOLDER", str(BASE_DIR / "uploads" / "documents"))
app.config["MAX_CONTENT_LENGTH"] = int(os.getenv("MAX_CONTENT_LENGTH", 25 * 1024 * 1024))
os.makedirs(app.config["DOCUMENT_UPLOAD_FOLDER"], exist_ok=True)
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

BRAND = {
    "company":"Sentinel Risk Compliance Group",
    "product":"SentinelRE™",
    "tagline":"Real Estate Operations Command Center",
    "platform_subtitle":"Manage real estate leads, property opportunities, broker approvals, agent workflows, document governance, and revenue operations."
}

# SentinelRE Governance & Security Engine™
# Least-privilege role definitions. The VA/Operations role can work records but cannot
# export client databases, administer users, view audit logs, or change system settings.
ROLE_PERMISSIONS = {
    "Owner/Broker": {
        "dashboard_view", "crm_view", "crm_edit", "opportunity_view", "opportunity_edit",
        "proposal_view", "proposal_edit", "client_view", "client_edit", "advisory_view",
        "advisory_edit", "renewal_view", "renewal_edit", "activity_view", "activity_edit",
        "kpi_view", "forecast_view", "automation_view", "automation_run", "email_view",
        "email_edit", "assessment_view", "assessment_edit", "export_reports", "export_clients",
        "export_financials", "export_all_data", "user_admin", "audit_view", "contractor_admin",
        "system_admin", "compliance_view", "compliance_edit", "compliance_admin", "document_view", "document_upload", "document_approve", "document_delete", "document_download", "document_admin"
    },
    "Operations Coordinator": {
        "dashboard_view", "crm_view", "crm_edit", "opportunity_view", "opportunity_edit",
        "proposal_view", "proposal_edit", "client_view", "client_edit", "advisory_view",
        "advisory_edit", "renewal_view", "renewal_edit", "activity_view", "activity_edit",
        "kpi_view", "automation_view", "email_view", "email_edit", "assessment_view", "compliance_view", "compliance_edit", "document_view", "document_upload", "document_download"
    },
    "Realtor / Agent": {
        "dashboard_view", "client_view", "client_edit", "advisory_view", "renewal_view",
        "activity_view", "activity_edit", "kpi_view", "assessment_view", "assessment_edit", "compliance_view", "compliance_edit",
        "proposal_view", "export_reports", "document_view", "document_upload", "document_download"
    },
    "Read Only": {
        "dashboard_view", "crm_view", "opportunity_view", "proposal_view", "client_view",
        "advisory_view", "renewal_view", "activity_view", "kpi_view", "assessment_view", "compliance_view", "document_view"
    }
}
ROLE_OPTIONS = list(ROLE_PERMISSIONS.keys())

def user_has_permission(user, permission):
    if not user or not getattr(user, "is_authenticated", False):
        return False
    return permission in ROLE_PERMISSIONS.get(getattr(user, "role", "Read Only"), set())

def require_permission(permission):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated:
                return login_manager.unauthorized()
            if not user_has_permission(current_user, permission):
                log_audit(action="Permission Denied", object_type="Route", object_id=request.path, result="Denied", new_value=permission)
                flash("Access denied. Your role does not have permission to perform that action.", "danger")
                return redirect(url_for("dashboard"))
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def role_label(role):
    return role if role in ROLE_PERMISSIONS else "Read Only"

def is_owner_broker():
    return current_user.is_authenticated and current_user.role == "Owner/Broker"

def is_operations_user():
    return current_user.is_authenticated and current_user.role == "Operations Coordinator"

def is_agent_user():
    return current_user.is_authenticated and current_user.role == "Realtor / Agent"

def allowed_document_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_DOCUMENT_EXTENSIONS

LIFECYCLE_STAGES = [
    "Lead", "Qualified", "Discovery Scheduled", "Snapshot Delivered", "Proposal Sent",
    "Assessment Sold", "Active Client", "Advisory Retainer", "Renewal", "Closed Lost"
]
PRIORITY_LEVELS = ["A - Immediate", "B - Nurture", "C - Archive"]
OFFER_TYPES = ["Property Risk Snapshot", "Property Readiness Review", "Commercial Property Review", "Transaction Readiness", "Advisory Retainer"]
OPPORTUNITY_STAGES = ["Discovery", "Snapshot Delivered", "Proposal Drafting", "Proposal Sent", "Negotiation", "Won", "Lost", "Deferred"]
PROPOSAL_STATUSES = ["Not Started", "Drafting", "Sent", "Approved", "Declined", "On Hold"]
PROPOSAL_TYPES = ["Property Risk Snapshot", "Property Readiness Review", "Commercial Property Review", "Transaction Readiness Assessment", "Broker Advisory Retainer"]
PROPOSAL_STATUSES_FULL = ["Draft", "Sent", "Accepted", "Declined", "Revision Requested", "On Hold"]
PAYMENT_TERMS = ["Due Upon Acceptance", "50% Upfront / 50% Upon Delivery", "Monthly Retainer", "Net 15", "Net 30"]
CLIENT_STATUS = ["Onboarding", "Active Assessment", "Report Delivered", "Roadmap Active", "Advisory Active", "Renewal Pending", "Paused", "Closed"]
LIFECYCLE_PHASES = ["Lead", "Discovery", "Snapshot", "Proposal", "Client", "Assessment", "Roadmap", "Advisory", "Renewal"]
REVIEW_CADENCE = ["Monthly", "Quarterly", "Semi-Annual", "Annual"]
ADVISORY_STATUS = ["Active", "Paused", "At Risk", "Cancelled", "Completed"]
BILLING_STATUS = ["Current", "Due Soon", "Overdue", "Paid", "Paused"]
ADVISORY_SERVICE_TYPES = ["Broker Advisory", "Transaction Readiness Advisory", "Roadmap Review", "Quarterly Risk Review", "Virtual Broker Operations Advisory"]
RENEWAL_STAGES = ["Upcoming", "Renewal Review", "Proposal Needed", "Proposal Sent", "Negotiation", "Renewed", "At Risk", "Lost", "Deferred"]
RENEWAL_TYPES = ["Advisory Retainer Renewal", "Annual Reassessment", "Quarterly Review Extension", "Transaction Readiness Continuation", "Expansion Opportunity"]
RENEWAL_RISK_LEVELS = ["Low", "Moderate", "High", "Critical"]
ACTIVITY_TYPES = ["Call", "Email", "LinkedIn", "Discovery Meeting", "Proposal Follow-Up", "Advisory Review", "Renewal Check-In", "Internal Note", "Task"]
ACTIVITY_OUTCOMES = ["Completed", "No Response", "Interested", "Not Interested", "Follow-Up Needed", "Meeting Scheduled", "Proposal Requested", "Client Issue", "Renewal Risk"]
ACTIVITY_PRIORITIES = ["Low", "Medium", "High", "Urgent"]
EMAIL_TRIGGER_TYPES = ["Discovery Invite", "Proposal Follow-Up", "Advisory Review Reminder", "Renewal Check-In", "General Follow-Up"]
EMAIL_STATUSES = ["Draft", "Queued", "Sent", "Skipped"]
DOCUMENT_CATEGORIES = [
    "Purchase Agreements", "Lease Agreements", "Appraisals", "Environmental Reports",
    "Inspection Reports", "Title Documents", "Insurance Documents", "Financial Statements",
    "Closing Packages", "Investor Reports", "Probate Documents", "Property Photos",
    "Due Diligence", "Other"
]
DOCUMENT_STATUSES = ["Pending Review", "Approved", "Archived", "Rejected"]
DOCUMENT_SENSITIVITY_LEVELS = ["Standard", "Confidential", "Restricted"]
ALLOWED_DOCUMENT_EXTENSIONS = {"pdf", "doc", "docx", "xls", "xlsx", "csv", "txt", "png", "jpg", "jpeg"}

# SentinelRE Phase 7 – Regulatory Readiness & Compliance Engine™
COMPLIANCE_DOMAINS = [
    "Licensing & Professional Governance",
    "Fair Housing Compliance",
    "AML / Transaction Integrity",
    "Transaction Governance",
    "Escrow & Financial Controls",
    "Records & Document Governance",
    "Operational Resilience",
]
COMPLIANCE_STATUS_LEVELS = ["Not Started", "In Progress", "Ready", "Needs Attention", "High Risk"]
COMPLIANCE_RISK_LEVELS = ["Low", "Moderate", "High", "Critical"]

# SentinelRE Phase 8/9/10 – expanded compliance engines
LICENSE_TYPES = ["Broker License", "Sales Associate License", "Attorney License", "Property Manager Credential", "Other"]
LICENSE_STATUSES = ["Active", "Expiring Soon", "Expired", "Suspended", "Inactive"]
CE_STATUSES = ["Not Started", "In Progress", "Completed", "Overdue"]
AML_REVIEW_STATUSES = ["Pending Review", "Cleared", "Enhanced Due Diligence Required", "Escalated", "Closed"]
TRANSACTION_REVIEW_STATUSES = ["Draft", "Under Review", "Ready for Broker Review", "Cleared", "Exception Found", "Closed"]
PROBATE_MATTER_STATUSES = ["Intake", "Inventory", "Court Filings", "Property Disposition", "Beneficiary Review", "Closing", "Closed"]
PROBATE_RISK_LEVELS = ["Low", "Moderate", "High", "Critical"]

def readiness_band(score):
    try:
        score = float(score or 0)
    except Exception:
        score = 0
    if score >= 85:
        return "Ready"
    if score >= 70:
        return "Mostly Ready"
    if score >= 50:
        return "Needs Attention"
    return "High Risk"


QUESTIONS = [
    ("ideal_client_fit","Client Fit","How closely does this prospect match SentinelRE's target real estate, commercial property, broker, investor, or attorney profile?"),
    ("decision_maker","Decision Access","How clearly have we identified and reached the right decision-maker?"),
    ("pain_signal","Business Need","How strong is the prospect's real estate governance, compliance, transaction readiness, or operational risk need?"),
    ("budget_fit","Commercial Fit","How likely is the prospect to afford a paid property review, transaction readiness review, or broker advisory engagement?"),
    ("timeline","Timing","How soon could this prospect reasonably move from interest to a paid engagement?"),
    ("next_step","Next Step Clarity","How clear is the next action needed to move this opportunity forward?"),
]
SCORE_MAP = {"Strong":1,"Moderate":2,"Limited":3,"Unknown":3}
FRAMEWORK_MAP = {
    "Client Fit":"ICP / Target Market Fit",
    "Decision Access":"Business Development / Buying Committee",
    "Business Need":"Risk Signal / Problem Urgency",
    "Commercial Fit":"Pricing / Revenue Potential",
    "Timing":"Sales Cycle / Close Probability",
    "Next Step Clarity":"Pipeline Hygiene / Follow-Up Discipline",
}

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(255))
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(50), nullable=False, default="Read Only")
    active = db.Column(db.Boolean, default=True)
    nda_signed = db.Column(db.Boolean, default=False)
    ip_agreement_signed = db.Column(db.Boolean, default=False)
    security_training_completed = db.Column(db.Boolean, default=False)
    access_approved = db.Column(db.Boolean, default=False)
    last_login_at = db.Column(db.DateTime)
    last_login_ip = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    def set_password(self, password): self.password_hash = generate_password_hash(password)
    def check_password(self, password): return check_password_hash(self.password_hash, password)
    @property
    def onboarding_complete(self):
        return self.role == "Owner/Broker" or (self.nda_signed and self.ip_agreement_signed and self.security_training_completed and self.access_approved)
    @property
    def can_access_system(self):
        return self.active and (self.role == "Owner/Broker" or self.onboarding_complete)

class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    username = db.Column(db.String(120))
    role = db.Column(db.String(80))
    action = db.Column(db.String(160), nullable=False)
    object_type = db.Column(db.String(120))
    object_id = db.Column(db.String(120))
    old_value = db.Column(db.Text)
    new_value = db.Column(db.Text)
    ip_address = db.Column(db.String(100))
    result = db.Column(db.String(80), default="Success")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class ContractorAgreement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    user = db.relationship("User", backref=db.backref("contractor_agreements", lazy=True))
    contractor_name = db.Column(db.String(255), nullable=False)
    contractor_email = db.Column(db.String(255))
    role_requested = db.Column(db.String(80), default="Operations Coordinator")
    nda_signed = db.Column(db.Boolean, default=False)
    ip_agreement_signed = db.Column(db.Boolean, default=False)
    non_solicitation_acknowledged = db.Column(db.Boolean, default=False)
    security_training_completed = db.Column(db.Boolean, default=False)
    access_approved = db.Column(db.Boolean, default=False)
    approved_by = db.Column(db.String(120))
    signed_date = db.Column(db.String(100))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

def log_audit(action, object_type=None, object_id=None, old_value=None, new_value=None, result="Success"):
    try:
        user_id = current_user.id if current_user.is_authenticated else None
        username = current_user.username if current_user.is_authenticated else request.form.get("username", "anonymous")
        role = current_user.role if current_user.is_authenticated else "Unauthenticated"
        entry = AuditLog(
            user_id=user_id, username=username, role=role, action=action, object_type=object_type,
            object_id=str(object_id) if object_id is not None else None, old_value=old_value,
            new_value=new_value, ip_address=request.headers.get("X-Forwarded-For", request.remote_addr), result=result
        )
        db.session.add(entry)
    except Exception:
        pass

def safe_commit(action=None, object_type=None, object_id=None, old_value=None, new_value=None):
    if action:
        log_audit(action=action, object_type=object_type, object_id=object_id, old_value=old_value, new_value=new_value)
    db.session.commit()

class Lead(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_name = db.Column(db.String(255), nullable=False)
    contact_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    phone = db.Column(db.String(100))
    industry = db.Column(db.String(150))
    state = db.Column(db.String(80))
    lead_source = db.Column(db.String(150))
    stage = db.Column(db.String(100), default="Lead")
    priority = db.Column(db.String(100), default="B - Nurture")
    recommended_offer = db.Column(db.String(150), default="Property Risk Snapshot")
    probability = db.Column(db.Float, default=0.25)
    estimated_value = db.Column(db.Float, default=0.0)
    monthly_retainer = db.Column(db.Float, default=0.0)
    next_follow_up = db.Column(db.String(100))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Opportunity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lead_id = db.Column(db.Integer, db.ForeignKey("lead.id"), nullable=True)
    lead = db.relationship("Lead", backref=db.backref("opportunities", lazy=True))
    company_name = db.Column(db.String(255), nullable=False)
    contact_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    phone = db.Column(db.String(100))
    industry = db.Column(db.String(150))
    service_type = db.Column(db.String(150), default="Property Risk Snapshot")
    opportunity_stage = db.Column(db.String(100), default="Discovery")
    proposal_status = db.Column(db.String(100), default="Not Started")
    estimated_value = db.Column(db.Float, default=0.0)
    probability = db.Column(db.Float, default=0.25)
    expected_close_date = db.Column(db.String(100))
    monthly_retainer = db.Column(db.Float, default=0.0)
    next_step = db.Column(db.String(255))
    owner = db.Column(db.String(100))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def weighted_value(self):
        return (self.estimated_value or 0) * (self.probability or 0)


class Proposal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    opportunity_id = db.Column(db.Integer, db.ForeignKey("opportunity.id"), nullable=True)
    opportunity = db.relationship("Opportunity", backref=db.backref("proposals", lazy=True))
    proposal_number = db.Column(db.String(80), unique=True, nullable=False)
    client_name = db.Column(db.String(255), nullable=False)
    contact_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    industry = db.Column(db.String(150))
    proposal_type = db.Column(db.String(150), default="Property Readiness Review")
    status = db.Column(db.String(100), default="Draft")
    scope = db.Column(db.Text)
    deliverables = db.Column(db.Text)
    timeline = db.Column(db.String(255), default="10 business days")
    one_time_fee = db.Column(db.Float, default=0.0)
    monthly_retainer = db.Column(db.Float, default=0.0)
    payment_terms = db.Column(db.String(150), default="50% Upfront / 50% Upon Delivery")
    valid_until = db.Column(db.String(100))
    next_step = db.Column(db.String(255))
    prepared_by = db.Column(db.String(120))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    approval_status = db.Column(db.String(100), default="Draft")
    executive_approval_required = db.Column(db.Boolean, default=True)
    approved_by = db.Column(db.String(120))
    approved_at = db.Column(db.DateTime)
    approval_notes = db.Column(db.Text)
    pricing_locked = db.Column(db.Boolean, default=False)
    pricing_set_by = db.Column(db.String(120))
    pricing_set_at = db.Column(db.DateTime)
    sent_by = db.Column(db.String(120))
    sent_at = db.Column(db.DateTime)

    @property
    def total_first_year_value(self):
        return (self.one_time_fee or 0) + ((self.monthly_retainer or 0) * 12)

class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lead_id = db.Column(db.Integer, db.ForeignKey("lead.id"), nullable=True)
    lead = db.relationship("Lead", backref=db.backref("clients", lazy=True))
    opportunity_id = db.Column(db.Integer, db.ForeignKey("opportunity.id"), nullable=True)
    opportunity = db.relationship("Opportunity", backref=db.backref("clients", lazy=True))
    proposal_id = db.Column(db.Integer, db.ForeignKey("proposal.id"), nullable=True)
    proposal = db.relationship("Proposal", backref=db.backref("clients", lazy=True))
    client_name = db.Column(db.String(255), nullable=False)
    contact_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    phone = db.Column(db.String(100))
    industry = db.Column(db.String(150))
    lifecycle_phase = db.Column(db.String(100), default="Client")
    client_status = db.Column(db.String(100), default="Onboarding")
    service_package = db.Column(db.String(150), default="Property Readiness Review")
    start_date = db.Column(db.String(100))
    assessment_due_date = db.Column(db.String(100))
    report_due_date = db.Column(db.String(100))
    roadmap_review_date = db.Column(db.String(100))
    next_advisory_session = db.Column(db.String(100))
    renewal_date = db.Column(db.String(100))
    monthly_retainer = db.Column(db.Float, default=0.0)
    total_contract_value = db.Column(db.Float, default=0.0)
    review_cadence = db.Column(db.String(80), default="Quarterly")
    owner = db.Column(db.String(100))
    open_actions = db.Column(db.Integer, default=0)
    risk_priority = db.Column(db.String(80), default="Moderate")
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def annual_recurring_value(self):
        return (self.monthly_retainer or 0) * 12

    @property
    def lifecycle_summary(self):
        return f"{self.lifecycle_phase} / {self.client_status}"


class DocumentCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    description = db.Column(db.Text)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=True)
    client = db.relationship("Client", backref=db.backref("documents", lazy=True))
    opportunity_id = db.Column(db.Integer, db.ForeignKey("opportunity.id"), nullable=True)
    opportunity = db.relationship("Opportunity", backref=db.backref("documents", lazy=True))
    proposal_id = db.Column(db.Integer, db.ForeignKey("proposal.id"), nullable=True)
    proposal = db.relationship("Proposal", backref=db.backref("documents", lazy=True))

    property_name = db.Column(db.String(255))
    property_address = db.Column(db.String(255))
    document_title = db.Column(db.String(255), nullable=False)
    document_type = db.Column(db.String(150), default="Other")
    category = db.Column(db.String(150), default="Other")
    sensitivity = db.Column(db.String(80), default="Standard")
    status = db.Column(db.String(80), default="Pending Review")
    version = db.Column(db.Integer, default=1)

    original_filename = db.Column(db.String(255), nullable=False)
    stored_filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    file_size = db.Column(db.Integer, default=0)
    mime_type = db.Column(db.String(150))

    uploaded_by = db.Column(db.String(120))
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    approved_by = db.Column(db.String(120))
    approved_at = db.Column(db.DateTime)
    approval_notes = db.Column(db.Text)
    retention_date = db.Column(db.String(100))
    notes = db.Column(db.Text)
    active = db.Column(db.Boolean, default=True)

    @property
    def related_record(self):
        if self.client:
            return f"Client: {self.client.client_name}"
        if self.opportunity:
            return f"Opportunity: {self.opportunity.company_name}"
        if self.proposal:
            return f"Proposal: {self.proposal.proposal_number}"
        if self.property_name:
            return f"Property: {self.property_name}"
        return "General Repository"


class DocumentVersion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey("document.id"), nullable=False)
    document = db.relationship("Document", backref=db.backref("versions", lazy=True))
    version = db.Column(db.Integer, default=1)
    original_filename = db.Column(db.String(255))
    stored_filename = db.Column(db.String(255))
    file_path = db.Column(db.String(500))
    uploaded_by = db.Column(db.String(120))
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)


class DocumentAccessLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey("document.id"), nullable=True)
    document = db.relationship("Document", backref=db.backref("access_logs", lazy=True))
    username = db.Column(db.String(120))
    role = db.Column(db.String(80))
    action = db.Column(db.String(120), nullable=False)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    result = db.Column(db.String(80), default="Success")


class RegulatoryReadinessAssessment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=True)
    client = db.relationship("Client", backref=db.backref("regulatory_assessments", lazy=True))
    opportunity_id = db.Column(db.Integer, db.ForeignKey("opportunity.id"), nullable=True)
    opportunity = db.relationship("Opportunity", backref=db.backref("regulatory_assessments", lazy=True))
    property_name = db.Column(db.String(255))
    property_address = db.Column(db.String(255))
    organization_name = db.Column(db.String(255), nullable=False)
    contact_name = db.Column(db.String(255))
    compliance_profile = db.Column(db.String(150), default="Brokerage / CRE")
    overall_score = db.Column(db.Float, default=0.0)
    readiness_status = db.Column(db.String(100), default="Needs Attention")
    licensing_score = db.Column(db.Float, default=0.0)
    fair_housing_score = db.Column(db.Float, default=0.0)
    aml_score = db.Column(db.Float, default=0.0)
    transaction_governance_score = db.Column(db.Float, default=0.0)
    escrow_controls_score = db.Column(db.Float, default=0.0)
    records_governance_score = db.Column(db.Float, default=0.0)
    operational_resilience_score = db.Column(db.Float, default=0.0)
    risk_level = db.Column(db.String(80), default="Moderate")
    priority_findings = db.Column(db.Text)
    corrective_actions = db.Column(db.Text)
    owner = db.Column(db.String(120))
    next_review_date = db.Column(db.String(100))
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def score_breakdown(self):
        return [
            ("Licensing", self.licensing_score or 0),
            ("Fair Housing", self.fair_housing_score or 0),
            ("AML", self.aml_score or 0),
            ("Transaction Governance", self.transaction_governance_score or 0),
            ("Escrow Controls", self.escrow_controls_score or 0),
            ("Records Governance", self.records_governance_score or 0),
            ("Operational Resilience", self.operational_resilience_score or 0),
        ]


class ComplianceActionItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    assessment_id = db.Column(db.Integer, db.ForeignKey("regulatory_readiness_assessment.id"), nullable=True)
    assessment = db.relationship("RegulatoryReadinessAssessment", backref=db.backref("action_items", lazy=True))
    domain = db.Column(db.String(150), nullable=False)
    requirement = db.Column(db.String(255), nullable=False)
    risk_level = db.Column(db.String(80), default="Moderate")
    status = db.Column(db.String(100), default="Open")
    owner = db.Column(db.String(120))
    due_date = db.Column(db.String(100))
    notes = db.Column(db.Text)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    closed_at = db.Column(db.DateTime)



class LicenseCredential(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    user = db.relationship("User", backref=db.backref("license_credentials", lazy=True))
    professional_name = db.Column(db.String(255), nullable=False)
    role_type = db.Column(db.String(100), default="Realtor / Agent")
    license_type = db.Column(db.String(120), default="Sales Associate License")
    license_number = db.Column(db.String(120))
    issuing_state = db.Column(db.String(80), default="Florida")
    status = db.Column(db.String(80), default="Active")
    issue_date = db.Column(db.String(100))
    expiration_date = db.Column(db.String(100))
    ce_required_hours = db.Column(db.Float, default=0.0)
    ce_completed_hours = db.Column(db.Float, default=0.0)
    ce_status = db.Column(db.String(80), default="Not Started")
    disciplinary_flag = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text)
    owner = db.Column(db.String(120))
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def ce_completion_rate(self):
        if not self.ce_required_hours:
            return 0
        return min(100, round((self.ce_completed_hours or 0) / max(self.ce_required_hours, 1) * 100, 1))


class ContinuingEducationRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    license_id = db.Column(db.Integer, db.ForeignKey("license_credential.id"), nullable=True)
    license = db.relationship("LicenseCredential", backref=db.backref("ce_records", lazy=True))
    professional_name = db.Column(db.String(255), nullable=False)
    course_name = db.Column(db.String(255), nullable=False)
    provider = db.Column(db.String(255))
    hours = db.Column(db.Float, default=0.0)
    completion_date = db.Column(db.String(100))
    certificate_document_id = db.Column(db.Integer, db.ForeignKey("document.id"), nullable=True)
    status = db.Column(db.String(80), default="Completed")
    notes = db.Column(db.Text)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AMLTransactionReview(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=True)
    client = db.relationship("Client", backref=db.backref("aml_reviews", lazy=True))
    opportunity_id = db.Column(db.Integer, db.ForeignKey("opportunity.id"), nullable=True)
    opportunity = db.relationship("Opportunity", backref=db.backref("aml_reviews", lazy=True))
    transaction_name = db.Column(db.String(255), nullable=False)
    property_address = db.Column(db.String(255))
    buyer_name = db.Column(db.String(255))
    seller_name = db.Column(db.String(255))
    transaction_value = db.Column(db.Float, default=0.0)
    cash_transaction = db.Column(db.Boolean, default=False)
    foreign_buyer = db.Column(db.Boolean, default=False)
    entity_buyer = db.Column(db.Boolean, default=False)
    beneficial_owner_verified = db.Column(db.Boolean, default=False)
    source_of_funds_verified = db.Column(db.Boolean, default=False)
    high_risk_jurisdiction = db.Column(db.Boolean, default=False)
    suspicious_activity_flags = db.Column(db.Text)
    risk_score = db.Column(db.Float, default=0.0)
    review_status = db.Column(db.String(100), default="Pending Review")
    escalation_required = db.Column(db.Boolean, default=False)
    reviewed_by = db.Column(db.String(120))
    reviewed_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class TransactionGovernanceReview(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=True)
    opportunity_id = db.Column(db.Integer, db.ForeignKey("opportunity.id"), nullable=True)
    transaction_name = db.Column(db.String(255), nullable=False)
    property_address = db.Column(db.String(255))
    contract_complete = db.Column(db.Boolean, default=False)
    disclosures_complete = db.Column(db.Boolean, default=False)
    inspection_complete = db.Column(db.Boolean, default=False)
    appraisal_complete = db.Column(db.Boolean, default=False)
    title_review_complete = db.Column(db.Boolean, default=False)
    escrow_review_complete = db.Column(db.Boolean, default=False)
    closing_package_complete = db.Column(db.Boolean, default=False)
    exceptions = db.Column(db.Text)
    readiness_score = db.Column(db.Float, default=0.0)
    review_status = db.Column(db.String(100), default="Draft")
    broker_review_required = db.Column(db.Boolean, default=True)
    reviewed_by = db.Column(db.String(120))
    reviewed_at = db.Column(db.DateTime)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ProbateMatter(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    matter_name = db.Column(db.String(255), nullable=False)
    estate_name = db.Column(db.String(255))
    attorney_name = db.Column(db.String(255))
    court_name = db.Column(db.String(255))
    case_number = db.Column(db.String(120))
    property_address = db.Column(db.String(255))
    personal_representative = db.Column(db.String(255))
    beneficiary_count = db.Column(db.Integer, default=0)
    inventory_completed = db.Column(db.Boolean, default=False)
    court_filings_current = db.Column(db.Boolean, default=False)
    beneficiary_notice_complete = db.Column(db.Boolean, default=False)
    property_disposition_plan = db.Column(db.Boolean, default=False)
    title_review_complete = db.Column(db.Boolean, default=False)
    risk_level = db.Column(db.String(80), default="Moderate")
    readiness_score = db.Column(db.Float, default=0.0)
    status = db.Column(db.String(100), default="Intake")
    next_action = db.Column(db.String(255))
    next_deadline = db.Column(db.String(100))
    notes = db.Column(db.Text)
    owner = db.Column(db.String(120))
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AdvisoryEngagement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=True)
    client = db.relationship("Client", backref=db.backref("advisory_engagements", lazy=True))
    client_name = db.Column(db.String(255), nullable=False)
    contact_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    service_type = db.Column(db.String(150), default="Broker Advisory")
    status = db.Column(db.String(80), default="Active")
    billing_status = db.Column(db.String(80), default="Current")
    monthly_fee = db.Column(db.Float, default=0.0)
    start_date = db.Column(db.String(100))
    next_invoice_date = db.Column(db.String(100))
    last_payment_date = db.Column(db.String(100))
    next_review_date = db.Column(db.String(100))
    renewal_date = db.Column(db.String(100))
    review_cadence = db.Column(db.String(80), default="Monthly")
    owner = db.Column(db.String(100))
    open_actions = db.Column(db.Integer, default=0)
    health_status = db.Column(db.String(80), default="Stable")
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def annual_value(self):
        return (self.monthly_fee or 0) * 12

    @property
    def is_active_revenue(self):
        return self.status == "Active" and self.billing_status not in ["Paused"]

class RenewalRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=True)
    client = db.relationship("Client", backref=db.backref("renewal_records", lazy=True))
    advisory_id = db.Column(db.Integer, db.ForeignKey("advisory_engagement.id"), nullable=True)
    advisory = db.relationship("AdvisoryEngagement", backref=db.backref("renewal_records", lazy=True))
    client_name = db.Column(db.String(255), nullable=False)
    contact_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    renewal_type = db.Column(db.String(150), default="Advisory Retainer Renewal")
    renewal_stage = db.Column(db.String(100), default="Upcoming")
    renewal_date = db.Column(db.String(100))
    reminder_date = db.Column(db.String(100))
    current_monthly_fee = db.Column(db.Float, default=0.0)
    proposed_monthly_fee = db.Column(db.Float, default=0.0)
    current_annual_value = db.Column(db.Float, default=0.0)
    renewal_value = db.Column(db.Float, default=0.0)
    probability = db.Column(db.Float, default=0.75)
    risk_level = db.Column(db.String(80), default="Moderate")
    health_status = db.Column(db.String(80), default="Stable")
    owner = db.Column(db.String(100))
    next_step = db.Column(db.String(255))
    outcome = db.Column(db.String(120))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def weighted_renewal_value(self):
        return (self.renewal_value or self.current_annual_value or 0) * (self.probability or 0)

    @property
    def projected_mrr(self):
        return self.proposed_monthly_fee or self.current_monthly_fee or 0


class ActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lead_id = db.Column(db.Integer, db.ForeignKey("lead.id"), nullable=True)
    lead = db.relationship("Lead", backref=db.backref("activities", lazy=True))
    opportunity_id = db.Column(db.Integer, db.ForeignKey("opportunity.id"), nullable=True)
    opportunity = db.relationship("Opportunity", backref=db.backref("activities", lazy=True))
    proposal_id = db.Column(db.Integer, db.ForeignKey("proposal.id"), nullable=True)
    proposal = db.relationship("Proposal", backref=db.backref("activities", lazy=True))
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=True)
    client = db.relationship("Client", backref=db.backref("activities", lazy=True))
    advisory_id = db.Column(db.Integer, db.ForeignKey("advisory_engagement.id"), nullable=True)
    advisory = db.relationship("AdvisoryEngagement", backref=db.backref("activities", lazy=True))
    activity_date = db.Column(db.String(100), default=lambda: date.today().isoformat())
    activity_type = db.Column(db.String(120), default="Call")
    subject = db.Column(db.String(255), nullable=False)
    related_name = db.Column(db.String(255))
    contact_name = db.Column(db.String(255))
    outcome = db.Column(db.String(120), default="Completed")
    priority = db.Column(db.String(80), default="Medium")
    next_follow_up = db.Column(db.String(100))
    owner = db.Column(db.String(120))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def is_open_follow_up(self):
        return bool(self.next_follow_up) and self.outcome in ["Follow-Up Needed", "No Response", "Interested", "Proposal Requested", "Renewal Risk"]


class WorkflowAutomationRun(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    run_date = db.Column(db.DateTime, default=datetime.utcnow)
    run_type = db.Column(db.String(120), default="Manual")
    triggered_by = db.Column(db.String(120))
    actions_created = db.Column(db.Integer, default=0)
    clients_created = db.Column(db.Integer, default=0)
    advisory_created = db.Column(db.Integer, default=0)
    renewals_created = db.Column(db.Integer, default=0)
    opportunities_created = db.Column(db.Integer, default=0)
    status = db.Column(db.String(80), default="Completed")
    summary_json = db.Column(db.Text)
    notes = db.Column(db.Text)

class EmailTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    template_name = db.Column(db.String(160), unique=True, nullable=False)
    trigger_type = db.Column(db.String(120), nullable=False)
    subject_template = db.Column(db.String(255), nullable=False)
    body_template = db.Column(db.Text, nullable=False)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class EmailAutomationLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lead_id = db.Column(db.Integer, db.ForeignKey("lead.id"), nullable=True)
    lead = db.relationship("Lead", backref=db.backref("email_logs", lazy=True))
    opportunity_id = db.Column(db.Integer, db.ForeignKey("opportunity.id"), nullable=True)
    opportunity = db.relationship("Opportunity", backref=db.backref("email_logs", lazy=True))
    proposal_id = db.Column(db.Integer, db.ForeignKey("proposal.id"), nullable=True)
    proposal = db.relationship("Proposal", backref=db.backref("email_logs", lazy=True))
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=True)
    client = db.relationship("Client", backref=db.backref("email_logs", lazy=True))
    advisory_id = db.Column(db.Integer, db.ForeignKey("advisory_engagement.id"), nullable=True)
    advisory = db.relationship("AdvisoryEngagement", backref=db.backref("email_logs", lazy=True))
    renewal_id = db.Column(db.Integer, db.ForeignKey("renewal_record.id"), nullable=True)
    renewal = db.relationship("RenewalRecord", backref=db.backref("email_logs", lazy=True))
    trigger_type = db.Column(db.String(120), default="General Follow-Up")
    recipient_name = db.Column(db.String(255))
    recipient_email = db.Column(db.String(255))
    related_name = db.Column(db.String(255))
    subject = db.Column(db.String(255), nullable=False)
    body = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(80), default="Queued")
    due_date = db.Column(db.String(100), default=lambda: date.today().isoformat())
    sent_at = db.Column(db.DateTime)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)

    @property
    def mailto_link(self):
        from urllib.parse import quote
        if not self.recipient_email:
            return "#"
        return f"mailto:{self.recipient_email}?subject={quote(self.subject or '')}&body={quote(self.body or '')}"

class Assessment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_name = db.Column(db.String(255), nullable=False)
    business_type = db.Column(db.String(255), nullable=False)
    advisor = db.Column(db.String(255), nullable=False)
    annual_transactions = db.Column(db.Integer, default=0)
    avg_transaction_value = db.Column(db.Float, default=0.0)
    revenue_per_day = db.Column(db.Float, default=0.0)
    downtime_days = db.Column(db.Integer, default=1)
    overall_level = db.Column(db.String(50), nullable=False)
    overall_score = db.Column(db.Float, nullable=False)
    exposure = db.Column(db.Float, default=0.0)
    downtime_loss = db.Column(db.Float, default=0.0)
    findings_json = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id): return db.session.get(User, int(user_id))

@app.context_processor
def inject_brand(): return {"BRAND": BRAND, "has_perm": user_has_permission, "ROLE_OPTIONS": ROLE_OPTIONS}


def parse_date_safe(value):
    """Parse common ISO date strings and simple relative dates used in SentinelRE forms.

    Supported examples: 2026-06-10, 06/10/2026, 30 days, 45 days, 12 months,
    90 days before renewal. Relative dates are interpreted from today so early demo
    and pipeline records still feed forecasts, renewal risk, and trend analytics.
    """
    if not value:
        return None
    if isinstance(value, date):
        return value
    text = str(value).strip().lower()
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m-%d-%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except Exception:
            pass
    import re
    m = re.search(r"(\d+)\s*(day|days|month|months|week|weeks)", text)
    if m:
        n = int(m.group(1))
        unit = m.group(2)
        if unit.startswith("day"):
            return date.today() + timedelta(days=n)
        if unit.startswith("week"):
            return date.today() + timedelta(weeks=n)
        if unit.startswith("month"):
            return date.today() + timedelta(days=30*n)
    return None

def in_forecast_window(value, days):
    """Return True when a date is blank or falls within the requested forecast window.
    Blank dates are included because early-stage opportunities often lack a confirmed close date.
    """
    d = parse_date_safe(value)
    if d is None:
        return True
    today = date.today()
    return today <= d <= today + timedelta(days=days)


# SentinelRE Phase 17 – Property-Centric Data Model

class Property(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_name = db.Column(db.String(255), nullable=False)
    property_type = db.Column(db.String(120))
    address = db.Column(db.String(255))
    city = db.Column(db.String(120))
    state = db.Column(db.String(50))
    zip_code = db.Column(db.String(20))
    county = db.Column(db.String(120))
    owner_name = db.Column(db.String(255))
    broker_owner = db.Column(db.String(120))
    assigned_agent = db.Column(db.String(120))
    operations_owner = db.Column(db.String(120))
    square_feet = db.Column(db.Float)
    units = db.Column(db.Integer)
    acreage = db.Column(db.Float)
    year_built = db.Column(db.Integer)
    occupancy_rate = db.Column(db.Float)
    purchase_price = db.Column(db.Float)
    estimated_value = db.Column(db.Float)
    noi = db.Column(db.Float)
    cap_rate = db.Column(db.Float)
    property_status = db.Column(db.String(100), default="Active")
    risk_score = db.Column(db.Float, default=0)
    compliance_score = db.Column(db.Float, default=0)
    document_readiness_score = db.Column(db.Float, default=0)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyTransaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    transaction_name = db.Column(db.String(255), nullable=False)
    transaction_type = db.Column(db.String(100))
    stage = db.Column(db.String(100), default="Prospect")
    buyer_name = db.Column(db.String(255))
    seller_name = db.Column(db.String(255))
    tenant_name = db.Column(db.String(255))
    landlord_name = db.Column(db.String(255))
    transaction_value = db.Column(db.Float)
    commission_estimate = db.Column(db.Float)
    expected_close_date = db.Column(db.Date)
    closing_date = db.Column(db.Date)
    compliance_status = db.Column(db.String(100), default="Pending Review")
    document_status = db.Column(db.String(100), default="Incomplete")
    approval_status = db.Column(db.String(100), default="Draft")
    approved_by = db.Column(db.String(120))
    approved_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class LeaseRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    tenant_name = db.Column(db.String(255))
    lease_type = db.Column(db.String(100))
    lease_status = db.Column(db.String(100), default="Active")
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    monthly_rent = db.Column(db.Float)
    annual_rent = db.Column(db.Float)
    square_feet_leased = db.Column(db.Float)
    renewal_option = db.Column(db.String(255))
    expiration_risk = db.Column(db.String(100), default="Normal")
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Investor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_name = db.Column(db.String(255), nullable=False)
    entity_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    phone = db.Column(db.String(80))
    investor_type = db.Column(db.String(120))
    accredited_status = db.Column(db.String(120))
    target_property_type = db.Column(db.String(120))
    target_market = db.Column(db.String(120))
    investment_capacity = db.Column(db.Float)
    risk_tolerance = db.Column(db.String(100))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyInvestor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    ownership_percentage = db.Column(db.Float)
    investment_amount = db.Column(db.Float)
    role = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyRiskScore(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    environmental_risk = db.Column(db.Float, default=0)
    insurance_risk = db.Column(db.Float, default=0)
    vacancy_risk = db.Column(db.Float, default=0)
    tenant_risk = db.Column(db.Float, default=0)
    market_risk = db.Column(db.Float, default=0)
    legal_title_risk = db.Column(db.Float, default=0)
    document_risk = db.Column(db.Float, default=0)
    overall_property_risk = db.Column(db.Float, default=0)
    risk_level = db.Column(db.String(50), default="Not Scored")
    recommendations = db.Column(db.Text)
    scored_by = db.Column(db.String(120))
    scored_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyComplianceChecklist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    licensing_review = db.Column(db.Boolean, default=False)
    fair_housing_review = db.Column(db.Boolean, default=False)
    aml_review = db.Column(db.Boolean, default=False)
    disclosure_review = db.Column(db.Boolean, default=False)
    escrow_review = db.Column(db.Boolean, default=False)
    title_review = db.Column(db.Boolean, default=False)
    inspection_review = db.Column(db.Boolean, default=False)
    insurance_review = db.Column(db.Boolean, default=False)
    compliance_score = db.Column(db.Float, default=0)
    status = db.Column(db.String(100), default="Incomplete")
    reviewed_by = db.Column(db.String(120))
    reviewed_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


def build_revenue_forecast(opportunities, proposals, advisory_engagements, renewals, salary_target=8000):
    """SentinelRE Revenue Forecast Engine™.

    Forecasts expected one-time revenue, renewal revenue, and recurring revenue potential
    using weighted pipeline values, proposal status, advisory MRR, and renewal probability.
    """
    active_opps = [o for o in opportunities if o.opportunity_stage not in ["Won", "Lost", "Deferred"]]
    active_props = [p for p in proposals if p.status not in ["Declined", "On Hold"]]
    active_advisory = [a for a in advisory_engagements if a.status == "Active" and a.billing_status != "Paused"]
    open_renewals = [r for r in renewals if r.renewal_stage not in ["Renewed", "Lost", "Deferred"]]

    current_mrr = sum((a.monthly_fee or 0) for a in active_advisory)
    current_arr = current_mrr * 12

    def opp_weighted(days):
        return sum(o.weighted_value for o in active_opps if in_forecast_window(o.expected_close_date, days))

    def proposal_weighted(days):
        total = 0
        for p in active_props:
            # Accepted proposals are treated as high-confidence, sent proposals as likely, drafts as lower confidence.
            if p.status == "Accepted":
                probability = 1.0
            elif p.status == "Sent":
                probability = 0.70
            elif p.status == "Revision Requested":
                probability = 0.60
            else:
                probability = 0.35
            if in_forecast_window(p.valid_until, days):
                total += (p.one_time_fee or 0) * probability
        return total

    def renewal_weighted(days):
        return sum(r.weighted_renewal_value for r in open_renewals if in_forecast_window(r.renewal_date, days))

    def new_mrr_weighted(days):
        opp_mrr = sum((o.monthly_retainer or 0) * (o.probability or 0) for o in active_opps if in_forecast_window(o.expected_close_date, days))
        prop_mrr = 0
        for p in active_props:
            if p.status == "Accepted":
                probability = 1.0
            elif p.status == "Sent":
                probability = 0.70
            elif p.status == "Revision Requested":
                probability = 0.60
            else:
                probability = 0.35
            if in_forecast_window(p.valid_until, days):
                prop_mrr += (p.monthly_retainer or 0) * probability
        renewal_mrr = sum((r.projected_mrr or 0) * (r.probability or 0) for r in open_renewals if in_forecast_window(r.renewal_date, days))
        return opp_mrr + prop_mrr + renewal_mrr

    forecast_30 = opp_weighted(30) + proposal_weighted(30) + renewal_weighted(30)
    forecast_90 = opp_weighted(90) + proposal_weighted(90) + renewal_weighted(90)
    forecast_12m = current_arr + (forecast_90 * 4)
    projected_mrr_90 = current_mrr + new_mrr_weighted(90)
    projected_arr_90 = projected_mrr_90 * 12
    projected_salary_gap = max(salary_target - projected_mrr_90, 0)
    projected_salary_progress = (projected_mrr_90 / salary_target * 100) if salary_target else 0

    details = {
        "opportunities_30": opp_weighted(30),
        "opportunities_90": opp_weighted(90),
        "proposals_30": proposal_weighted(30),
        "proposals_90": proposal_weighted(90),
        "renewals_30": renewal_weighted(30),
        "renewals_90": renewal_weighted(90),
        "new_mrr_90": new_mrr_weighted(90),
    }
    return {
        "current_mrr": current_mrr,
        "current_arr": current_arr,
        "forecast_30": forecast_30,
        "forecast_90": forecast_90,
        "forecast_12m": forecast_12m,
        "projected_mrr_90": projected_mrr_90,
        "projected_arr_90": projected_arr_90,
        "projected_salary_gap": projected_salary_gap,
        "projected_salary_progress": projected_salary_progress,
        "details": details,
        "open_opportunities": active_opps,
        "open_proposals": active_props,
        "open_renewals": open_renewals,
    }



def days_until(value):
    """Return days until a stored date. Supports ISO and friendly placeholder strings.
    Returns None when the date cannot be parsed.
    """
    d = parse_date_safe(value)
    if not d:
        return None
    return (d - date.today()).days


def health_points_from(value):
    """Normalize client/advisory health language into a risk-point contribution."""
    text = (value or "").strip().lower()
    if text in ["healthy", "stable", "current", "good", "green"]:
        return 0
    if text in ["watchlist", "watch", "due soon", "moderate", "yellow"]:
        return 15
    if text in ["at risk", "overdue", "high", "critical", "red"]:
        return 35
    if text in ["paused", "cancelled", "closed"]:
        return 45
    return 10


def build_client_health(clients, advisory_engagements, renewals, activities):
    """SentinelRE Client Health Engine™.

    Produces a simple executive health score for every client based on:
    billing status, advisory status, open actions, renewal risk, upcoming reviews,
    recent activity / follow-up pressure, and lifecycle status.
    """
    advisory_by_client = {}
    for a in advisory_engagements:
        advisory_by_client.setdefault((a.client_name or "").lower(), []).append(a)

    renewals_by_client = {}
    for r in renewals:
        renewals_by_client.setdefault((r.client_name or "").lower(), []).append(r)

    activities_by_client = {}
    for act in activities:
        key = (act.related_name or "").lower()
        if not key and act.client:
            key = (act.client.client_name or "").lower()
        if key:
            activities_by_client.setdefault(key, []).append(act)

    records = []
    for c in clients:
        key = (c.client_name or "").lower()
        score = 100
        flags = []
        recommendations = []

        # Client lifecycle/status risk
        if c.client_status in ["Paused", "Closed"]:
            score -= 35
            flags.append("Client not active")
            recommendations.append("Confirm whether the relationship should be reactivated or archived.")
        elif c.client_status in ["Renewal Pending"]:
            score -= 15
            flags.append("Renewal pending")
            recommendations.append("Schedule renewal value review and confirm next-term scope.")
        elif c.client_status in ["Onboarding", "Active Assessment"]:
            score -= 5

        # Open actions
        if (c.open_actions or 0) >= 8:
            score -= 25
            flags.append("High number of open actions")
            recommendations.append("Reduce open roadmap/advisory actions before next client review.")
        elif (c.open_actions or 0) >= 4:
            score -= 12
            flags.append("Open actions need attention")
            recommendations.append("Review open actions and assign due dates.")

        # Client risk priority
        rp = (c.risk_priority or "").lower()
        if rp == "critical":
            score -= 25
            flags.append("Critical client risk priority")
        elif rp == "high":
            score -= 15
            flags.append("High client risk priority")
        elif rp == "moderate":
            score -= 5

        # Advisory engagement health and billing
        client_advisories = advisory_by_client.get(key, [])
        for a in client_advisories:
            if a.status in ["At Risk", "Cancelled", "Paused"]:
                score -= health_points_from(a.status)
                flags.append(f"Advisory status: {a.status}")
            if a.billing_status == "Overdue":
                score -= 30
                flags.append("Billing overdue")
                recommendations.append("Resolve billing issue before expanding advisory scope.")
            elif a.billing_status == "Due Soon":
                score -= 10
                flags.append("Invoice due soon")
            if (a.open_actions or 0) >= 5:
                score -= 12
                flags.append("Advisory actions accumulating")
            score -= min(health_points_from(a.health_status), 20)

            review_days = days_until(a.next_review_date)
            if review_days is not None:
                if review_days < 0:
                    score -= 20
                    flags.append("Advisory review overdue")
                    recommendations.append("Schedule overdue advisory review immediately.")
                elif review_days <= 14:
                    score -= 5
                    flags.append("Advisory review due soon")

        # Renewal risk
        client_renewals = [r for r in renewals_by_client.get(key, []) if r.renewal_stage not in ["Renewed", "Lost", "Deferred"]]
        for r in client_renewals:
            if r.renewal_stage == "At Risk" or r.risk_level in ["High", "Critical"]:
                score -= 25 if r.risk_level == "High" else 35 if r.risk_level == "Critical" else 20
                flags.append(f"Renewal risk: {r.risk_level}")
                recommendations.append("Prepare renewal recovery plan and executive value summary.")
            renewal_days = days_until(r.renewal_date)
            if renewal_days is not None:
                if renewal_days < 0:
                    score -= 25
                    flags.append("Renewal overdue")
                elif renewal_days <= 30:
                    score -= 15
                    flags.append("Renewal due within 30 days")
                elif renewal_days <= 90:
                    score -= 7
                    flags.append("Renewal due within 90 days")

        # Activity pressure
        client_activities = activities_by_client.get(key, [])
        open_followups = [a for a in client_activities if a.is_open_follow_up]
        urgent_followups = [a for a in open_followups if a.priority in ["High", "Urgent"]]
        if len(urgent_followups) >= 2:
            score -= 15
            flags.append("Multiple urgent follow-ups")
        elif len(open_followups) >= 3:
            score -= 10
            flags.append("Multiple open follow-ups")

        score = max(0, min(100, round(score)))
        if score >= 85:
            status = "Healthy"
            next_action = "Maintain cadence and look for expansion opportunity."
        elif score >= 70:
            status = "Stable"
            next_action = "Monitor open actions and upcoming reviews."
        elif score >= 55:
            status = "Watchlist"
            next_action = "Schedule client health check within 14 days."
        else:
            status = "At Risk"
            next_action = "Immediate founder/advisor intervention recommended."

        if recommendations:
            next_action = recommendations[0]
        records.append({
            "client": c,
            "score": score,
            "status": status,
            "flags": flags[:4],
            "next_action": next_action,
            "mrr": c.monthly_retainer or sum((a.monthly_fee or 0) for a in client_advisories),
            "open_followups": len(open_followups),
            "open_renewals": len(client_renewals),
            "advisory_count": len(client_advisories),
        })

    records.sort(key=lambda x: x["score"])
    summary = {
        "total_clients": len(records),
        "healthy": len([r for r in records if r["status"] in ["Healthy", "Stable"]]),
        "watchlist": len([r for r in records if r["status"] == "Watchlist"]),
        "at_risk": len([r for r in records if r["status"] == "At Risk"]),
        "average_health": round(sum(r["score"] for r in records) / max(len(records), 1)),
        "at_risk_mrr": sum((r["mrr"] or 0) for r in records if r["status"] == "At Risk"),
        "watchlist_mrr": sum((r["mrr"] or 0) for r in records if r["status"] == "Watchlist"),
        "records": records,
        "top_risks": records[:5],
    }
    return summary



def renewal_risk_status(record):
    """Return normalized renewal risk status and executive action guidance."""
    days = days_until(record.renewal_date)
    score = 0
    flags = []
    if record.renewal_stage in ["At Risk", "Negotiation"]:
        score += 30
        flags.append(f"Stage: {record.renewal_stage}")
    elif record.renewal_stage in ["Proposal Needed", "Proposal Sent"]:
        score += 15
        flags.append(f"Stage: {record.renewal_stage}")
    if record.risk_level == "Critical":
        score += 40
        flags.append("Critical renewal risk")
    elif record.risk_level == "High":
        score += 30
        flags.append("High renewal risk")
    elif record.risk_level == "Moderate":
        score += 15
    if days is not None:
        if days < 0:
            score += 35
            flags.append("Renewal overdue")
        elif days <= 30:
            score += 30
            flags.append("Due within 30 days")
        elif days <= 60:
            score += 20
            flags.append("Due within 60 days")
        elif days <= 90:
            score += 10
            flags.append("Due within 90 days")
    if (record.probability or 0) < 0.4:
        score += 20
        flags.append("Low renewal probability")
    if record.health_status in ["At Risk", "High", "Critical"]:
        score += 20
        flags.append(f"Health: {record.health_status}")
    score = min(score, 100)
    if score >= 75:
        status = "Critical"
        action = "Founder intervention required: schedule executive renewal call and prepare retention plan."
    elif score >= 50:
        status = "High"
        action = "Prioritize renewal: send value summary, confirm decision-maker, and propose next-term scope."
    elif score >= 25:
        status = "Moderate"
        action = "Monitor renewal: prepare follow-up and confirm renewal timeline."
    else:
        status = "Low"
        action = "Maintain cadence and look for expansion opportunity."
    return {"score": score, "status": status, "days_until": days, "flags": flags[:4], "action": action}


def build_renewal_risk(renewals):
    """SentinelRE Renewal Risk Engine™ for protecting recurring revenue."""
    open_records = [r for r in renewals if r.renewal_stage not in ["Renewed", "Lost", "Deferred"]]
    records = []
    for r in open_records:
        risk = renewal_risk_status(r)
        records.append({
            "renewal": r,
            "risk_score": risk["score"],
            "risk_status": risk["status"],
            "days_until": risk["days_until"],
            "flags": risk["flags"],
            "next_action": risk["action"],
            "mrr": r.projected_mrr,
            "arr": (r.projected_mrr or 0) * 12,
            "weighted_value": r.weighted_renewal_value,
        })
    records.sort(key=lambda x: (x["risk_score"], x["weighted_value"]), reverse=True)
    summary = {
        "total_open": len(records),
        "critical": len([r for r in records if r["risk_status"] == "Critical"]),
        "high": len([r for r in records if r["risk_status"] == "High"]),
        "moderate": len([r for r in records if r["risk_status"] == "Moderate"]),
        "low": len([r for r in records if r["risk_status"] == "Low"]),
        "due_30": len([r for r in records if r["days_until"] is not None and 0 <= r["days_until"] <= 30]),
        "due_60": len([r for r in records if r["days_until"] is not None and 0 <= r["days_until"] <= 60]),
        "due_90": len([r for r in records if r["days_until"] is not None and 0 <= r["days_until"] <= 90]),
        "at_risk_mrr": sum((r["mrr"] or 0) for r in records if r["risk_status"] in ["Critical", "High"]),
        "weighted_renewal_value": sum((r["weighted_value"] or 0) for r in records),
        "renewal_pipeline_value": sum((r["renewal"].renewal_value or r["renewal"].current_annual_value or 0) for r in records),
        "records": records,
        "top_risks": records[:5],
    }
    return summary


def month_key(dt):
    return dt.strftime("%Y-%m") if dt else "Unknown"


def build_trend_analytics(leads, opportunities, proposals, clients, advisory_engagements, renewals, activities):
    """SentinelRE Trend Analytics Engine™ for monthly growth and operational movement."""
    months = []
    today = date.today().replace(day=1)
    for i in range(5, -1, -1):
        # approximate month stepping without external dependencies
        y = today.year
        m = today.month - i
        while m <= 0:
            y -= 1
            m += 12
        months.append(f"{y:04d}-{m:02d}")

    def init_series():
        return {k: 0 for k in months}

    trends = {
        "leads": init_series(),
        "opportunities": init_series(),
        "proposals": init_series(),
        "clients": init_series(),
        "activities": init_series(),
        "one_time_revenue": init_series(),
        "new_mrr": init_series(),
        "renewal_value": init_series(),
    }

    for item in leads:
        k = month_key(item.created_at)
        if k in trends["leads"]: trends["leads"][k] += 1
    for item in opportunities:
        k = month_key(item.created_at)
        if k in trends["opportunities"]: trends["opportunities"][k] += 1
    for item in proposals:
        k = month_key(item.created_at)
        if k in trends["proposals"]:
            trends["proposals"][k] += 1
            if item.status == "Accepted":
                trends["one_time_revenue"][k] += item.one_time_fee or 0
                trends["new_mrr"][k] += item.monthly_retainer or 0
    for item in clients:
        k = month_key(item.created_at)
        if k in trends["clients"]:
            trends["clients"][k] += 1
            trends["new_mrr"][k] += item.monthly_retainer or 0
    for item in advisory_engagements:
        k = month_key(item.created_at)
        if k in trends["new_mrr"] and item.status == "Active":
            trends["new_mrr"][k] += item.monthly_fee or 0
    for item in renewals:
        k = month_key(item.created_at)
        if k in trends["renewal_value"]:
            trends["renewal_value"][k] += item.renewal_value or item.current_annual_value or 0
    for item in activities:
        k = month_key(item.created_at)
        if k in trends["activities"]: trends["activities"][k] += 1

    current_mrr = sum((a.monthly_fee or 0) for a in advisory_engagements if a.status == "Active" and a.billing_status != "Paused")
    prev_month = months[-2] if len(months) > 1 else months[-1]
    current_month = months[-1]
    lead_growth = trends["leads"][current_month] - trends["leads"][prev_month]
    opp_growth = trends["opportunities"][current_month] - trends["opportunities"][prev_month]
    activity_growth = trends["activities"][current_month] - trends["activities"][prev_month]

    return {
        "months": months,
        "trends": trends,
        "current_mrr": current_mrr,
        "current_arr": current_mrr * 12,
        "lead_growth": lead_growth,
        "opportunity_growth": opp_growth,
        "activity_growth": activity_growth,
        "six_month_pipeline_created": sum(trends["opportunities"].values()),
        "six_month_clients_created": sum(trends["clients"].values()),
        "six_month_activities": sum(trends["activities"].values()),
        "six_month_new_mrr": sum(trends["new_mrr"].values()),
        "six_month_renewal_value": sum(trends["renewal_value"].values()),
    }


def _record_exists(model, **kwargs):
    return model.query.filter_by(**kwargs).first() is not None


def create_activity_once(subject, related_name=None, activity_type="Task", outcome="Follow-Up Needed", priority="Medium", next_follow_up=None, owner=None, **links):
    """Create a follow-up activity only when the same open activity does not already exist."""
    existing = ActivityLog.query.filter_by(subject=subject, related_name=related_name, outcome=outcome).first()
    if existing:
        return None
    act = ActivityLog(
        activity_date=date.today().isoformat(),
        activity_type=activity_type,
        subject=subject,
        related_name=related_name,
        outcome=outcome,
        priority=priority,
        next_follow_up=next_follow_up or "Within 7 days",
        owner=owner,
        **links,
    )
    db.session.add(act)
    return act


def render_email_template(trigger_type, record):
    """Create branded SentinelRE email drafts from CRM objects without sending externally."""
    company = getattr(record, "client_name", None) or getattr(record, "company_name", None) or getattr(record, "related_name", "")
    contact = getattr(record, "contact_name", None) or "there"
    service = getattr(record, "recommended_offer", None) or getattr(record, "service_type", None) or getattr(record, "proposal_type", None) or "Executive Risk Intelligence"
    if trigger_type == "Discovery Invite":
        subject = f"Executive Risk Intelligence conversation for {company}"
        body = f"Hello {contact},\n\nI wanted to follow up regarding {company}'s real estate governance risk visibility, operational resilience, and transaction readiness needs. SentinelRE helps leaders understand priority risks, business impact, and practical next steps through an executive-friendly assessment process.\n\nWould you be open to a brief discovery conversation this week to determine whether a Property Risk Snapshot would be useful?\n\nBest regards,\nDr. Ursala Clarke\nSentinel Risk Compliance Group"
    elif trigger_type == "Proposal Follow-Up":
        subject = f"Following up on SentinelRE proposal for {company}"
        body = f"Hello {contact},\n\nI am following up on the SentinelRE proposal for {company}. The proposed engagement is designed to provide executive visibility into real estate transaction risk, business impact, transaction readiness, and a prioritized roadmap.\n\nPlease let me know if you would like to review the scope, timeline, or advisory options.\n\nBest regards,\nDr. Ursala Clarke\nSentinel Risk Compliance Group"
    elif trigger_type == "Advisory Review Reminder":
        subject = f"Upcoming advisory review for {company}"
        body = f"Hello {contact},\n\nThis is a reminder to schedule or prepare for the next SentinelRE advisory review for {company}. The review will focus on open roadmap items, risk reduction progress, executive priorities, and next-step recommendations.\n\nPlease confirm a convenient time for the review.\n\nBest regards,\nDr. Ursala Clarke\nSentinel Risk Compliance Group"
    elif trigger_type == "Renewal Check-In":
        subject = f"SentinelRE renewal planning for {company}"
        body = f"Hello {contact},\n\nI wanted to begin renewal planning for {company}'s SentinelRE advisory or assessment services. This is an opportunity to review progress, remaining risks, and the best support model for the next term.\n\nWould you like to schedule a renewal value review?\n\nBest regards,\nDr. Ursala Clarke\nSentinel Risk Compliance Group"
    else:
        subject = f"Following up with {company}"
        body = f"Hello {contact},\n\nI wanted to follow up regarding {service} and the next steps for {company}. Please let me know if there is a convenient time to continue the conversation.\n\nBest regards,\nDr. Ursala Clarke\nSentinel Risk Compliance Group"
    return subject, body


def existing_email_log(trigger_type, **filters):
    query = EmailAutomationLog.query.filter_by(trigger_type=trigger_type, **filters)
    return query.first()


def build_email_automation_preview():
    """Identify recommended email drafts without creating records."""
    items = []
    for lead in Lead.query.all():
        if (lead.priority or "").startswith("A") and lead.email and not existing_email_log("Discovery Invite", lead_id=lead.id):
            items.append({"type":"Discovery Invite", "priority":"High", "record":lead.client_name, "recipient":lead.email, "reason":"A-tier lead with email has no discovery invite draft.", "action":"Create discovery invite email draft."})
        elif lead.email and lead.next_follow_up and not existing_email_log("General Follow-Up", lead_id=lead.id):
            items.append({"type":"General Follow-Up", "priority":"Medium", "record":lead.client_name, "recipient":lead.email, "reason":"Lead has a follow-up date and email address.", "action":"Create follow-up email draft."})
    for proposal in Proposal.query.filter_by(status="Sent").all():
        if proposal.email and not existing_email_log("Proposal Follow-Up", proposal_id=proposal.id):
            items.append({"type":"Proposal Follow-Up", "priority":"High", "record":proposal.client_name, "recipient":proposal.email, "reason":"Sent proposal needs tracked email follow-up.", "action":"Create proposal follow-up email draft."})
    for advisory in AdvisoryEngagement.query.filter_by(status="Active").all():
        if advisory.email and advisory.next_review_date and not existing_email_log("Advisory Review Reminder", advisory_id=advisory.id):
            items.append({"type":"Advisory Review Reminder", "priority":"Medium", "record":advisory.client_name, "recipient":advisory.email, "reason":"Active advisory client has an upcoming review cadence.", "action":"Create advisory review reminder draft."})
    for renewal in RenewalRecord.query.all():
        if renewal.email and renewal.renewal_stage not in ["Renewed", "Lost", "Deferred"] and not existing_email_log("Renewal Check-In", renewal_id=renewal.id):
            priority = "High" if renewal.risk_level in ["High", "Critical"] else "Medium"
            items.append({"type":"Renewal Check-In", "priority":priority, "record":renewal.client_name, "recipient":renewal.email, "reason":"Open renewal should have a proactive renewal check-in email.", "action":"Create renewal check-in email draft."})
    return items


def create_email_log(trigger_type, record, created_by="system", **links):
    subject, body = render_email_template(trigger_type, record)
    recipient_name = getattr(record, "contact_name", None)
    recipient_email = getattr(record, "email", None)
    related_name = getattr(record, "client_name", None) or getattr(record, "company_name", None) or ""
    if not recipient_email:
        return None
    log = EmailAutomationLog(
        trigger_type=trigger_type,
        recipient_name=recipient_name,
        recipient_email=recipient_email,
        related_name=related_name,
        subject=subject,
        body=body,
        status="Queued",
        due_date=date.today().isoformat(),
        created_by=created_by,
        notes="Created by SentinelRE Email Automation Engine™.",
        **links,
    )
    db.session.add(log)
    return log


def run_email_automation(created_by="system"):
    """Create email drafts/queue records. This does not send external email automatically."""
    created = []
    for lead in Lead.query.all():
        if (lead.priority or "").startswith("A") and lead.email and not existing_email_log("Discovery Invite", lead_id=lead.id):
            log = create_email_log("Discovery Invite", lead, created_by=created_by, lead_id=lead.id)
            if log: created.append(f"Discovery invite draft: {lead.client_name}")
        elif lead.email and lead.next_follow_up and not existing_email_log("General Follow-Up", lead_id=lead.id):
            log = create_email_log("General Follow-Up", lead, created_by=created_by, lead_id=lead.id)
            if log: created.append(f"Lead follow-up draft: {lead.client_name}")
    for proposal in Proposal.query.filter_by(status="Sent").all():
        if proposal.email and not existing_email_log("Proposal Follow-Up", proposal_id=proposal.id):
            log = create_email_log("Proposal Follow-Up", proposal, created_by=created_by, proposal_id=proposal.id, opportunity_id=proposal.opportunity_id)
            if log: created.append(f"Proposal follow-up draft: {proposal.client_name}")
    for advisory in AdvisoryEngagement.query.filter_by(status="Active").all():
        if advisory.email and advisory.next_review_date and not existing_email_log("Advisory Review Reminder", advisory_id=advisory.id):
            log = create_email_log("Advisory Review Reminder", advisory, created_by=created_by, advisory_id=advisory.id, client_id=advisory.client_id)
            if log: created.append(f"Advisory review reminder draft: {advisory.client_name}")
    for renewal in RenewalRecord.query.all():
        if renewal.email and renewal.renewal_stage not in ["Renewed", "Lost", "Deferred"] and not existing_email_log("Renewal Check-In", renewal_id=renewal.id):
            log = create_email_log("Renewal Check-In", renewal, created_by=created_by, renewal_id=renewal.id, client_id=renewal.client_id, advisory_id=renewal.advisory_id)
            if log: created.append(f"Renewal check-in draft: {renewal.client_name}")
    db.session.commit()
    return created

def build_workflow_automation_preview():
    """Identify recommended workflow actions without changing records."""
    items = []

    accepted_without_client = [p for p in Proposal.query.filter_by(status="Accepted").all() if not Client.query.filter_by(proposal_id=p.id).first()]
    for p in accepted_without_client:
        items.append({"type":"Create Client", "priority":"High", "record":p.client_name, "description":"Accepted proposal has no linked client lifecycle record.", "action":"Create client from accepted proposal."})

    proposal_sent_followups = [p for p in Proposal.query.filter_by(status="Sent").all()]
    for p in proposal_sent_followups:
        if not ActivityLog.query.filter_by(proposal_id=p.id, subject="Follow up on sent proposal", outcome="Follow-Up Needed").first():
            items.append({"type":"Create Follow-Up", "priority":"High", "record":p.client_name, "description":"Sent proposal needs tracked follow-up activity.", "action":"Create proposal follow-up task."})

    active_clients = [c for c in Client.query.all() if c.client_status not in ["Paused", "Closed"]]
    for c in active_clients:
        if (c.monthly_retainer or 0) > 0 and not AdvisoryEngagement.query.filter_by(client_id=c.id).first():
            items.append({"type":"Create Advisory", "priority":"High", "record":c.client_name, "description":"Client has monthly retainer but no advisory engagement record.", "action":"Create advisory revenue record."})
        if c.renewal_date and not RenewalRecord.query.filter_by(client_id=c.id).first():
            items.append({"type":"Create Renewal", "priority":"Medium", "record":c.client_name, "description":"Client has renewal date but no renewal record.", "action":"Create renewal tracking record."})

    active_advisory = [a for a in AdvisoryEngagement.query.all() if a.status == "Active"]
    for a in active_advisory:
        if a.renewal_date and not RenewalRecord.query.filter_by(advisory_id=a.id).first():
            items.append({"type":"Create Renewal", "priority":"Medium", "record":a.client_name, "description":"Active advisory engagement has no renewal tracking record.", "action":"Create advisory renewal record."})
        if a.next_review_date and not ActivityLog.query.filter_by(advisory_id=a.id, subject="Prepare advisory review", outcome="Follow-Up Needed").first():
            items.append({"type":"Create Follow-Up", "priority":"Medium", "record":a.client_name, "description":"Advisory review should be tracked as an activity.", "action":"Create advisory review preparation task."})

    a_tier_leads = [l for l in Lead.query.all() if (l.priority or "").startswith("A")]
    for l in a_tier_leads:
        if not Opportunity.query.filter_by(lead_id=l.id).first():
            items.append({"type":"Create Opportunity", "priority":"High", "record":l.client_name, "description":"A-tier lead has no opportunity record.", "action":"Create opportunity from lead."})
        if not ActivityLog.query.filter_by(lead_id=l.id, subject="Move A-tier lead to discovery", outcome="Follow-Up Needed").first():
            items.append({"type":"Create Follow-Up", "priority":"High", "record":l.client_name, "description":"A-tier lead needs discovery follow-up.", "action":"Create discovery follow-up task."})

    return items


def run_workflow_automation(triggered_by="system"):
    """SentinelRE Workflow Automation Engine™.

    Automates repetitive operations that protect the real estate advisory pipeline:
    accepted proposal -> client, client retainer -> advisory, client/advisory renewal date -> renewal,
    A-tier lead -> opportunity, and required follow-up activities.
    """
    summary = []
    counts = {"actions":0, "clients":0, "advisory":0, "renewals":0, "opportunities":0}

    # 1. Accepted proposal -> client lifecycle record.
    for p in Proposal.query.filter_by(status="Accepted").all():
        if Client.query.filter_by(proposal_id=p.id).first():
            continue
        opp = p.opportunity
        client = Client(
            proposal_id=p.id,
            opportunity_id=opp.id if opp else None,
            lead_id=opp.lead_id if opp else None,
            client_name=p.client_name,
            contact_name=p.contact_name,
            email=p.email,
            industry=p.industry,
            lifecycle_phase="Client",
            client_status="Advisory Active" if (p.monthly_retainer or 0) > 0 else "Onboarding",
            service_package=p.proposal_type,
            start_date=date.today().isoformat(),
            monthly_retainer=p.monthly_retainer or 0,
            total_contract_value=p.total_first_year_value,
            review_cadence="Quarterly",
            owner=triggered_by,
            notes="Created automatically by SentinelRE Workflow Automation Engine™.",
        )
        db.session.add(client)
        if opp:
            opp.opportunity_stage = "Won"
            opp.proposal_status = "Approved"
        summary.append(f"Created client lifecycle record for accepted proposal: {p.client_name}")
        counts["clients"] += 1

    db.session.flush()

    # 2. Client retainer -> advisory engagement.
    for c in Client.query.all():
        if (c.monthly_retainer or 0) > 0 and not AdvisoryEngagement.query.filter_by(client_id=c.id).first():
            adv = AdvisoryEngagement(
                client_id=c.id,
                client_name=c.client_name,
                contact_name=c.contact_name,
                email=c.email,
                service_type="Broker Advisory",
                status="Active",
                billing_status="Current",
                monthly_fee=c.monthly_retainer or 0,
                start_date=c.start_date or date.today().isoformat(),
                next_invoice_date="30 days",
                next_review_date=c.next_advisory_session or c.roadmap_review_date or "30 days",
                renewal_date=c.renewal_date or "12 months",
                review_cadence=c.review_cadence or "Monthly",
                owner=triggered_by,
                open_actions=c.open_actions or 0,
                health_status="Stable",
                notes="Created automatically from active client retainer.",
            )
            db.session.add(adv)
            c.client_status = "Advisory Active"
            c.lifecycle_phase = "Advisory"
            summary.append(f"Created advisory engagement for client: {c.client_name}")
            counts["advisory"] += 1

    db.session.flush()

    # 3. Client or advisory renewal date -> renewal tracking record.
    for c in Client.query.all():
        if c.renewal_date and not RenewalRecord.query.filter_by(client_id=c.id).first():
            r = RenewalRecord(
                client_id=c.id,
                client_name=c.client_name,
                contact_name=c.contact_name,
                email=c.email,
                renewal_type="Annual Reassessment" if not (c.monthly_retainer or 0) else "Advisory Retainer Renewal",
                renewal_stage="Upcoming",
                renewal_date=c.renewal_date,
                reminder_date="90 days before renewal",
                current_monthly_fee=c.monthly_retainer or 0,
                proposed_monthly_fee=c.monthly_retainer or 0,
                current_annual_value=(c.monthly_retainer or 0) * 12,
                renewal_value=(c.monthly_retainer or 0) * 12,
                probability=0.75,
                risk_level=c.risk_priority or "Moderate",
                health_status="Stable",
                owner=triggered_by,
                next_step="Schedule renewal value review and confirm next-term scope.",
                notes="Created automatically from client renewal date.",
            )
            db.session.add(r)
            summary.append(f"Created renewal record for client: {c.client_name}")
            counts["renewals"] += 1

    for a in AdvisoryEngagement.query.filter_by(status="Active").all():
        if a.renewal_date and not RenewalRecord.query.filter_by(advisory_id=a.id).first():
            r = RenewalRecord(
                advisory_id=a.id,
                client_id=a.client_id,
                client_name=a.client_name,
                contact_name=a.contact_name,
                email=a.email,
                renewal_type="Advisory Retainer Renewal",
                renewal_stage="Upcoming",
                renewal_date=a.renewal_date,
                reminder_date="90 days before renewal",
                current_monthly_fee=a.monthly_fee or 0,
                proposed_monthly_fee=a.monthly_fee or 0,
                current_annual_value=(a.monthly_fee or 0) * 12,
                renewal_value=(a.monthly_fee or 0) * 12,
                probability=0.75,
                risk_level="Moderate",
                health_status=a.health_status or "Stable",
                owner=triggered_by,
                next_step="Prepare advisory renewal value summary.",
                notes="Created automatically from active advisory engagement.",
            )
            db.session.add(r)
            summary.append(f"Created advisory renewal record for: {a.client_name}")
            counts["renewals"] += 1

    # 4. A-tier lead -> opportunity and discovery follow-up.
    for l in Lead.query.all():
        if (l.priority or "").startswith("A") and not Opportunity.query.filter_by(lead_id=l.id).first():
            opp = Opportunity(
                lead_id=l.id,
                company_name=l.client_name,
                contact_name=l.contact_name,
                email=l.email,
                phone=l.phone,
                industry=l.industry,
                service_type=l.recommended_offer or "Property Risk Snapshot",
                opportunity_stage="Discovery",
                proposal_status="Not Started",
                estimated_value=l.estimated_value or 0,
                probability=l.probability or 0.25,
                expected_close_date="90 days",
                monthly_retainer=l.monthly_retainer or 0,
                next_step="Schedule executive discovery call.",
                owner=triggered_by,
                notes="Created automatically from A-tier lead.",
            )
            db.session.add(opp)
            l.stage = "Qualified"
            summary.append(f"Created opportunity from A-tier lead: {l.client_name}")
            counts["opportunities"] += 1
        act = create_activity_once(
            subject="Move A-tier lead to discovery",
            related_name=l.client_name,
            activity_type="Task",
            outcome="Follow-Up Needed",
            priority="High",
            next_follow_up=l.next_follow_up or "Within 7 days",
            owner=triggered_by,
            lead_id=l.id,
            contact_name=l.contact_name,
            notes="Automation-created discovery follow-up for A-tier lead.",
        ) if (l.priority or "").startswith("A") else None
        if act:
            counts["actions"] += 1
            summary.append(f"Created A-tier discovery follow-up for: {l.client_name}")

    # 5. Proposal and advisory follow-up tasks.
    for p in Proposal.query.filter_by(status="Sent").all():
        act = create_activity_once(
            subject="Follow up on sent proposal",
            related_name=p.client_name,
            activity_type="Proposal Follow-Up",
            outcome="Follow-Up Needed",
            priority="High",
            next_follow_up="Within 5 business days",
            owner=triggered_by,
            proposal_id=p.id,
            contact_name=p.contact_name,
            notes="Automation-created follow-up for sent proposal.",
        )
        if act:
            counts["actions"] += 1
            summary.append(f"Created proposal follow-up for: {p.client_name}")

    for a in AdvisoryEngagement.query.filter_by(status="Active").all():
        act = create_activity_once(
            subject="Prepare advisory review",
            related_name=a.client_name,
            activity_type="Advisory Review",
            outcome="Follow-Up Needed",
            priority="Medium",
            next_follow_up=a.next_review_date or "Within 30 days",
            owner=triggered_by,
            advisory_id=a.id,
            contact_name=a.contact_name,
            notes="Automation-created advisory review preparation task.",
        )
        if act:
            counts["actions"] += 1
            summary.append(f"Created advisory review preparation for: {a.client_name}")

    run = WorkflowAutomationRun(
        run_type="Manual",
        triggered_by=triggered_by,
        actions_created=counts["actions"],
        clients_created=counts["clients"],
        advisory_created=counts["advisory"],
        renewals_created=counts["renewals"],
        opportunities_created=counts["opportunities"],
        status="Completed",
        summary_json=json.dumps(summary),
        notes="; ".join(summary[:5]) if summary else "No automation actions were needed.",
    )
    db.session.add(run)
    db.session.commit()
    return run, summary


def build_findings(form_data):
    findings = []
    for key, category, question in QUESTIONS:
        response = form_data.get(key, "Unknown")
        score = SCORE_MAP.get(response, 3)
        findings.append({
            "category": category,
            "question": question,
            "response": response,
            "risk_score": score,
            "risk_level": "Low" if score == 1 else "Moderate" if score == 2 else "High",
            "framework_alignment": FRAMEWORK_MAP[category],
        })
    return findings

def overall_from_findings(findings):
    score = sum(x["risk_score"] for x in findings) / max(len(findings), 1)
    if score >= 2.4: return "High", score
    if score >= 1.8: return "Moderate", score
    return "Low", score

def exposure_from_value(avg_transaction_value, level):
    return avg_transaction_value * {"Low":0.05,"Moderate":0.15,"High":0.30}[level] if avg_transaction_value > 0 else 0.0

def action_plan(level):
    if level == "High":
        return ["Schedule a discovery call within 48 hours.","Prepare a tailored Property Risk Snapshot offer.","Identify decision-maker objections and buying triggers.","Draft a proposal with scope, deliverables, pricing, and next steps.","Set a follow-up date and owner in the pipeline."]
    if level == "Moderate":
        return ["Send value-based follow-up with a sample executive report.","Invite prospect to a Property Risk Snapshot consultation.","Validate budget, timing, and decision-maker involvement."]
    return ["Place prospect in nurture sequence.","Revisit in 30–60 days with educational content or industry insight."]

def build_pdf(assessment):
    if not REPORTLAB_AVAILABLE: return None
    findings = json.loads(assessment.findings_json)
    logo_path = BASE_DIR / "static" / "img" / "srcg_logo.png"
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, topMargin=36, bottomMargin=36, leftMargin=36, rightMargin=36)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleStyle", parent=styles["Title"], textColor=colors.HexColor("#0B122B"), fontSize=18, leading=22)
    sub_style = ParagraphStyle("SubStyle", parent=styles["Normal"], textColor=colors.HexColor("#C99A2E"), fontSize=10, spaceAfter=8)
    head_style = ParagraphStyle("HeadStyle", parent=styles["Heading2"], textColor=colors.HexColor("#0B122B"), fontSize=13, spaceBefore=10)
    normal = styles["BodyText"]
    story = []
    if logo_path.exists(): story.append(Image(str(logo_path), width=60, height=60))
    story.append(Paragraph(BRAND["company"], title_style))
    story.append(Paragraph("SentinelRE™ Opportunity Brief", sub_style))
    story.append(Paragraph(f"Organization: {assessment.client_name} | Date: {assessment.created_at.date().isoformat()}", normal))
    story.append(Spacer(1, 8))
    story.append(Paragraph("Executive Summary", head_style))
    story.append(Paragraph(f"Overall risk level: <b>{assessment.overall_level}</b>. Average score: <b>{assessment.overall_score:.2f}</b>. Weighted opportunity exposure: <b>${assessment.exposure:,.0f}</b>. Estimated revenue-at-risk / delivery delay: <b>${assessment.downtime_loss:,.0f}</b>.", normal))
    story.append(Spacer(1, 8))
    story.append(Paragraph("Key Findings", head_style))
    table_data = [["Category","Response","Risk Level"]]
    for row in findings: table_data.append([row["category"], row["response"], row["risk_level"]])
    table = Table(table_data, repeatRows=1, colWidths=[150,120,100])
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#0B122B")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#D7D7E0")),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white, colors.HexColor("#F7F5FB")])]))
    story.append(table)
    story.append(Spacer(1, 8))
    story.append(Paragraph("30–60 Day Pipeline Action Plan", head_style))
    for idx, item in enumerate(action_plan(assessment.overall_level), start=1):
        story.append(Paragraph(f"{idx}. {item}", normal))
    story.append(Spacer(1, 8))
    story.append(Paragraph("Disclaimer", head_style))
    story.append(Paragraph("This operations brief supports internal business development decision-making. It is not a legal opinion, guarantee of sales performance, or client certification.", normal))
    doc.build(story)
    buffer.seek(0)
    return buffer


def split_lines(text):
    if not text:
        return []
    return [line.strip() for line in text.replace(";", "\n").split("\n") if line.strip()]

def default_scope(proposal_type):
    if "Advisory" in proposal_type:
        return "Ongoing brokerage advisory support, transaction governance tracking, quarterly property risk review, and compliance readiness guidance."
    if "Federal" in proposal_type:
        return "Transaction readiness assessment focused on real estate transaction governance, document readiness, broker oversight, compliance readiness indicators, and executive remediation priorities."
    if "Advance" in proposal_type:
        return "Executive Risk Intelligence Assessment with Transaction Readiness review, business impact analysis, Top 5 Risks, and a 30-60-90 day roadmap."
    if "Snapshot" in proposal_type:
        return "Property Risk Snapshot designed to identify priority risk signals, readiness concerns, and next-step recommendations."
    return "Executive Risk Intelligence Assessment focused on domain scoring, risk visibility, Top 5 Risks, and executive recommendations."

def default_deliverables(proposal_type):
    base = [
        "Executive Risk Intelligence review",
        "Executive Risk Index™ and domain-level risk summary",
        "Top risk observations and business impact summary",
        "Prioritized executive recommendations",
    ]
    if "Federal" in proposal_type or "Advance" in proposal_type:
        base += ["Transaction Readiness Score™", "real estate compliance readiness gap summary", "30-60-90 day Executive Roadmap™"]
    if "Advisory" in proposal_type:
        base += ["Monthly advisory session", "Quarterly roadmap review", "Risk progress tracking", "Executive briefing support"]
    return "\n".join(base)

def build_proposal_pdf(proposal):
    if not REPORTLAB_AVAILABLE:
        return None
    logo_path = BASE_DIR / "static" / "img" / "srcg_logo.png"
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, topMargin=36, bottomMargin=36, leftMargin=42, rightMargin=42)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("ProposalTitle", parent=styles["Title"], textColor=colors.HexColor("#0B122B"), fontSize=20, leading=24, spaceAfter=8)
    gold_style = ParagraphStyle("Gold", parent=styles["Normal"], textColor=colors.HexColor("#C99A2E"), fontSize=10, leading=13, spaceAfter=10, fontName="Helvetica-Bold")
    heading = ParagraphStyle("Heading", parent=styles["Heading2"], textColor=colors.HexColor("#0B122B"), fontSize=13, leading=16, spaceBefore=12, spaceAfter=6)
    normal = styles["BodyText"]
    small = ParagraphStyle("Small", parent=styles["BodyText"], fontSize=8, leading=10, textColor=colors.HexColor("#555555"))
    story = []
    if logo_path.exists():
        story.append(Image(str(logo_path), width=58, height=58))
    story.append(Paragraph(BRAND["company"], title_style))
    story.append(Paragraph("SentinelRE™ Proposal Engine | Executive Risk Intelligence Proposal", gold_style))
    story.append(Paragraph(f"Proposal Number: <b>{proposal.proposal_number}</b>", normal))
    story.append(Paragraph(f"Prepared for: <b>{proposal.client_name}</b>", normal))
    if proposal.contact_name:
        story.append(Paragraph(f"Contact: {proposal.contact_name} | {proposal.email or ''}", normal))
    story.append(Paragraph(f"Prepared by: {proposal.prepared_by or 'Sentinel Risk Compliance Group'} | Date: {proposal.created_at.date().isoformat()}", normal))
    story.append(Spacer(1, 14))
    story.append(Table([["Proposal Type", proposal.proposal_type], ["Status", proposal.status], ["Timeline", proposal.timeline], ["Valid Until", proposal.valid_until or "To be confirmed"]], colWidths=[130, 330], style=TableStyle([
        ("BACKGROUND", (0,0), (0,-1), colors.HexColor("#0B122B")), ("TEXTCOLOR", (0,0), (0,-1), colors.white),
        ("BACKGROUND", (1,0), (1,-1), colors.HexColor("#F7F5FB")), ("GRID", (0,0), (-1,-1), .4, colors.HexColor("#D7D7E0")),
        ("FONTNAME", (0,0), (-1,-1), "Helvetica"), ("FONTSIZE", (0,0), (-1,-1), 9), ("VALIGN", (0,0), (-1,-1), "TOP")
    ])))
    story.append(Paragraph("Executive Overview", heading))
    story.append(Paragraph("Sentinel Risk Compliance Group provides executive-level real estate governance, transaction readiness visibility, document governance, and prioritized advisory guidance designed to help brokers, owners, and real estate leaders understand risk, make informed decisions, and improve operational resilience.", normal))
    story.append(Paragraph("Scope of Work", heading))
    story.append(Paragraph(proposal.scope or default_scope(proposal.proposal_type), normal))
    story.append(Paragraph("Deliverables", heading))
    for item in split_lines(proposal.deliverables or default_deliverables(proposal.proposal_type)):
        story.append(Paragraph(f"• {item}", normal))
    story.append(Paragraph("Investment", heading))
    investment = [["One-Time Fee", f"${proposal.one_time_fee or 0:,.0f}"], ["Monthly Advisory Retainer", f"${proposal.monthly_retainer or 0:,.0f}"], ["Estimated First-Year Value", f"${proposal.total_first_year_value:,.0f}"], ["Payment Terms", proposal.payment_terms or "To be confirmed"]]
    t = Table(investment, colWidths=[190, 270])
    t.setStyle(TableStyle([("BACKGROUND", (0,0), (0,-1), colors.HexColor("#0B122B")), ("TEXTCOLOR", (0,0), (0,-1), colors.white), ("BACKGROUND", (1,0), (1,-1), colors.HexColor("#FFF7E6")), ("GRID", (0,0), (-1,-1), .4, colors.HexColor("#D7D7E0")), ("FONTNAME", (0,0), (-1,-1), "Helvetica-Bold"), ("FONTSIZE", (0,0), (-1,-1), 9)]))
    story.append(t)
    story.append(Paragraph("Recommended Next Step", heading))
    story.append(Paragraph(proposal.next_step or "Approve proposal, schedule kickoff, and begin the SentinelRE Executive Risk Intelligence engagement.", normal))
    story.append(Spacer(1, 18))
    story.append(Paragraph("Acceptance", heading))
    story.append(Paragraph("Authorized Signature: ________________________________    Date: _______________", normal))
    story.append(Spacer(1, 8))
    story.append(Paragraph("Advisory Notice", heading))
    story.append(Paragraph("This proposal is for advisory and assessment services. It does not constitute a legal opinion, formal audit, certification, or guarantee of compliance. Final scope and pricing may be adjusted based on client requirements and confirmed assessment boundaries.", small))
    doc.build(story)
    buffer.seek(0)
    return buffer



# SentinelRE Phase 18 – Investor Management Models

class InvestorContact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    contact_name = db.Column(db.String(255))
    title = db.Column(db.String(120))
    email = db.Column(db.String(255))
    phone = db.Column(db.String(80))
    preferred_contact_method = db.Column(db.String(80))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class InvestorInteraction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    interaction_type = db.Column(db.String(120))
    subject = db.Column(db.String(255))
    notes = db.Column(db.Text)
    follow_up_required = db.Column(db.Boolean, default=False)
    follow_up_date = db.Column(db.Date)
    completed = db.Column(db.Boolean, default=False)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class InvestorPreference(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    target_markets = db.Column(db.Text)
    target_property_types = db.Column(db.Text)
    min_investment = db.Column(db.Float)
    max_investment = db.Column(db.Float)
    preferred_hold_period = db.Column(db.String(120))
    risk_profile = db.Column(db.String(120))
    return_target = db.Column(db.String(120))
    financing_preference = db.Column(db.String(120))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class InvestorOpportunityMatch(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    transaction_id = db.Column(db.Integer, db.ForeignKey("property_transaction.id"))
    match_score = db.Column(db.Float, default=0)
    readiness_status = db.Column(db.String(100), default="Review Needed")
    recommended_action = db.Column(db.String(255))
    matched_by = db.Column(db.String(120))
    matched_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)


class InvestorReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    report_title = db.Column(db.String(255))
    report_type = db.Column(db.String(120))
    report_status = db.Column(db.String(100), default="Draft")
    prepared_by = db.Column(db.String(120))
    approved_by = db.Column(db.String(120))
    approved_at = db.Column(db.DateTime)
    file_path = db.Column(db.String(500))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class InvestorDocument(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    investor_id = db.Column(db.Integer, db.ForeignKey("investor.id"))
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    filename = db.Column(db.String(255))
    document_type = db.Column(db.String(120))
    category = db.Column(db.String(120))
    status = db.Column(db.String(100), default="Uploaded")
    uploaded_by = db.Column(db.String(120))
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    file_path = db.Column(db.String(500))
    notes = db.Column(db.Text)




# SentinelRE Phase 19 – Property Risk Engine & Workflow Automation Models

class PropertyRiskAssessment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"), nullable=False)
    assessment_name = db.Column(db.String(255))
    assessment_status = db.Column(db.String(100), default="Draft")
    environmental_risk = db.Column(db.Float, default=0)
    insurance_risk = db.Column(db.Float, default=0)
    vacancy_risk = db.Column(db.Float, default=0)
    tenant_concentration_risk = db.Column(db.Float, default=0)
    market_risk = db.Column(db.Float, default=0)
    title_legal_risk = db.Column(db.Float, default=0)
    document_completeness_risk = db.Column(db.Float, default=0)
    physical_condition_risk = db.Column(db.Float, default=0)
    financing_risk = db.Column(db.Float, default=0)
    compliance_risk = db.Column(db.Float, default=0)
    overall_risk_score = db.Column(db.Float, default=0)
    risk_level = db.Column(db.String(50), default="Not Scored")
    executive_summary = db.Column(db.Text)
    recommendations = db.Column(db.Text)
    assessed_by = db.Column(db.String(120))
    assessed_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyRiskAction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey("property.id"))
    assessment_id = db.Column(db.Integer, db.ForeignKey("property_risk_assessment.id"))
    action_title = db.Column(db.String(255), nullable=False)
    action_category = db.Column(db.String(120))
    priority = db.Column(db.String(50), default="Medium")
    status = db.Column(db.String(100), default="Open")
    assigned_to = db.Column(db.String(120))
    due_date = db.Column(db.Date)
    completed_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class WorkflowRule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rule_name = db.Column(db.String(255), nullable=False)
    workflow_type = db.Column(db.String(120))
    trigger_event = db.Column(db.String(120))
    condition_field = db.Column(db.String(120))
    condition_operator = db.Column(db.String(50))
    condition_value = db.Column(db.String(255))
    action_type = db.Column(db.String(120))
    action_owner = db.Column(db.String(120))
    action_template = db.Column(db.Text)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class WorkflowTask(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    task_title = db.Column(db.String(255), nullable=False)
    task_type = db.Column(db.String(120))
    priority = db.Column(db.String(50), default="Medium")
    status = db.Column(db.String(100), default="Open")
    assigned_to = db.Column(db.String(120))
    due_date = db.Column(db.Date)
    completed_at = db.Column(db.DateTime)
    created_by = db.Column(db.String(120))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class WorkflowEventLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workflow_rule_id = db.Column(db.Integer, db.ForeignKey("workflow_rule.id"))
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    event_name = db.Column(db.String(255))
    event_status = db.Column(db.String(100))
    event_details = db.Column(db.Text)
    executed_by = db.Column(db.String(120))
    executed_at = db.Column(db.DateTime, default=datetime.utcnow)




# SentinelRE Phase 20 – Client Portal & E-Signature Models

class PortalUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(255))
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(80), default="Client")
    client_name = db.Column(db.String(255))
    investor_id = db.Column(db.Integer)
    property_id = db.Column(db.Integer)
    active = db.Column(db.Boolean, default=True)
    access_approved = db.Column(db.Boolean, default=False)
    last_login_at = db.Column(db.DateTime)
    last_login_ip = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class PortalMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    portal_user_id = db.Column(db.Integer, db.ForeignKey("portal_user.id"))
    sender = db.Column(db.String(120))
    subject = db.Column(db.String(255))
    message = db.Column(db.Text)
    status = db.Column(db.String(100), default="Unread")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PortalAccessLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    portal_user_id = db.Column(db.Integer, db.ForeignKey("portal_user.id"))
    event_type = db.Column(db.String(120))
    event_details = db.Column(db.Text)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SignatureRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    signer_name = db.Column(db.String(255))
    signer_email = db.Column(db.String(255))
    document_title = db.Column(db.String(255))
    document_type = db.Column(db.String(120))
    file_path = db.Column(db.String(500))
    status = db.Column(db.String(100), default="Pending Signature")
    requested_by = db.Column(db.String(120))
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    signed_by = db.Column(db.String(255))
    signed_at = db.Column(db.DateTime)
    signature_text = db.Column(db.String(255))
    signature_ip = db.Column(db.String(100))
    signature_hash = db.Column(db.String(255))
    notes = db.Column(db.Text)


class SignatureAuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signature_request_id = db.Column(db.Integer, db.ForeignKey("signature_request.id"))
    event_type = db.Column(db.String(120))
    event_details = db.Column(db.Text)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)




# SentinelRE Phase 21-24 Models – Commission, Reporting, Mapping/GIS, AI Executive Advisor

class CommissionPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    plan_name = db.Column(db.String(255), nullable=False)
    plan_type = db.Column(db.String(120))
    broker_split_percent = db.Column(db.Float, default=0)
    agent_split_percent = db.Column(db.Float, default=0)
    operations_split_percent = db.Column(db.Float, default=0)
    referral_fee_percent = db.Column(db.Float, default=0)
    minimum_broker_fee = db.Column(db.Float, default=0)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class CommissionRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.Integer)
    property_id = db.Column(db.Integer)
    agent_name = db.Column(db.String(120))
    broker_name = db.Column(db.String(120))
    gross_commission = db.Column(db.Float, default=0)
    broker_amount = db.Column(db.Float, default=0)
    agent_amount = db.Column(db.Float, default=0)
    operations_amount = db.Column(db.Float, default=0)
    referral_amount = db.Column(db.Float, default=0)
    net_company_revenue = db.Column(db.Float, default=0)
    payout_status = db.Column(db.String(100), default="Pending")
    payout_date = db.Column(db.Date)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class RealEstateReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    report_title = db.Column(db.String(255), nullable=False)
    report_type = db.Column(db.String(120))
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    report_status = db.Column(db.String(100), default="Draft")
    prepared_by = db.Column(db.String(120))
    approved_by = db.Column(db.String(120))
    approved_at = db.Column(db.DateTime)
    file_path = db.Column(db.String(500))
    executive_summary = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyGeoProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    neighborhood = db.Column(db.String(255))
    market_area = db.Column(db.String(255))
    flood_zone = db.Column(db.String(120))
    zoning = db.Column(db.String(120))
    opportunity_zone = db.Column(db.Boolean, default=False)
    census_tract = db.Column(db.String(120))
    traffic_count = db.Column(db.String(120))
    walkability_score = db.Column(db.Float)
    market_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class GISLayer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    layer_name = db.Column(db.String(255), nullable=False)
    layer_type = db.Column(db.String(120))
    description = db.Column(db.Text)
    source_name = db.Column(db.String(255))
    source_url = db.Column(db.String(500))
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorQuery(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(120))
    query_text = db.Column(db.Text, nullable=False)
    response_summary = db.Column(db.Text)
    query_category = db.Column(db.String(120))
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    confidence_note = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorInsight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    insight_title = db.Column(db.String(255), nullable=False)
    insight_type = db.Column(db.String(120))
    priority = db.Column(db.String(50), default="Medium")
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    insight_summary = db.Column(db.Text)
    recommended_action = db.Column(db.Text)
    status = db.Column(db.String(100), default="Open")
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)




# SentinelRE Phase 25 – E-Signature Legal Hardening & AI Advisor Upgrade Models

class SignatureCertificate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signature_request_id = db.Column(db.Integer, db.ForeignKey("signature_request.id"))
    certificate_number = db.Column(db.String(120))
    signer_name = db.Column(db.String(255))
    signer_email = db.Column(db.String(255))
    signed_at = db.Column(db.DateTime)
    ip_address = db.Column(db.String(100))
    user_agent = db.Column(db.Text)
    consent_text = db.Column(db.Text)
    document_hash = db.Column(db.String(255))
    signature_hash = db.Column(db.String(255))
    certificate_path = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SignatureIdentityVerification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signature_request_id = db.Column(db.Integer, db.ForeignKey("signature_request.id"))
    verification_method = db.Column(db.String(120))
    signer_email = db.Column(db.String(255))
    verification_code = db.Column(db.String(120))
    verified = db.Column(db.Boolean, default=False)
    verified_at = db.Column(db.DateTime)
    ip_address = db.Column(db.String(100))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SignatureEmailDelivery(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signature_request_id = db.Column(db.Integer, db.ForeignKey("signature_request.id"))
    recipient_email = db.Column(db.String(255))
    email_subject = db.Column(db.String(255))
    delivery_status = db.Column(db.String(100), default="Queued")
    sent_at = db.Column(db.DateTime)
    opened_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class LegalReviewItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    item_title = db.Column(db.String(255))
    item_type = db.Column(db.String(120))
    status = db.Column(db.String(100), default="Attorney Review Needed")
    assigned_to = db.Column(db.String(120))
    reviewed_by = db.Column(db.String(120))
    reviewed_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorSource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    source_name = db.Column(db.String(255))
    source_type = db.Column(db.String(120))
    source_table = db.Column(db.String(120))
    source_description = db.Column(db.Text)
    enabled = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorContextSnapshot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    query_id = db.Column(db.Integer)
    snapshot_title = db.Column(db.String(255))
    property_count = db.Column(db.Integer, default=0)
    open_risk_actions = db.Column(db.Integer, default=0)
    pending_signatures = db.Column(db.Integer, default=0)
    open_workflow_tasks = db.Column(db.Integer, default=0)
    projected_commission = db.Column(db.Float, default=0)
    compliance_items_open = db.Column(db.Integer, default=0)
    snapshot_json = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorRecommendation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    query_id = db.Column(db.Integer)
    recommendation_title = db.Column(db.String(255))
    recommendation_type = db.Column(db.String(120))
    priority = db.Column(db.String(50))
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    recommendation_text = db.Column(db.Text)
    status = db.Column(db.String(100), default="Open")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)




# SentinelRE Phase 26 – Interactive GIS Map Models

class MapView(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    view_name = db.Column(db.String(255), nullable=False)
    view_type = db.Column(db.String(120))
    default_latitude = db.Column(db.Float, default=26.1224)
    default_longitude = db.Column(db.Float, default=-80.1373)
    default_zoom = db.Column(db.Integer, default=10)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MapMarkerNote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer)
    marker_type = db.Column(db.String(120))
    note_title = db.Column(db.String(255))
    note_text = db.Column(db.Text)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MarketOverlay(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    overlay_name = db.Column(db.String(255), nullable=False)
    overlay_type = db.Column(db.String(120))
    market_area = db.Column(db.String(255))
    layer_color = db.Column(db.String(50))
    risk_level = db.Column(db.String(50))
    notes = db.Column(db.Text)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)




# SentinelRE Phase 27-30 Models – Production Readiness

class RouteValidationResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    route_path = db.Column(db.String(255))
    http_status = db.Column(db.Integer)
    validation_status = db.Column(db.String(50))
    validation_notes = db.Column(db.Text)
    tested_at = db.Column(db.DateTime, default=datetime.utcnow)


class LegalTemplateReview(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    template_name = db.Column(db.String(255), nullable=False)
    template_type = db.Column(db.String(120))
    legal_status = db.Column(db.String(100), default="Attorney Review Needed")
    reviewed_by = db.Column(db.String(120))
    reviewed_at = db.Column(db.DateTime)
    approved_for_use = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ESignComplianceControl(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    control_name = db.Column(db.String(255), nullable=False)
    control_area = db.Column(db.String(120))
    requirement_summary = db.Column(db.Text)
    implemented = db.Column(db.Boolean, default=False)
    attorney_review_required = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(100), default="Open")
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PortalMFAChallenge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    portal_user_id = db.Column(db.Integer)
    challenge_type = db.Column(db.String(120), default="Email OTP")
    challenge_code = db.Column(db.String(120))
    expires_at = db.Column(db.DateTime)
    verified = db.Column(db.Boolean, default=False)
    verified_at = db.Column(db.DateTime)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PortalAccessPolicy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    policy_name = db.Column(db.String(255), nullable=False)
    policy_type = db.Column(db.String(120))
    policy_description = db.Column(db.Text)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SecureDocumentToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer)
    portal_user_id = db.Column(db.Integer)
    token = db.Column(db.String(255))
    expires_at = db.Column(db.DateTime)
    used = db.Column(db.Boolean, default=False)
    used_at = db.Column(db.DateTime)
    ip_address = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIDataClassificationRule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rule_name = db.Column(db.String(255), nullable=False)
    data_type = db.Column(db.String(120))
    classification = db.Column(db.String(120))
    ai_access_allowed = db.Column(db.Boolean, default=False)
    redaction_required = db.Column(db.Boolean, default=True)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIGovernanceSetting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    setting_name = db.Column(db.String(255), nullable=False)
    setting_value = db.Column(db.String(255))
    setting_description = db.Column(db.Text)
    updated_by = db.Column(db.String(120))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIPromptAuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(120))
    prompt_text = db.Column(db.Text)
    response_summary = db.Column(db.Text)
    data_classification = db.Column(db.String(120))
    blocked = db.Column(db.Boolean, default=False)
    block_reason = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@app.route("/")
def home():
    return redirect(url_for("dashboard")) if current_user.is_authenticated else redirect(url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if current_user.is_authenticated: return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username","").strip()
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(request.form.get("password","")):
            if not user.can_access_system:
                log_audit(action="Login Blocked", object_type="User", object_id=user.id, result="Denied", new_value="Inactive or onboarding incomplete")
                db.session.commit()
                flash("Account access is not active. NDA/IP agreement, security training, and approval may be required.","danger")
                return render_template("login.html")
            login_user(user)
            user.last_login_at = datetime.utcnow()
            user.last_login_ip = request.headers.get("X-Forwarded-For", request.remote_addr)
            log_audit(action="Login", object_type="User", object_id=user.id)
            db.session.commit()
            flash("Signed in successfully.","success")
            return redirect(url_for("dashboard"))
        log_audit(action="Failed Login", object_type="User", object_id=username, result="Denied")
        db.session.commit()
        flash("Invalid username or password.","danger")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    log_audit(action="Logout", object_type="User", object_id=current_user.id)
    db.session.commit()
    logout_user(); flash("Signed out.","info"); return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
@require_permission("dashboard_view")
def dashboard():
    leads = Lead.query.order_by(Lead.created_at.desc()).limit(100).all()
    opportunities = Opportunity.query.order_by(Opportunity.created_at.desc()).limit(100).all()
    assessments = Assessment.query.order_by(Assessment.created_at.desc()).limit(100).all()
    proposals = Proposal.query.order_by(Proposal.created_at.desc()).limit(100).all()
    clients = Client.query.order_by(Client.created_at.desc()).limit(100).all()
    advisory_engagements = AdvisoryEngagement.query.order_by(AdvisoryEngagement.created_at.desc()).limit(100).all()
    renewals = RenewalRecord.query.order_by(RenewalRecord.created_at.desc()).limit(100).all()
    activities = ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(100).all()
    proposal_value = sum((p.one_time_fee or 0) for p in proposals if p.status not in ["Declined", "On Hold"])
    accepted_proposal_value = sum((p.one_time_fee or 0) for p in proposals if p.status == "Accepted")
    proposed_mrr = sum((p.monthly_retainer or 0) for p in proposals if p.status not in ["Declined", "On Hold"])
    pipeline_value = sum((lead.estimated_value or 0) for lead in leads) + sum((opp.estimated_value or 0) for opp in opportunities if opp.opportunity_stage not in ["Lost", "Deferred"])
    weighted_pipeline = sum((lead.estimated_value or 0) * (lead.probability or 0) for lead in leads) + sum((opp.estimated_value or 0) * (opp.probability or 0) for opp in opportunities if opp.opportunity_stage not in ["Lost", "Deferred"])
    advisory_mrr_actual = sum((a.monthly_fee or 0) for a in advisory_engagements if a.status == "Active" and a.billing_status != "Paused")
    monthly_retainer = advisory_mrr_actual if advisory_mrr_actual > 0 else sum((lead.monthly_retainer or 0) for lead in leads if lead.stage in ["Advisory Retainer", "Active Client", "Renewal"]) + sum((opp.monthly_retainer or 0) for opp in opportunities if opp.opportunity_stage == "Won") + sum((client.monthly_retainer or 0) for client in clients if client.client_status in ["Advisory Active", "Roadmap Active", "Renewal Pending", "Active Assessment", "Report Delivered"])
    active_clients = [client for client in clients if client.client_status not in ["Paused", "Closed"]]
    advisory_clients = [client for client in clients if client.client_status == "Advisory Active" or (client.monthly_retainer or 0) > 0]
    renewal_clients = [client for client in clients if client.client_status == "Renewal Pending" or (client.renewal_date or "")]
    total_contract_value = sum((client.total_contract_value or 0) for client in clients)
    salary_target = 8000
    salary_gap = max(salary_target - monthly_retainer, 0)
    open_opportunity_value = sum((opp.estimated_value or 0) for opp in opportunities if opp.opportunity_stage not in ["Won", "Lost", "Deferred"])
    advisory_arr = advisory_mrr_actual * 12
    active_advisory_count = len([a for a in advisory_engagements if a.status == "Active"])
    overdue_advisory_count = len([a for a in advisory_engagements if a.billing_status == "Overdue"])
    open_renewals = [r for r in renewals if r.renewal_stage not in ["Renewed", "Lost", "Deferred"]]
    renewal_pipeline_value = sum((r.renewal_value or r.current_annual_value or 0) for r in open_renewals)
    weighted_renewal_value = sum(r.weighted_renewal_value for r in open_renewals)
    at_risk_renewals = len([r for r in open_renewals if r.renewal_stage == "At Risk" or r.risk_level in ["High", "Critical"]])
    activity_count = len(activities)
    follow_up_count = len([a for a in activities if a.is_open_follow_up])
    meetings_scheduled = len([a for a in activities if a.outcome == "Meeting Scheduled"])
    proposal_requests = len([a for a in activities if a.outcome == "Proposal Requested"])
    closed_won_value = sum((opp.estimated_value or 0) for opp in opportunities if opp.opportunity_stage == "Won") + accepted_proposal_value
    closed_lost_count = len([opp for opp in opportunities if opp.opportunity_stage == "Lost"]) + len([p for p in proposals if p.status == "Declined"])
    discovery_count = len([opp for opp in opportunities if opp.opportunity_stage in ["Discovery", "Snapshot Delivered"]])
    proposal_sent_count = len([p for p in proposals if p.status == "Sent"])
    close_rate = (len([opp for opp in opportunities if opp.opportunity_stage == "Won"]) / max(len([opp for opp in opportunities if opp.opportunity_stage in ["Won", "Lost"]]), 1)) * 100
    client_health = build_client_health(clients, advisory_engagements, renewals, activities)
    renewal_risk = build_renewal_risk(renewals)
    trend_analytics = build_trend_analytics(leads, opportunities, proposals, clients, advisory_engagements, renewals, activities)
    email_preview = build_email_automation_preview()
    queued_emails = EmailAutomationLog.query.filter_by(status="Queued").count()
    sent_emails = EmailAutomationLog.query.filter_by(status="Sent").count()
    revenue_forecast = build_revenue_forecast(opportunities, proposals, advisory_engagements, renewals, salary_target=salary_target)
    last_automation_run = WorkflowAutomationRun.query.order_by(WorkflowAutomationRun.run_date.desc()).first()
    automation_preview = build_workflow_automation_preview()


    # Phase 5B Operations Metrics, Executive Forecasting, and SentinelRE Readiness
    today_dt = datetime.utcnow()
    current_month_key = today_dt.strftime("%Y-%m")

    def _parse_date_value(value):
        if not value:
            return None
        if isinstance(value, datetime):
            return value
        if isinstance(value, date):
            return datetime.combine(value, datetime.min.time())
        text = str(value).strip()
        for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m-%d-%Y", "%Y-%m", "%b %Y"):
            try:
                parsed = datetime.strptime(text, fmt)
                return parsed
            except Exception:
                continue
        return None

    operations_metrics = {
        "va_activity_count": len([
            a for a in activities
            if (a.owner or "").lower() not in ["", "admin", "clarkeu", "ursala", "dr. ursala clarke"]
        ]),
        "follow_ups_due": len([a for a in activities if a.is_open_follow_up]),
        "client_touchpoints": len([a for a in activities if a.client_id or (a.activity_type or "").lower() in ["client call", "client email", "advisory review", "follow-up"]]),
        "proposal_turnaround_days": 0,
    }
    turnaround_days = []
    for p in proposals:
        start_dt = _parse_date_value(p.created_at)
        end_dt = _parse_date_value(getattr(p, "sent_at", None)) or _parse_date_value(getattr(p, "approved_at", None))
        if start_dt and end_dt and end_dt >= start_dt:
            turnaround_days.append((end_dt - start_dt).days)
    operations_metrics["proposal_turnaround_days"] = round(sum(turnaround_days) / len(turnaround_days), 1) if turnaround_days else 0

    # Six-month monthly growth trend based on created records and accepted revenue.
    month_labels = []
    base_year = today_dt.year
    base_month = today_dt.month
    for offset in range(5, -1, -1):
        month = base_month - offset
        year = base_year
        while month <= 0:
            month += 12
            year -= 1
        month_labels.append(f"{year}-{month:02d}")

    monthly_growth_trend = []
    for month_key in month_labels:
        label_dt = datetime.strptime(month_key, "%Y-%m")
        new_leads = len([l for l in leads if _parse_date_value(l.created_at) and _parse_date_value(l.created_at).strftime("%Y-%m") == month_key])
        new_opportunities = len([o for o in opportunities if _parse_date_value(o.created_at) and _parse_date_value(o.created_at).strftime("%Y-%m") == month_key])
        new_proposals = len([p for p in proposals if _parse_date_value(p.created_at) and _parse_date_value(p.created_at).strftime("%Y-%m") == month_key])
        accepted_revenue_month = sum((p.one_time_fee or 0) for p in proposals if p.status == "Accepted" and _parse_date_value(p.created_at) and _parse_date_value(p.created_at).strftime("%Y-%m") == month_key)
        monthly_growth_trend.append({
            "label": label_dt.strftime("%b %Y"),
            "leads": new_leads,
            "opportunities": new_opportunities,
            "proposals": new_proposals,
            "accepted_revenue": accepted_revenue_month,
        })

    revenue_forecast_chart = [
        {"label": "30 Days", "value": revenue_forecast.forecast_30},
        {"label": "60 Days", "value": revenue_forecast.forecast_60},
        {"label": "90 Days", "value": revenue_forecast.forecast_90},
    ]

    stage_counts = {}
    for opp in opportunities:
        stage = opp.opportunity_stage or "Unspecified"
        stage_counts[stage] = stage_counts.get(stage, 0) + 1
    deal_stage_conversion = [
        {"stage": stage, "count": count}
        for stage, count in sorted(stage_counts.items(), key=lambda item: item[0])
    ]
    real_estate_readiness = {
        "enabled": False,
        "message": "Dashboard is prepared for a future SentinelRE™ tab without redesign. Add property intake, CRE deal pipeline, document vault, and property risk intelligence as the next vertical module.",
        "planned_tabs": ["Property Intake", "CRE Deal Pipeline", "Property Risk", "Document Vault", "Investor Reports"],
    }

    # Phase 5 Executive KPI and Approval Queue metrics
    pending_approval_statuses = ["Ready for Executive Review", "Pending Executive Review", "Pricing Required", "Draft"]
    pending_proposal_approvals = [
        p for p in proposals
        if getattr(p, "executive_approval_required", False)
        and (getattr(p, "approval_status", None) or "Draft") in pending_approval_statuses
        and p.status not in ["Declined", "Accepted", "Sent"]
    ]
    proposals_awaiting_pricing = [
        p for p in proposals
        if not getattr(p, "pricing_locked", False)
        and (p.one_time_fee or 0) == 0
        and (p.monthly_retainer or 0) == 0
        and p.status not in ["Declined", "Accepted", "Sent"]
    ]
    approved_not_sent = [
        p for p in proposals
        if (getattr(p, "approval_status", "") == "Approved")
        and p.status not in ["Sent", "Accepted", "Declined"]
    ]
    regulatory_assessments = RegulatoryReadinessAssessment.query.order_by(RegulatoryReadinessAssessment.created_at.desc()).limit(25).all()
    open_compliance_actions = ComplianceActionItem.query.filter(ComplianceActionItem.status != "Closed").order_by(ComplianceActionItem.created_at.desc()).limit(25).all()
    if regulatory_assessments:
        avg_regulatory_score = sum((r.overall_score or 0) for r in regulatory_assessments) / max(len(regulatory_assessments), 1)
    else:
        avg_regulatory_score = 0
    regulatory_kpis = {
        "avg_score": avg_regulatory_score,
        "readiness_band": readiness_band(avg_regulatory_score),
        "assessments": len(regulatory_assessments),
        "open_actions": len(open_compliance_actions),
        "high_risk": len([r for r in regulatory_assessments if r.risk_level in ["High", "Critical"] or (r.overall_score or 0) < 50]),
    }

    executive_kpis = {
        "forecast_90": revenue_forecast.forecast_90,
        "pipeline_value": pipeline_value,
        "weighted_pipeline": weighted_pipeline,
        "proposal_value": proposal_value,
        "accepted_revenue": accepted_proposal_value,
        "proposed_mrr": proposed_mrr,
        "active_clients": len(active_clients),
        "pending_approvals": len(pending_proposal_approvals),
        "awaiting_pricing": len(proposals_awaiting_pricing),
        "approved_not_sent": len(approved_not_sent),
    }

    return render_template("dashboard.html", regulatory_kpis=regulatory_kpis, regulatory_assessments=regulatory_assessments, open_compliance_actions=open_compliance_actions, operations_metrics=operations_metrics, revenue_forecast_chart=revenue_forecast_chart, monthly_growth_trend=monthly_growth_trend, deal_stage_conversion=deal_stage_conversion, real_estate_readiness=real_estate_readiness, revenue_forecast=revenue_forecast, last_automation_run=last_automation_run, automation_preview=automation_preview, executive_kpis=executive_kpis, pending_proposal_approvals=pending_proposal_approvals, proposals_awaiting_pricing=proposals_awaiting_pricing, approved_not_sent=approved_not_sent, leads=leads, opportunities=opportunities, assessments=assessments, proposals=proposals, clients=clients, advisory_engagements=advisory_engagements, renewals=renewals, activities=activities, client_health=client_health, renewal_risk=renewal_risk, trend_analytics=trend_analytics, email_preview=email_preview, queued_emails=queued_emails, sent_emails=sent_emails, activity_count=activity_count, follow_up_count=follow_up_count, meetings_scheduled=meetings_scheduled, proposal_requests=proposal_requests, closed_won_value=closed_won_value, closed_lost_count=closed_lost_count, discovery_count=discovery_count, proposal_sent_count=proposal_sent_count, close_rate=close_rate, open_renewals=open_renewals, renewal_pipeline_value=renewal_pipeline_value, weighted_renewal_value=weighted_renewal_value, at_risk_renewals=at_risk_renewals, active_clients=active_clients, advisory_clients=advisory_clients, renewal_clients=renewal_clients, total_contract_value=total_contract_value, proposal_value=proposal_value, accepted_proposal_value=accepted_proposal_value, proposed_mrr=proposed_mrr, pipeline_value=pipeline_value, weighted_pipeline=weighted_pipeline, monthly_retainer=monthly_retainer, advisory_mrr_actual=advisory_mrr_actual, advisory_arr=advisory_arr, active_advisory_count=active_advisory_count, overdue_advisory_count=overdue_advisory_count, salary_target=salary_target, salary_gap=salary_gap, open_opportunity_value=open_opportunity_value)

@app.route("/crm", methods=["GET","POST"])
@login_required
@require_permission("crm_view")
def crm():
    if request.method == "POST" and not user_has_permission(current_user, "crm_edit"):
        log_audit(action="Permission Denied", object_type="crm", result="Denied", new_value="crm_edit")
        db.session.commit()
        flash("Access denied for this edit action.", "danger")
        return redirect(url_for("crm"))
    if request.method == "POST":
        lead = Lead(
            client_name=request.form.get("client_name","").strip(),
            contact_name=request.form.get("contact_name","").strip(),
            email=request.form.get("email","").strip(),
            phone=request.form.get("phone","").strip(),
            industry=request.form.get("industry","").strip(),
            state=request.form.get("state","").strip(),
            lead_source=request.form.get("lead_source","").strip(),
            stage=request.form.get("stage","Lead"),
            priority=request.form.get("priority","B - Nurture"),
            recommended_offer=request.form.get("recommended_offer","Property Risk Snapshot"),
            probability=float(request.form.get("probability",0.25) or 0.25),
            estimated_value=float(request.form.get("estimated_value",0) or 0),
            monthly_retainer=float(request.form.get("monthly_retainer",0) or 0),
            next_follow_up=request.form.get("next_follow_up","").strip(),
            notes=request.form.get("notes","").strip()
        )
        db.session.add(lead); safe_commit("Lead Created", "Lead", lead.client_name, new_value=lead.email); flash("Opportunity saved.","success"); return redirect(url_for("crm"))
    leads = Lead.query.order_by(Lead.created_at.desc()).all()
    return render_template("crm.html", leads=leads, stages=LIFECYCLE_STAGES, priorities=PRIORITY_LEVELS, offers=OFFER_TYPES)

@app.route("/opportunities", methods=["GET","POST"])
@login_required
@require_permission("opportunity_view")
def opportunities():
    leads = Lead.query.order_by(Lead.client_name.asc()).all()
    if request.method == "POST":
        selected_lead = None
        lead_id_raw = request.form.get("lead_id")
        if lead_id_raw:
            try:
                selected_lead = db.session.get(Lead, int(lead_id_raw))
            except Exception:
                selected_lead = None
        opp = Opportunity(
            lead_id=selected_lead.id if selected_lead else None,
            company_name=request.form.get("company_name", "").strip() or (selected_lead.client_name if selected_lead else "Unnamed Opportunity"),
            contact_name=request.form.get("contact_name", "").strip() or (selected_lead.contact_name if selected_lead else ""),
            email=request.form.get("email", "").strip() or (selected_lead.email if selected_lead else ""),
            phone=request.form.get("phone", "").strip() or (selected_lead.phone if selected_lead else ""),
            industry=request.form.get("industry", "").strip() or (selected_lead.industry if selected_lead else ""),
            service_type=request.form.get("service_type", "Property Risk Snapshot"),
            opportunity_stage=request.form.get("opportunity_stage", "Discovery"),
            proposal_status=request.form.get("proposal_status", "Not Started"),
            estimated_value=float(request.form.get("estimated_value", 0) or 0),
            probability=float(request.form.get("probability", 0.25) or 0.25),
            expected_close_date=request.form.get("expected_close_date", "").strip(),
            monthly_retainer=float(request.form.get("monthly_retainer", 0) or 0),
            next_step=request.form.get("next_step", "").strip(),
            owner=request.form.get("owner", current_user.username).strip() or current_user.username,
            notes=request.form.get("notes", "").strip(),
        )
        db.session.add(opp)
        if selected_lead and selected_lead.stage in ["Lead", "Qualified", "Discovery Scheduled", "Snapshot Delivered"]:
            selected_lead.stage = "Proposal Sent" if opp.opportunity_stage == "Proposal Sent" else selected_lead.stage
        safe_commit("Opportunity Created", "Opportunity", opp.company_name, new_value=f"{opp.service_type} / ${opp.estimated_value}")
        flash("Opportunity record created.", "success")
        return redirect(url_for("opportunities"))
    opportunity_records = Opportunity.query.order_by(Opportunity.created_at.desc()).all()
    total_value = sum((opp.estimated_value or 0) for opp in opportunity_records if opp.opportunity_stage not in ["Lost", "Deferred"])
    weighted_value = sum((opp.estimated_value or 0) * (opp.probability or 0) for opp in opportunity_records if opp.opportunity_stage not in ["Lost", "Deferred"])
    potential_mrr = sum((opp.monthly_retainer or 0) for opp in opportunity_records if opp.opportunity_stage not in ["Lost", "Deferred"])
    return render_template("opportunities.html", opportunities=opportunity_records, leads=leads, stages=OPPORTUNITY_STAGES, proposal_statuses=PROPOSAL_STATUSES, offers=OFFER_TYPES, total_value=total_value, weighted_value=weighted_value, potential_mrr=potential_mrr)


@app.route("/proposals", methods=["GET", "POST"])
@login_required
@require_permission("proposal_view")
def proposals():
    opportunities = Opportunity.query.order_by(Opportunity.company_name.asc()).all()
    if request.method == "POST":
        selected_opp = None
        opp_id_raw = request.form.get("opportunity_id")
        if opp_id_raw:
            try:
                selected_opp = db.session.get(Opportunity, int(opp_id_raw))
            except Exception:
                selected_opp = None
        proposal_type = request.form.get("proposal_type", "Property Readiness Review")
        proposal = Proposal(
            opportunity_id=selected_opp.id if selected_opp else None,
            proposal_number=request.form.get("proposal_number", "").strip() or f"SOP-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            client_name=request.form.get("client_name", "").strip() or (selected_opp.company_name if selected_opp else "Unnamed Client"),
            contact_name=request.form.get("contact_name", "").strip() or (selected_opp.contact_name if selected_opp else ""),
            email=request.form.get("email", "").strip() or (selected_opp.email if selected_opp else ""),
            industry=request.form.get("industry", "").strip() or (selected_opp.industry if selected_opp else ""),
            proposal_type=proposal_type,
            status=request.form.get("status", "Draft"),
            scope=request.form.get("scope", "").strip() or default_scope(proposal_type),
            deliverables=request.form.get("deliverables", "").strip() or default_deliverables(proposal_type),
            timeline=request.form.get("timeline", "10 business days").strip(),
            one_time_fee=float(request.form.get("one_time_fee", 0) or 0),
            monthly_retainer=float(request.form.get("monthly_retainer", 0) or 0),
            payment_terms=request.form.get("payment_terms", "50% Upfront / 50% Upon Delivery"),
            valid_until=request.form.get("valid_until", "").strip(),
            next_step=request.form.get("next_step", "").strip(),
            prepared_by=request.form.get("prepared_by", current_user.username).strip() or current_user.username,
            notes=request.form.get("notes", "").strip(),
        )
        db.session.add(proposal)
        if selected_opp:
            selected_opp.proposal_status = "Sent" if proposal.status == "Sent" else "Drafting"
            if proposal.status == "Sent":
                selected_opp.opportunity_stage = "Proposal Sent"
            if proposal.status == "Accepted":
                selected_opp.opportunity_stage = "Won"
                selected_opp.proposal_status = "Approved"
        safe_commit("Proposal Created", "Proposal", proposal.proposal_number, new_value=f"{proposal.client_name} / {proposal.status}")
        flash("Proposal created.", "success")
        return redirect(url_for("proposals"))
    proposal_records = Proposal.query.order_by(Proposal.created_at.desc()).all()
    total_proposed = sum((p.one_time_fee or 0) for p in proposal_records if p.status not in ["Declined", "On Hold"])
    total_mrr = sum((p.monthly_retainer or 0) for p in proposal_records if p.status not in ["Declined", "On Hold"])
    first_year = sum(p.total_first_year_value for p in proposal_records if p.status not in ["Declined", "On Hold"])
    accepted = sum((p.one_time_fee or 0) for p in proposal_records if p.status == "Accepted")
    return render_template("proposals.html", proposals=proposal_records, opportunities=opportunities, proposal_types=PROPOSAL_TYPES, statuses=PROPOSAL_STATUSES_FULL, payment_terms=PAYMENT_TERMS, total_proposed=total_proposed, total_mrr=total_mrr, first_year=first_year, accepted=accepted)

@app.route("/proposal/<int:proposal_id>/pdf")
@login_required
@require_permission("export_reports")
def proposal_pdf(proposal_id):
    proposal = Proposal.query.get_or_404(proposal_id)
    pdf_buffer = build_proposal_pdf(proposal)
    if pdf_buffer is None:
        flash("PDF generation requires reportlab.", "warning")
        return redirect(url_for("proposals"))
    log_audit(action="Export Report", object_type="Proposal", object_id=proposal.id, new_value=proposal.client_name)
    db.session.commit()
    return send_file(pdf_buffer, as_attachment=True, download_name=f"SentinelRE_{proposal.client_name.replace(' ', '_')}_Proposal.pdf", mimetype="application/pdf")

@app.route("/clients", methods=["GET", "POST"])
@login_required
@require_permission("client_view")
def clients():
    leads = Lead.query.order_by(Lead.client_name.asc()).all()
    opportunities = Opportunity.query.order_by(Opportunity.company_name.asc()).all()
    proposals = Proposal.query.order_by(Proposal.client_name.asc()).all()
    if request.method == "POST":
        selected_lead = None
        selected_opp = None
        selected_proposal = None
        if request.form.get("lead_id"):
            try: selected_lead = db.session.get(Lead, int(request.form.get("lead_id")))
            except Exception: selected_lead = None
        if request.form.get("opportunity_id"):
            try: selected_opp = db.session.get(Opportunity, int(request.form.get("opportunity_id")))
            except Exception: selected_opp = None
        if request.form.get("proposal_id"):
            try: selected_proposal = db.session.get(Proposal, int(request.form.get("proposal_id")))
            except Exception: selected_proposal = None
        client = Client(
            lead_id=selected_lead.id if selected_lead else None,
            opportunity_id=selected_opp.id if selected_opp else None,
            proposal_id=selected_proposal.id if selected_proposal else None,
            client_name=request.form.get("client_name", "").strip() or (selected_proposal.client_name if selected_proposal else selected_opp.company_name if selected_opp else selected_lead.client_name if selected_lead else "Unnamed Client"),
            contact_name=request.form.get("contact_name", "").strip() or (selected_proposal.contact_name if selected_proposal else selected_opp.contact_name if selected_opp else selected_lead.contact_name if selected_lead else ""),
            email=request.form.get("email", "").strip() or (selected_proposal.email if selected_proposal else selected_opp.email if selected_opp else selected_lead.email if selected_lead else ""),
            phone=request.form.get("phone", "").strip() or (selected_opp.phone if selected_opp else selected_lead.phone if selected_lead else ""),
            industry=request.form.get("industry", "").strip() or (selected_proposal.industry if selected_proposal else selected_opp.industry if selected_opp else selected_lead.industry if selected_lead else ""),
            lifecycle_phase=request.form.get("lifecycle_phase", "Client"),
            client_status=request.form.get("client_status", "Onboarding"),
            service_package=request.form.get("service_package", "Property Readiness Review"),
            start_date=request.form.get("start_date", "").strip(),
            assessment_due_date=request.form.get("assessment_due_date", "").strip(),
            report_due_date=request.form.get("report_due_date", "").strip(),
            roadmap_review_date=request.form.get("roadmap_review_date", "").strip(),
            next_advisory_session=request.form.get("next_advisory_session", "").strip(),
            renewal_date=request.form.get("renewal_date", "").strip(),
            monthly_retainer=float(request.form.get("monthly_retainer", 0) or 0),
            total_contract_value=float(request.form.get("total_contract_value", 0) or 0),
            review_cadence=request.form.get("review_cadence", "Quarterly"),
            owner=request.form.get("owner", current_user.username).strip() or current_user.username,
            open_actions=int(request.form.get("open_actions", 0) or 0),
            risk_priority=request.form.get("risk_priority", "Moderate"),
            notes=request.form.get("notes", "").strip(),
        )
        db.session.add(client)
        if selected_lead:
            selected_lead.stage = "Active Client" if client.client_status in ["Active Assessment", "Report Delivered", "Roadmap Active", "Advisory Active"] else selected_lead.stage
            selected_lead.monthly_retainer = client.monthly_retainer or selected_lead.monthly_retainer
        if selected_opp:
            selected_opp.opportunity_stage = "Won" if client.client_status not in ["Paused", "Closed"] else selected_opp.opportunity_stage
            selected_opp.monthly_retainer = client.monthly_retainer or selected_opp.monthly_retainer
        if selected_proposal:
            selected_proposal.status = "Accepted" if client.client_status not in ["Paused", "Closed"] else selected_proposal.status
        db.session.commit()
        flash("Client lifecycle record created.", "success")
        return redirect(url_for("clients"))
    client_records = Client.query.order_by(Client.created_at.desc()).all()
    active_count = len([c for c in client_records if c.client_status not in ["Paused", "Closed"]])
    advisory_mrr = sum((c.monthly_retainer or 0) for c in client_records if c.client_status == "Advisory Active" or (c.monthly_retainer or 0) > 0)
    renewal_count = len([c for c in client_records if c.client_status == "Renewal Pending" or (c.renewal_date or "")])
    total_value = sum((c.total_contract_value or 0) for c in client_records)
    return render_template("clients.html", clients=client_records, leads=leads, opportunities=opportunities, proposals=proposals, statuses=CLIENT_STATUS, phases=LIFECYCLE_PHASES, offers=OFFER_TYPES, cadence=REVIEW_CADENCE, active_count=active_count, advisory_mrr=advisory_mrr, renewal_count=renewal_count, total_value=total_value)

@app.route("/proposal/<int:proposal_id>/convert-client")
@login_required
@require_permission("client_edit")
def convert_proposal_to_client(proposal_id):
    proposal = Proposal.query.get_or_404(proposal_id)
    existing = Client.query.filter_by(proposal_id=proposal.id).first()
    if existing:
        flash("Client record already exists for this proposal.", "info")
        return redirect(url_for("clients"))
    opp = proposal.opportunity
    client = Client(
        proposal_id=proposal.id,
        opportunity_id=opp.id if opp else None,
        lead_id=opp.lead_id if opp else None,
        client_name=proposal.client_name,
        contact_name=proposal.contact_name,
        email=proposal.email,
        industry=proposal.industry,
        lifecycle_phase="Client",
        client_status="Onboarding" if proposal.monthly_retainer == 0 else "Advisory Active",
        service_package=proposal.proposal_type,
        start_date=date.today().isoformat(),
        monthly_retainer=proposal.monthly_retainer or 0,
        total_contract_value=proposal.total_first_year_value,
        review_cadence="Quarterly",
        owner=current_user.username,
        open_actions=3,
        risk_priority="High" if "Federal" in proposal.proposal_type or "Advance" in proposal.proposal_type else "Moderate",
        notes="Converted from accepted proposal. Next steps: kickoff, assessment schedule, report delivery, roadmap review, and advisory cadence."
    )
    proposal.status = "Accepted"
    if opp:
        opp.opportunity_stage = "Won"
        opp.proposal_status = "Approved"
    db.session.add(client)
    db.session.commit()
    flash("Proposal converted to client lifecycle record.", "success")
    return redirect(url_for("clients"))


@app.route("/advisory", methods=["GET", "POST"])
@login_required
@require_permission("advisory_view")
def advisory():
    clients = Client.query.order_by(Client.client_name.asc()).all()
    if request.method == "POST":
        selected_client = None
        if request.form.get("client_id"):
            try:
                selected_client = db.session.get(Client, int(request.form.get("client_id")))
            except Exception:
                selected_client = None
        engagement = AdvisoryEngagement(
            client_id=selected_client.id if selected_client else None,
            client_name=request.form.get("client_name", "").strip() or (selected_client.client_name if selected_client else "Unnamed Advisory Client"),
            contact_name=request.form.get("contact_name", "").strip() or (selected_client.contact_name if selected_client else ""),
            email=request.form.get("email", "").strip() or (selected_client.email if selected_client else ""),
            service_type=request.form.get("service_type", "Broker Advisory"),
            status=request.form.get("status", "Active"),
            billing_status=request.form.get("billing_status", "Current"),
            monthly_fee=float(request.form.get("monthly_fee", 0) or 0),
            start_date=request.form.get("start_date", "").strip(),
            next_invoice_date=request.form.get("next_invoice_date", "").strip(),
            last_payment_date=request.form.get("last_payment_date", "").strip(),
            next_review_date=request.form.get("next_review_date", "").strip(),
            renewal_date=request.form.get("renewal_date", "").strip(),
            review_cadence=request.form.get("review_cadence", "Monthly"),
            owner=request.form.get("owner", current_user.username).strip() or current_user.username,
            open_actions=int(request.form.get("open_actions", 0) or 0),
            health_status=request.form.get("health_status", "Stable"),
            notes=request.form.get("notes", "").strip(),
        )
        db.session.add(engagement)
        if selected_client:
            selected_client.client_status = "Advisory Active" if engagement.status == "Active" else selected_client.client_status
            selected_client.monthly_retainer = engagement.monthly_fee or selected_client.monthly_retainer
            selected_client.next_advisory_session = engagement.next_review_date or selected_client.next_advisory_session
            selected_client.renewal_date = engagement.renewal_date or selected_client.renewal_date
        db.session.commit()
        flash("Advisory revenue record created.", "success")
        return redirect(url_for("advisory"))
    engagements = AdvisoryEngagement.query.order_by(AdvisoryEngagement.created_at.desc()).all()
    active_engagements = [a for a in engagements if a.status == "Active"]
    advisory_mrr = sum((a.monthly_fee or 0) for a in active_engagements if a.billing_status != "Paused")
    advisory_arr = advisory_mrr * 12
    paid_mrr = sum((a.monthly_fee or 0) for a in engagements if a.billing_status == "Paid")
    at_risk_mrr = sum((a.monthly_fee or 0) for a in engagements if a.status == "At Risk" or a.billing_status == "Overdue")
    salary_target = 8000
    salary_gap = max(salary_target - advisory_mrr, 0)
    return render_template("advisory.html", clients=clients, engagements=engagements, service_types=ADVISORY_SERVICE_TYPES, statuses=ADVISORY_STATUS, billing_statuses=BILLING_STATUS, cadence=REVIEW_CADENCE, advisory_mrr=advisory_mrr, advisory_arr=advisory_arr, paid_mrr=paid_mrr, at_risk_mrr=at_risk_mrr, salary_target=salary_target, salary_gap=salary_gap, active_count=len(active_engagements))


@app.route("/renewals", methods=["GET", "POST"])
@login_required
@require_permission("renewal_view")
def renewals():
    clients = Client.query.order_by(Client.client_name.asc()).all()
    advisory_engagements = AdvisoryEngagement.query.order_by(AdvisoryEngagement.client_name.asc()).all()
    if request.method == "POST":
        selected_client = None
        selected_advisory = None
        if request.form.get("client_id"):
            try:
                selected_client = db.session.get(Client, int(request.form.get("client_id")))
            except Exception:
                selected_client = None
        if request.form.get("advisory_id"):
            try:
                selected_advisory = db.session.get(AdvisoryEngagement, int(request.form.get("advisory_id")))
            except Exception:
                selected_advisory = None
        current_fee = float(request.form.get("current_monthly_fee", 0) or 0)
        proposed_fee = float(request.form.get("proposed_monthly_fee", 0) or 0)
        renewal_value = float(request.form.get("renewal_value", 0) or 0)
        if selected_advisory and current_fee == 0:
            current_fee = selected_advisory.monthly_fee or 0
        if selected_client and current_fee == 0:
            current_fee = selected_client.monthly_retainer or 0
        if proposed_fee == 0:
            proposed_fee = current_fee
        if renewal_value == 0:
            renewal_value = proposed_fee * 12
        record = RenewalRecord(
            client_id=selected_client.id if selected_client else (selected_advisory.client_id if selected_advisory else None),
            advisory_id=selected_advisory.id if selected_advisory else None,
            client_name=request.form.get("client_name", "").strip() or (selected_advisory.client_name if selected_advisory else selected_client.client_name if selected_client else "Unnamed Renewal"),
            contact_name=request.form.get("contact_name", "").strip() or (selected_advisory.contact_name if selected_advisory else selected_client.contact_name if selected_client else ""),
            email=request.form.get("email", "").strip() or (selected_advisory.email if selected_advisory else selected_client.email if selected_client else ""),
            renewal_type=request.form.get("renewal_type", "Advisory Retainer Renewal"),
            renewal_stage=request.form.get("renewal_stage", "Upcoming"),
            renewal_date=request.form.get("renewal_date", "").strip(),
            reminder_date=request.form.get("reminder_date", "").strip(),
            current_monthly_fee=current_fee,
            proposed_monthly_fee=proposed_fee,
            current_annual_value=current_fee * 12,
            renewal_value=renewal_value,
            probability=float(request.form.get("probability", 0.75) or 0.75),
            risk_level=request.form.get("risk_level", "Moderate"),
            health_status=request.form.get("health_status", "Stable"),
            owner=request.form.get("owner", current_user.username).strip() or current_user.username,
            next_step=request.form.get("next_step", "").strip(),
            outcome=request.form.get("outcome", "").strip(),
            notes=request.form.get("notes", "").strip(),
        )
        db.session.add(record)
        if selected_client:
            selected_client.renewal_date = record.renewal_date or selected_client.renewal_date
            selected_client.client_status = "Renewal Pending" if record.renewal_stage in ["Renewal Review", "Proposal Needed", "Proposal Sent", "Negotiation"] else selected_client.client_status
            selected_client.monthly_retainer = record.proposed_monthly_fee or selected_client.monthly_retainer
        if selected_advisory:
            selected_advisory.renewal_date = record.renewal_date or selected_advisory.renewal_date
            selected_advisory.health_status = record.health_status or selected_advisory.health_status
            selected_advisory.monthly_fee = record.proposed_monthly_fee or selected_advisory.monthly_fee
            if record.renewal_stage == "At Risk":
                selected_advisory.status = "At Risk"
            if record.renewal_stage == "Renewed":
                selected_advisory.status = "Active"
                selected_advisory.billing_status = "Current"
        db.session.commit()
        flash("Renewal record created.", "success")
        return redirect(url_for("renewals"))
    renewal_records = RenewalRecord.query.order_by(RenewalRecord.created_at.desc()).all()
    open_renewals = [r for r in renewal_records if r.renewal_stage not in ["Renewed", "Lost", "Deferred"]]
    renewed = [r for r in renewal_records if r.renewal_stage == "Renewed"]
    at_risk = [r for r in open_renewals if r.renewal_stage == "At Risk" or r.risk_level in ["High", "Critical"]]
    renewal_pipeline_value = sum((r.renewal_value or r.current_annual_value or 0) for r in open_renewals)
    weighted_value = sum(r.weighted_renewal_value for r in open_renewals)
    retained_mrr = sum((r.projected_mrr or 0) for r in renewed)
    open_mrr = sum((r.projected_mrr or 0) for r in open_renewals)
    return render_template("renewals.html", clients=clients, advisory_engagements=advisory_engagements, renewals=renewal_records, open_renewals=open_renewals, renewed=renewed, at_risk=at_risk, renewal_types=RENEWAL_TYPES, renewal_stages=RENEWAL_STAGES, risk_levels=RENEWAL_RISK_LEVELS, renewal_pipeline_value=renewal_pipeline_value, weighted_value=weighted_value, retained_mrr=retained_mrr, open_mrr=open_mrr)


@app.route("/activities", methods=["GET", "POST"])
@login_required
@require_permission("activity_view")
def activities():
    leads = Lead.query.order_by(Lead.client_name.asc()).all()
    opportunities = Opportunity.query.order_by(Opportunity.company_name.asc()).all()
    proposals = Proposal.query.order_by(Proposal.client_name.asc()).all()
    clients = Client.query.order_by(Client.client_name.asc()).all()
    advisory_engagements = AdvisoryEngagement.query.order_by(AdvisoryEngagement.client_name.asc()).all()
    if request.method == "POST":
        selected_lead = db.session.get(Lead, int(request.form.get("lead_id"))) if request.form.get("lead_id") else None
        selected_opp = db.session.get(Opportunity, int(request.form.get("opportunity_id"))) if request.form.get("opportunity_id") else None
        selected_proposal = db.session.get(Proposal, int(request.form.get("proposal_id"))) if request.form.get("proposal_id") else None
        selected_client = db.session.get(Client, int(request.form.get("client_id"))) if request.form.get("client_id") else None
        selected_advisory = db.session.get(AdvisoryEngagement, int(request.form.get("advisory_id"))) if request.form.get("advisory_id") else None
        related_name = request.form.get("related_name", "").strip()
        contact_name = request.form.get("contact_name", "").strip()
        if not related_name:
            related_name = (selected_client.client_name if selected_client else selected_advisory.client_name if selected_advisory else selected_proposal.client_name if selected_proposal else selected_opp.company_name if selected_opp else selected_lead.client_name if selected_lead else "")
        if not contact_name:
            contact_name = (selected_client.contact_name if selected_client else selected_advisory.contact_name if selected_advisory else selected_proposal.contact_name if selected_proposal else selected_opp.contact_name if selected_opp else selected_lead.contact_name if selected_lead else "")
        item = ActivityLog(
            lead_id=selected_lead.id if selected_lead else None,
            opportunity_id=selected_opp.id if selected_opp else None,
            proposal_id=selected_proposal.id if selected_proposal else None,
            client_id=selected_client.id if selected_client else None,
            advisory_id=selected_advisory.id if selected_advisory else None,
            activity_date=request.form.get("activity_date", "").strip() or date.today().isoformat(),
            activity_type=request.form.get("activity_type", "Call"),
            subject=request.form.get("subject", "").strip() or "Business development activity",
            related_name=related_name,
            contact_name=contact_name,
            outcome=request.form.get("outcome", "Completed"),
            priority=request.form.get("priority", "Medium"),
            next_follow_up=request.form.get("next_follow_up", "").strip(),
            owner=request.form.get("owner", current_user.username).strip() or current_user.username,
            notes=request.form.get("notes", "").strip(),
        )
        db.session.add(item)
        if selected_lead and item.next_follow_up:
            selected_lead.next_follow_up = item.next_follow_up
        if selected_opp and item.outcome == "Proposal Requested":
            selected_opp.proposal_status = "Drafting"
            selected_opp.opportunity_stage = "Proposal Drafting"
        db.session.commit()
        flash("Activity logged.", "success")
        return redirect(url_for("activities"))
    activity_records = ActivityLog.query.order_by(ActivityLog.created_at.desc()).all()
    open_followups = [a for a in activity_records if a.is_open_follow_up]
    return render_template("activities.html", activities=activity_records, open_followups=open_followups, leads=leads, opportunities=opportunities, proposals=proposals, clients=clients, advisory_engagements=advisory_engagements, activity_types=ACTIVITY_TYPES, outcomes=ACTIVITY_OUTCOMES, priorities=ACTIVITY_PRIORITIES)

@app.route("/kpis")
@login_required
@require_permission("kpi_view")
def kpis():
    leads = Lead.query.all()
    opportunities = Opportunity.query.all()
    proposals = Proposal.query.all()
    clients = Client.query.all()
    advisory_engagements = AdvisoryEngagement.query.all()
    renewals = RenewalRecord.query.all()
    activities = ActivityLog.query.all()
    active_opps = [o for o in opportunities if o.opportunity_stage not in ["Won", "Lost", "Deferred"]]
    won_opps = [o for o in opportunities if o.opportunity_stage == "Won"]
    lost_opps = [o for o in opportunities if o.opportunity_stage == "Lost"]
    active_advisory = [a for a in advisory_engagements if a.status == "Active" and a.billing_status != "Paused"]
    open_renewals = [r for r in renewals if r.renewal_stage not in ["Renewed", "Lost", "Deferred"]]
    metrics = {
        "total_leads": len(leads),
        "a_tier_leads": len([l for l in leads if (l.priority or "").startswith("A")]),
        "open_opportunities": len(active_opps),
        "pipeline_value": sum((o.estimated_value or 0) for o in active_opps),
        "weighted_pipeline": sum(o.weighted_value for o in active_opps),
        "proposals_sent": len([p for p in proposals if p.status == "Sent"]),
        "proposals_accepted": len([p for p in proposals if p.status == "Accepted"]),
        "proposal_value": sum((p.one_time_fee or 0) for p in proposals if p.status not in ["Declined", "On Hold"]),
        "clients": len(clients),
        "active_clients": len([c for c in clients if c.client_status not in ["Paused", "Closed"]]),
        "advisory_mrr": sum((a.monthly_fee or 0) for a in active_advisory),
        "advisory_arr": sum((a.monthly_fee or 0) for a in active_advisory) * 12,
        "open_renewals": len(open_renewals),
        "renewal_pipeline": sum((r.renewal_value or r.current_annual_value or 0) for r in open_renewals),
        "activities": len(activities),
        "open_followups": len([a for a in activities if a.is_open_follow_up]),
        "meetings_scheduled": len([a for a in activities if a.outcome == "Meeting Scheduled"]),
        "proposal_requests": len([a for a in activities if a.outcome == "Proposal Requested"]),
        "close_rate": (len(won_opps) / max(len(won_opps) + len(lost_opps), 1)) * 100,
        "salary_target": 8000,
    }
    metrics["salary_gap"] = max(metrics["salary_target"] - metrics["advisory_mrr"], 0)
    metrics["salary_progress"] = (metrics["advisory_mrr"] / metrics["salary_target"] * 100) if metrics["salary_target"] else 0
    revenue_forecast = build_revenue_forecast(opportunities, proposals, advisory_engagements, renewals, salary_target=metrics["salary_target"])
    metrics.update({
        "forecast_30": revenue_forecast["forecast_30"],
        "forecast_90": revenue_forecast["forecast_90"],
        "forecast_12m": revenue_forecast["forecast_12m"],
        "projected_mrr_90": revenue_forecast["projected_mrr_90"],
        "projected_arr_90": revenue_forecast["projected_arr_90"],
        "projected_salary_gap": revenue_forecast["projected_salary_gap"],
        "projected_salary_progress": revenue_forecast["projected_salary_progress"],
    })
    client_health = build_client_health(clients, advisory_engagements, renewals, activities)
    renewal_risk = build_renewal_risk(renewals)
    trend_analytics = build_trend_analytics(leads, opportunities, proposals, clients, advisory_engagements, renewals, activities)
    metrics.update({
        "average_client_health": client_health["average_health"],
        "healthy_clients": client_health["healthy"],
        "watchlist_clients": client_health["watchlist"],
        "at_risk_clients": client_health["at_risk"],
        "at_risk_mrr": client_health["at_risk_mrr"],
        "critical_renewals": renewal_risk["critical"],
        "high_risk_renewals": renewal_risk["high"],
        "renewals_due_30": renewal_risk["due_30"],
        "renewals_due_90": renewal_risk["due_90"],
        "renewal_at_risk_mrr": renewal_risk["at_risk_mrr"],
        "six_month_new_mrr": trend_analytics["six_month_new_mrr"],
        "six_month_clients_created": trend_analytics["six_month_clients_created"],
        "six_month_activities": trend_analytics["six_month_activities"],
    })
    return render_template("kpis.html", metrics=metrics, recent_activities=ActivityLog.query.order_by(ActivityLog.created_at.desc()).limit(10).all(), active_opps=active_opps[:10], open_renewals=open_renewals[:10], revenue_forecast=revenue_forecast, client_health=client_health, renewal_risk=renewal_risk, trend_analytics=trend_analytics)


@app.route("/forecast")
@login_required
@require_permission("forecast_view")
def forecast():
    opportunities = Opportunity.query.all()
    proposals = Proposal.query.all()
    advisory_engagements = AdvisoryEngagement.query.all()
    renewals = RenewalRecord.query.all()
    salary_target = 8000
    revenue_forecast = build_revenue_forecast(opportunities, proposals, advisory_engagements, renewals, salary_target=salary_target)
    return render_template("forecast.html", revenue_forecast=revenue_forecast, salary_target=salary_target)


@app.route("/client-health")
@login_required
@require_permission("client_view")
def client_health():
    clients = Client.query.order_by(Client.client_name.asc()).all()
    advisory_engagements = AdvisoryEngagement.query.all()
    renewals = RenewalRecord.query.all()
    activities = ActivityLog.query.all()
    health = build_client_health(clients, advisory_engagements, renewals, activities)
    return render_template("client_health.html", health=health)


@app.route("/renewal-risk")
@login_required
@require_permission("renewal_view")
def renewal_risk():
    renewals = RenewalRecord.query.order_by(RenewalRecord.created_at.desc()).all()
    risk = build_renewal_risk(renewals)
    return render_template("renewal_risk.html", risk=risk)


@app.route("/trend-analytics")
@login_required
@require_permission("kpi_view")
def trend_analytics():
    leads = Lead.query.all()
    opportunities = Opportunity.query.all()
    proposals = Proposal.query.all()
    clients = Client.query.all()
    advisory_engagements = AdvisoryEngagement.query.all()
    renewals = RenewalRecord.query.all()
    activities = ActivityLog.query.all()
    trends = build_trend_analytics(leads, opportunities, proposals, clients, advisory_engagements, renewals, activities)
    return render_template("trend_analytics.html", trends=trends)

@app.route("/workflow-automation")
@login_required
@require_permission("automation_view")
def workflow_automation():
    preview = build_workflow_automation_preview()
    runs = WorkflowAutomationRun.query.order_by(WorkflowAutomationRun.run_date.desc()).limit(10).all()
    metrics = {
        "recommended_actions": len(preview),
        "high_priority": len([x for x in preview if x["priority"] == "High"]),
        "automation_runs": WorkflowAutomationRun.query.count(),
        "last_run": runs[0] if runs else None,
    }
    return render_template("workflow_automation.html", preview=preview, runs=runs, metrics=metrics)


@app.route("/workflow-automation/run", methods=["POST"])
@login_required
@require_permission("automation_run")
def workflow_automation_run():
    run, summary = run_workflow_automation(triggered_by=current_user.username)
    flash(f"Workflow Automation completed. {len(summary)} action(s) processed.", "success")
    return redirect(url_for("workflow_automation"))


@app.route("/email-automation")
@login_required
@require_permission("email_view")
def email_automation():
    preview = build_email_automation_preview()
    queued = EmailAutomationLog.query.filter_by(status="Queued").order_by(EmailAutomationLog.created_at.desc()).all()
    sent = EmailAutomationLog.query.filter_by(status="Sent").order_by(EmailAutomationLog.created_at.desc()).limit(25).all()
    metrics = {
        "recommended": len(preview),
        "queued": len(queued),
        "sent": EmailAutomationLog.query.filter_by(status="Sent").count(),
        "high_priority": len([x for x in preview if x["priority"] == "High"]),
    }
    return render_template("email_automation.html", preview=preview, queued=queued, sent=sent, metrics=metrics)


@app.route("/email-automation/run", methods=["POST"])
@login_required
@require_permission("email_edit")
def email_automation_run():
    created = run_email_automation(created_by=current_user.username)
    flash(f"Email Automation completed. {len(created)} email draft(s) queued.", "success")
    return redirect(url_for("email_automation"))


@app.route("/email-automation/<int:email_id>/mark-sent", methods=["POST"])
@login_required
@require_permission("email_edit")
def email_automation_mark_sent(email_id):
    email = EmailAutomationLog.query.get_or_404(email_id)
    email.status = "Sent"
    email.sent_at = datetime.utcnow()
    db.session.add(ActivityLog(
        activity_date=date.today().isoformat(),
        activity_type="Email",
        subject=f"Email sent: {email.trigger_type}",
        related_name=email.related_name,
        contact_name=email.recipient_name,
        outcome="Completed",
        priority="Medium",
        owner=current_user.username,
        notes=f"Subject: {email.subject}",
        lead_id=email.lead_id,
        opportunity_id=email.opportunity_id,
        proposal_id=email.proposal_id,
        client_id=email.client_id,
        advisory_id=email.advisory_id,
    ))
    db.session.commit()
    flash("Email marked as sent and activity was logged.", "success")
    return redirect(url_for("email_automation"))


@app.route("/email-automation/<int:email_id>/skip", methods=["POST"])
@login_required
@require_permission("email_edit")
def email_automation_skip(email_id):
    email = EmailAutomationLog.query.get_or_404(email_id)
    email.status = "Skipped"
    email.notes = (email.notes or "") + " Skipped by user."
    safe_commit("Email Draft Skipped", "EmailAutomationLog", email.id, new_value=email.recipient_email)
    flash("Email draft skipped.", "info")
    return redirect(url_for("email_automation"))


@app.route("/assessment", methods=["GET","POST"])
@login_required
@require_permission("assessment_view")
def assessment():
    if request.method == "POST" and not user_has_permission(current_user, "assessment_edit"):
        log_audit(action="Permission Denied", object_type="assessment", result="Denied", new_value="assessment_edit")
        db.session.commit()
        flash("Access denied for this edit action.", "danger")
        return redirect(url_for("assessment"))
    if request.method == "POST":
        client_name = request.form.get("client_name","").strip() or "Unnamed Client"
        business_type = request.form.get("business_type","")
        annual_transactions = int(request.form.get("annual_transactions",0) or 0)
        avg_transaction_value = float(request.form.get("avg_transaction_value",0) or 0)
        revenue_per_day = float(request.form.get("revenue_per_day",0) or 0)
        downtime_days = int(request.form.get("downtime_days",1) or 1)
        findings = build_findings(request.form)
        overall_level, overall_score = overall_from_findings(findings)
        exposure = exposure_from_value(avg_transaction_value, overall_level)
        downtime_loss = revenue_per_day * downtime_days
        item = Assessment(client_name=client_name,business_type=business_type,advisor=current_user.username,annual_transactions=annual_transactions,avg_transaction_value=avg_transaction_value,revenue_per_day=revenue_per_day,downtime_days=downtime_days,overall_level=overall_level,overall_score=overall_score,exposure=exposure,downtime_loss=downtime_loss,findings_json=json.dumps(findings))
        db.session.add(item); safe_commit("Opportunity Brief Created", "Assessment", item.client_name, new_value=item.overall_level); flash("Assessment completed.","success"); return redirect(url_for("assessment_result", assessment_id=item.id))
    return render_template("assessment.html", questions=QUESTIONS)

@app.route("/assessment/<int:assessment_id>")
@login_required
@require_permission("assessment_view")
def assessment_result(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    findings = json.loads(assessment.findings_json)
    return render_template("assessment_result.html", assessment=assessment, findings=findings, actions=action_plan(assessment.overall_level))

@app.route("/assessment/<int:assessment_id>/pdf")
@login_required
@require_permission("export_reports")
def assessment_pdf(assessment_id):
    assessment = Assessment.query.get_or_404(assessment_id)
    pdf_buffer = build_pdf(assessment)
    if pdf_buffer is None:
        flash("PDF generation requires reportlab.","warning")
        return redirect(url_for("assessment_result", assessment_id=assessment.id))
    log_audit(action="Export Report", object_type="Assessment", object_id=assessment.id, new_value=assessment.client_name)
    db.session.commit()
    return send_file(pdf_buffer, as_attachment=True, download_name=f"SentinelRE_{assessment.client_name.replace(' ', '_')}_Opportunity_Brief.pdf", mimetype="application/pdf")



@app.route("/admin/users", methods=["GET", "POST"])
@login_required
@require_permission("user_admin")
def admin_users():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        if not username:
            flash("Username is required.", "danger")
            return redirect(url_for("admin_users"))
        user = User.query.filter_by(username=username).first() or User(username=username)
        is_new = user.id is None
        user.email = request.form.get("email", "").strip()
        user.role = role_label(request.form.get("role", "Read Only"))
        user.active = bool(request.form.get("active"))
        user.nda_signed = bool(request.form.get("nda_signed"))
        user.ip_agreement_signed = bool(request.form.get("ip_agreement_signed"))
        user.security_training_completed = bool(request.form.get("security_training_completed"))
        user.access_approved = bool(request.form.get("access_approved"))
        password = request.form.get("password", "").strip()
        if password:
            user.set_password(password)
        elif is_new:
            user.set_password("ChangeMe123!")
        db.session.add(user)
        safe_commit("User Created" if is_new else "User Updated", "User", username, new_value=f"role={user.role}; active={user.active}")
        flash("User access record saved.", "success")
        return redirect(url_for("admin_users"))
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin_users.html", users=users, roles=ROLE_OPTIONS)



@app.route("/license-compliance", methods=["GET", "POST"])
@login_required
@require_permission("compliance_view")
def license_compliance():
    if request.method == "POST":
        if not user_has_permission(current_user, "compliance_edit"):
            abort(403)
        record_type = request.form.get("record_type")
        if record_type == "license":
            lic = LicenseCredential(
                professional_name=request.form.get("professional_name", "").strip() or "Unnamed Professional",
                role_type=request.form.get("role_type") or "Realtor / Agent",
                license_type=request.form.get("license_type") or "Sales Associate License",
                license_number=request.form.get("license_number"),
                issuing_state=request.form.get("issuing_state") or "Florida",
                status=request.form.get("status") or "Active",
                issue_date=request.form.get("issue_date"),
                expiration_date=request.form.get("expiration_date"),
                ce_required_hours=float(request.form.get("ce_required_hours") or 0),
                ce_completed_hours=float(request.form.get("ce_completed_hours") or 0),
                ce_status=request.form.get("ce_status") or "Not Started",
                disciplinary_flag=True if request.form.get("disciplinary_flag") == "on" else False,
                notes=request.form.get("notes"),
                owner=request.form.get("owner") or current_user.username,
                created_by=current_user.username,
            )
            db.session.add(lic)
            safe_commit("License Credential Created", "LicenseCredential", lic.id, new_value=lic.professional_name)
            flash("License credential saved.", "success")
        elif record_type == "ce":
            ce = ContinuingEducationRecord(
                license_id=int(request.form.get("license_id")) if request.form.get("license_id") else None,
                professional_name=request.form.get("ce_professional_name", "").strip() or "Unnamed Professional",
                course_name=request.form.get("course_name", "").strip() or "Continuing Education Course",
                provider=request.form.get("provider"),
                hours=float(request.form.get("hours") or 0),
                completion_date=request.form.get("completion_date"),
                status=request.form.get("ce_record_status") or "Completed",
                notes=request.form.get("ce_notes"),
                created_by=current_user.username,
            )
            db.session.add(ce)
            safe_commit("CE Record Created", "ContinuingEducationRecord", ce.id, new_value=ce.course_name)
            flash("Continuing education record saved.", "success")
        return redirect(url_for("license_compliance"))

    licenses = LicenseCredential.query.order_by(LicenseCredential.created_at.desc()).all()
    ce_records = ContinuingEducationRecord.query.order_by(ContinuingEducationRecord.created_at.desc()).limit(50).all()
    active_count = len([l for l in licenses if l.status == "Active"])
    expiring_count = len([l for l in licenses if l.status in ["Expiring Soon", "Expired"]])
    disciplinary_count = len([l for l in licenses if l.disciplinary_flag])
    avg_ce = sum([l.ce_completion_rate for l in licenses]) / max(len(licenses), 1) if licenses else 0
    return render_template("license_compliance.html", licenses=licenses, ce_records=ce_records, active_count=active_count, expiring_count=expiring_count, disciplinary_count=disciplinary_count, avg_ce=avg_ce, license_types=LICENSE_TYPES, license_statuses=LICENSE_STATUSES, ce_statuses=CE_STATUSES)


@app.route("/aml-transaction-governance", methods=["GET", "POST"])
@login_required
@require_permission("compliance_view")
def aml_transaction_governance():
    clients = Client.query.order_by(Client.client_name.asc()).all()
    opportunities = Opportunity.query.order_by(Opportunity.company_name.asc()).all()
    if request.method == "POST":
        if not user_has_permission(current_user, "compliance_edit"):
            abort(403)
        record_type = request.form.get("record_type")
        if record_type == "aml":
            risk = 0
            for flag in ["cash_transaction", "foreign_buyer", "entity_buyer", "high_risk_jurisdiction"]:
                if request.form.get(flag) == "on":
                    risk += 20
            if request.form.get("beneficial_owner_verified") != "on":
                risk += 15
            if request.form.get("source_of_funds_verified") != "on":
                risk += 15
            risk = min(100, risk)
            aml = AMLTransactionReview(
                client_id=int(request.form.get("client_id")) if request.form.get("client_id") else None,
                opportunity_id=int(request.form.get("opportunity_id")) if request.form.get("opportunity_id") else None,
                transaction_name=request.form.get("transaction_name", "").strip() or "Unnamed Transaction",
                property_address=request.form.get("property_address"),
                buyer_name=request.form.get("buyer_name"),
                seller_name=request.form.get("seller_name"),
                transaction_value=float(request.form.get("transaction_value") or 0),
                cash_transaction=request.form.get("cash_transaction") == "on",
                foreign_buyer=request.form.get("foreign_buyer") == "on",
                entity_buyer=request.form.get("entity_buyer") == "on",
                beneficial_owner_verified=request.form.get("beneficial_owner_verified") == "on",
                source_of_funds_verified=request.form.get("source_of_funds_verified") == "on",
                high_risk_jurisdiction=request.form.get("high_risk_jurisdiction") == "on",
                suspicious_activity_flags=request.form.get("suspicious_activity_flags"),
                risk_score=risk,
                review_status=request.form.get("review_status") or ("Enhanced Due Diligence Required" if risk >= 50 else "Cleared"),
                escalation_required=risk >= 50,
                reviewed_by=current_user.username,
                reviewed_at=datetime.utcnow(),
                notes=request.form.get("notes"),
                created_by=current_user.username,
            )
            db.session.add(aml)
            safe_commit("AML Transaction Review Created", "AMLTransactionReview", aml.id, new_value=f"{aml.transaction_name} / risk {aml.risk_score}")
            flash("AML transaction review saved.", "success")
        elif record_type == "transaction":
            checks = ["contract_complete", "disclosures_complete", "inspection_complete", "appraisal_complete", "title_review_complete", "escrow_review_complete", "closing_package_complete"]
            complete = sum(1 for c in checks if request.form.get(c) == "on")
            score = round((complete / len(checks)) * 100, 1)
            tg = TransactionGovernanceReview(
                client_id=int(request.form.get("tg_client_id")) if request.form.get("tg_client_id") else None,
                opportunity_id=int(request.form.get("tg_opportunity_id")) if request.form.get("tg_opportunity_id") else None,
                transaction_name=request.form.get("tg_transaction_name", "").strip() or "Unnamed Transaction",
                property_address=request.form.get("tg_property_address"),
                contract_complete=request.form.get("contract_complete") == "on",
                disclosures_complete=request.form.get("disclosures_complete") == "on",
                inspection_complete=request.form.get("inspection_complete") == "on",
                appraisal_complete=request.form.get("appraisal_complete") == "on",
                title_review_complete=request.form.get("title_review_complete") == "on",
                escrow_review_complete=request.form.get("escrow_review_complete") == "on",
                closing_package_complete=request.form.get("closing_package_complete") == "on",
                exceptions=request.form.get("exceptions"),
                readiness_score=score,
                review_status=request.form.get("tg_review_status") or ("Cleared" if score >= 85 else "Under Review"),
                broker_review_required=score < 85,
                reviewed_by=current_user.username,
                reviewed_at=datetime.utcnow(),
                created_by=current_user.username,
            )
            db.session.add(tg)
            safe_commit("Transaction Governance Review Created", "TransactionGovernanceReview", tg.id, new_value=f"{tg.transaction_name} / {tg.readiness_score}")
            flash("Transaction governance review saved.", "success")
        return redirect(url_for("aml_transaction_governance"))

    aml_reviews = AMLTransactionReview.query.order_by(AMLTransactionReview.created_at.desc()).all()
    transaction_reviews = TransactionGovernanceReview.query.order_by(TransactionGovernanceReview.created_at.desc()).all()
    high_risk_aml = len([a for a in aml_reviews if a.escalation_required or (a.risk_score or 0) >= 50])
    avg_transaction = sum([(t.readiness_score or 0) for t in transaction_reviews]) / max(len(transaction_reviews), 1) if transaction_reviews else 0
    return render_template("aml_transaction_governance.html", clients=clients, opportunities=opportunities, aml_reviews=aml_reviews, transaction_reviews=transaction_reviews, high_risk_aml=high_risk_aml, avg_transaction=avg_transaction, aml_statuses=AML_REVIEW_STATUSES, transaction_statuses=TRANSACTION_REVIEW_STATUSES)


@app.route("/probate-governance", methods=["GET", "POST"])
@login_required
@require_permission("compliance_view")
def probate_governance():
    if request.method == "POST":
        if not user_has_permission(current_user, "compliance_edit"):
            abort(403)
        checks = ["inventory_completed", "court_filings_current", "beneficiary_notice_complete", "property_disposition_plan", "title_review_complete"]
        complete = sum(1 for c in checks if request.form.get(c) == "on")
        readiness = round((complete / len(checks)) * 100, 1)
        matter = ProbateMatter(
            matter_name=request.form.get("matter_name", "").strip() or "Unnamed Probate Matter",
            estate_name=request.form.get("estate_name"),
            attorney_name=request.form.get("attorney_name"),
            court_name=request.form.get("court_name"),
            case_number=request.form.get("case_number"),
            property_address=request.form.get("property_address"),
            personal_representative=request.form.get("personal_representative"),
            beneficiary_count=int(request.form.get("beneficiary_count") or 0),
            inventory_completed=request.form.get("inventory_completed") == "on",
            court_filings_current=request.form.get("court_filings_current") == "on",
            beneficiary_notice_complete=request.form.get("beneficiary_notice_complete") == "on",
            property_disposition_plan=request.form.get("property_disposition_plan") == "on",
            title_review_complete=request.form.get("title_review_complete") == "on",
            risk_level=request.form.get("risk_level") or ("High" if readiness < 60 else "Moderate" if readiness < 85 else "Low"),
            readiness_score=readiness,
            status=request.form.get("status") or "Intake",
            next_action=request.form.get("next_action"),
            next_deadline=request.form.get("next_deadline"),
            notes=request.form.get("notes"),
            owner=request.form.get("owner") or current_user.username,
            created_by=current_user.username,
        )
        db.session.add(matter)
        safe_commit("Probate Matter Created", "ProbateMatter", matter.id, new_value=f"{matter.matter_name} / {matter.readiness_score}")
        flash("Probate governance matter saved.", "success")
        return redirect(url_for("probate_governance"))

    matters = ProbateMatter.query.order_by(ProbateMatter.created_at.desc()).all()
    avg_readiness = sum([(m.readiness_score or 0) for m in matters]) / max(len(matters), 1) if matters else 0
    high_risk = len([m for m in matters if m.risk_level in ["High", "Critical"] or (m.readiness_score or 0) < 60])
    return render_template("probate_governance.html", matters=matters, avg_readiness=avg_readiness, high_risk=high_risk, statuses=PROBATE_MATTER_STATUSES, risk_levels=PROBATE_RISK_LEVELS)


@app.route("/regulatory-readiness", methods=["GET", "POST"])
@login_required
@require_permission("compliance_view")
def regulatory_readiness():
    clients = Client.query.order_by(Client.client_name.asc()).all()
    opportunities = Opportunity.query.order_by(Opportunity.company_name.asc()).all()
    if request.method == "POST":
        if not user_has_permission(current_user, "compliance_edit"):
            abort(403)

        def score(name):
            try:
                return max(0, min(100, float(request.form.get(name, 0) or 0)))
            except Exception:
                return 0

        scores = {
            "licensing_score": score("licensing_score"),
            "fair_housing_score": score("fair_housing_score"),
            "aml_score": score("aml_score"),
            "transaction_governance_score": score("transaction_governance_score"),
            "escrow_controls_score": score("escrow_controls_score"),
            "records_governance_score": score("records_governance_score"),
            "operational_resilience_score": score("operational_resilience_score"),
        }
        overall = sum(scores.values()) / max(len(scores), 1)
        assessment = RegulatoryReadinessAssessment(
            client_id=int(request.form.get("client_id")) if request.form.get("client_id") else None,
            opportunity_id=int(request.form.get("opportunity_id")) if request.form.get("opportunity_id") else None,
            property_name=request.form.get("property_name"),
            property_address=request.form.get("property_address"),
            organization_name=request.form.get("organization_name", "").strip() or "Unnamed Organization",
            contact_name=request.form.get("contact_name"),
            compliance_profile=request.form.get("compliance_profile") or "Brokerage / CRE",
            overall_score=overall,
            readiness_status=readiness_band(overall),
            risk_level=request.form.get("risk_level") or ("High" if overall < 50 else "Moderate" if overall < 70 else "Low"),
            priority_findings=request.form.get("priority_findings"),
            corrective_actions=request.form.get("corrective_actions"),
            owner=request.form.get("owner") or current_user.username,
            next_review_date=request.form.get("next_review_date"),
            created_by=current_user.username,
            **scores
        )
        db.session.add(assessment)
        db.session.flush()

        # Auto-create compliance action items for weak domains.
        domain_map = [
            ("Licensing & Professional Governance", assessment.licensing_score, "Verify broker/agent licenses, CE records, and supervisory controls."),
            ("Fair Housing Compliance", assessment.fair_housing_score, "Review advertising, training, policy acknowledgement, and complaint records."),
            ("AML / Transaction Integrity", assessment.aml_score, "Review cash transaction risk, beneficial ownership, and high-risk buyer indicators."),
            ("Transaction Governance", assessment.transaction_governance_score, "Validate disclosures, contract completeness, title, inspection, appraisal, and closing readiness."),
            ("Escrow & Financial Controls", assessment.escrow_controls_score, "Review escrow controls, trust account procedures, and exception documentation."),
            ("Records & Document Governance", assessment.records_governance_score, "Confirm document retention, legal hold, versioning, and approval workflow."),
            ("Operational Resilience", assessment.operational_resilience_score, "Review access controls, data security, vendor risk, and incident response readiness."),
        ]
        for domain, value, requirement in domain_map:
            if (value or 0) < 70:
                db.session.add(ComplianceActionItem(
                    assessment_id=assessment.id,
                    domain=domain,
                    requirement=requirement,
                    risk_level="High" if (value or 0) < 50 else "Moderate",
                    status="Open",
                    owner=assessment.owner,
                    due_date=assessment.next_review_date,
                    created_by=current_user.username,
                ))

        safe_commit("Regulatory Assessment Created", "RegulatoryReadinessAssessment", assessment.id, new_value=f"{assessment.organization_name} / {assessment.overall_score:.1f}")
        flash("Regulatory readiness assessment saved and action items generated.", "success")
        return redirect(url_for("regulatory_readiness"))

    assessments = RegulatoryReadinessAssessment.query.order_by(RegulatoryReadinessAssessment.created_at.desc()).all()
    open_actions = ComplianceActionItem.query.filter(ComplianceActionItem.status != "Closed").order_by(ComplianceActionItem.created_at.desc()).all()
    avg_score = sum((a.overall_score or 0) for a in assessments) / max(len(assessments), 1) if assessments else 0
    return render_template(
        "regulatory_readiness.html",
        assessments=assessments,
        open_actions=open_actions,
        clients=clients,
        opportunities=opportunities,
        avg_score=avg_score,
        readiness_band=readiness_band(avg_score),
        compliance_domains=COMPLIANCE_DOMAINS,
        risk_levels=COMPLIANCE_RISK_LEVELS,
        status_levels=COMPLIANCE_STATUS_LEVELS,
    )


@app.route("/regulatory-readiness/actions/<int:action_id>/close", methods=["POST"])
@login_required
@require_permission("compliance_edit")
def close_compliance_action(action_id):
    item = ComplianceActionItem.query.get_or_404(action_id)
    item.status = "Closed"
    item.closed_at = datetime.utcnow()
    item.notes = ((item.notes or "") + "\nClosed note: " + (request.form.get("close_note") or "")).strip()
    safe_commit("Compliance Action Closed", "ComplianceActionItem", item.id, new_value=item.requirement)
    flash("Compliance action item closed.", "success")
    return redirect(url_for("regulatory_readiness"))


@app.route("/documents", methods=["GET", "POST"])
@login_required
@require_permission("document_view")
def documents():
    if request.method == "POST":
        if not user_has_permission(current_user, "document_upload"):
            abort(403)

        uploaded_file = request.files.get("file")
        if not uploaded_file or uploaded_file.filename == "":
            flash("Please select a document to upload.", "warning")
            return redirect(url_for("documents"))

        if not allowed_document_file(uploaded_file.filename):
            flash("Unsupported file type. Allowed: PDF, Word, Excel, CSV, TXT, PNG, JPG.", "danger")
            return redirect(url_for("documents"))

        original_filename = secure_filename(uploaded_file.filename)
        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        stored_filename = f"{timestamp}_{current_user.username}_{original_filename}"
        storage_path = Path(app.config["DOCUMENT_UPLOAD_FOLDER"]) / stored_filename
        uploaded_file.save(storage_path)

        doc = Document(
            client_id=int(request.form.get("client_id")) if request.form.get("client_id") else None,
            opportunity_id=int(request.form.get("opportunity_id")) if request.form.get("opportunity_id") else None,
            proposal_id=int(request.form.get("proposal_id")) if request.form.get("proposal_id") else None,
            property_name=request.form.get("property_name"),
            property_address=request.form.get("property_address"),
            document_title=request.form.get("document_title") or original_filename,
            document_type=request.form.get("document_type") or "Other",
            category=request.form.get("category") or "Other",
            sensitivity=request.form.get("sensitivity") or "Standard",
            status="Pending Review",
            version=1,
            original_filename=original_filename,
            stored_filename=stored_filename,
            file_path=str(storage_path),
            file_size=storage_path.stat().st_size if storage_path.exists() else 0,
            mime_type=uploaded_file.mimetype,
            uploaded_by=current_user.username,
            uploaded_at=datetime.utcnow(),
            retention_date=request.form.get("retention_date"),
            notes=request.form.get("notes"),
            active=True
        )
        db.session.add(doc)
        db.session.flush()

        version = DocumentVersion(
            document_id=doc.id,
            version=1,
            original_filename=original_filename,
            stored_filename=stored_filename,
            file_path=str(storage_path),
            uploaded_by=current_user.username,
            notes="Initial upload"
        )
        db.session.add(version)

        access = DocumentAccessLog(
            document_id=doc.id,
            username=current_user.username,
            role=current_user.role,
            action="Uploaded",
            ip_address=request.headers.get("X-Forwarded-For", request.remote_addr)
        )
        db.session.add(access)

        safe_commit(action="Document Uploaded", object_type="Document", object_id=doc.id, new_value=doc.document_title)
        flash("Document uploaded and routed for broker review.", "success")
        return redirect(url_for("documents"))

    docs = Document.query.filter_by(active=True).order_by(Document.uploaded_at.desc()).all()
    clients = Client.query.order_by(Client.client_name.asc()).all()
    opportunities = Opportunity.query.order_by(Opportunity.company_name.asc()).all()
    proposals = Proposal.query.order_by(Proposal.proposal_number.desc()).all()
    return render_template(
        "documents.html",
        documents=docs,
        clients=clients,
        opportunities=opportunities,
        proposals=proposals,
        categories=DOCUMENT_CATEGORIES,
        statuses=DOCUMENT_STATUSES,
        sensitivity_levels=DOCUMENT_SENSITIVITY_LEVELS,
        BRAND=BRAND
    )


@app.route("/documents/<int:document_id>/download")
@login_required
@require_permission("document_download")
def document_download(document_id):
    doc = Document.query.get_or_404(document_id)
    if not doc.active:
        abort(404)

    db.session.add(DocumentAccessLog(
        document_id=doc.id,
        username=current_user.username,
        role=current_user.role,
        action="Downloaded",
        ip_address=request.headers.get("X-Forwarded-For", request.remote_addr)
    ))
    safe_commit(action="Document Downloaded", object_type="Document", object_id=doc.id, new_value=doc.document_title)

    return send_file(doc.file_path, as_attachment=True, download_name=doc.original_filename)


@app.route("/documents/<int:document_id>/approve", methods=["POST"])
@login_required
@require_permission("document_approve")
def document_approve(document_id):
    doc = Document.query.get_or_404(document_id)
    doc.status = "Approved"
    doc.approved_by = current_user.username
    doc.approved_at = datetime.utcnow()
    doc.approval_notes = request.form.get("approval_notes")
    db.session.add(DocumentAccessLog(
        document_id=doc.id,
        username=current_user.username,
        role=current_user.role,
        action="Approved",
        ip_address=request.headers.get("X-Forwarded-For", request.remote_addr)
    ))
    safe_commit(action="Document Approved", object_type="Document", object_id=doc.id, new_value=doc.document_title)
    flash("Document approved.", "success")
    return redirect(url_for("documents"))


@app.route("/documents/<int:document_id>/archive", methods=["POST"])
@login_required
@require_permission("document_approve")
def document_archive(document_id):
    doc = Document.query.get_or_404(document_id)
    doc.status = "Archived"
    db.session.add(DocumentAccessLog(
        document_id=doc.id,
        username=current_user.username,
        role=current_user.role,
        action="Archived",
        ip_address=request.headers.get("X-Forwarded-For", request.remote_addr)
    ))
    safe_commit(action="Document Archived", object_type="Document", object_id=doc.id, new_value=doc.document_title)
    flash("Document archived.", "success")
    return redirect(url_for("documents"))


@app.route("/documents/<int:document_id>/delete", methods=["POST"])
@login_required
@require_permission("document_delete")
def document_delete(document_id):
    doc = Document.query.get_or_404(document_id)
    doc.active = False
    db.session.add(DocumentAccessLog(
        document_id=doc.id,
        username=current_user.username,
        role=current_user.role,
        action="Deleted/Disabled",
        ip_address=request.headers.get("X-Forwarded-For", request.remote_addr)
    ))
    safe_commit(action="Document Disabled", object_type="Document", object_id=doc.id, new_value=doc.document_title)
    flash("Document removed from active vault. File retained for audit evidence.", "warning")
    return redirect(url_for("documents"))


@app.route("/admin/audit-logs")
@login_required
@require_permission("audit_view")
def audit_logs():
    q = AuditLog.query
    action = request.args.get("action", "").strip()
    username = request.args.get("username", "").strip()
    object_type = request.args.get("object_type", "").strip()
    if action:
        q = q.filter(AuditLog.action.contains(action))
    if username:
        q = q.filter(AuditLog.username.contains(username))
    if object_type:
        q = q.filter(AuditLog.object_type.contains(object_type))
    logs = q.order_by(AuditLog.timestamp.desc()).limit(500).all()
    return render_template("audit_logs.html", logs=logs)

@app.route("/admin/contractor-agreements", methods=["GET", "POST"])
@login_required
@require_permission("contractor_admin")
def contractor_agreements():
    users = User.query.order_by(User.username.asc()).all()
    if request.method == "POST":
        user = None
        if request.form.get("user_id"):
            try: user = db.session.get(User, int(request.form.get("user_id")))
            except Exception: user = None
        record = ContractorAgreement(
            user_id=user.id if user else None,
            contractor_name=request.form.get("contractor_name", "").strip() or (user.username if user else "Unnamed Contractor"),
            contractor_email=request.form.get("contractor_email", "").strip() or (user.email if user else ""),
            role_requested=role_label(request.form.get("role_requested", "Operations Coordinator")),
            nda_signed=bool(request.form.get("nda_signed")),
            ip_agreement_signed=bool(request.form.get("ip_agreement_signed")),
            non_solicitation_acknowledged=bool(request.form.get("non_solicitation_acknowledged")),
            security_training_completed=bool(request.form.get("security_training_completed")),
            access_approved=bool(request.form.get("access_approved")),
            approved_by=current_user.username,
            signed_date=request.form.get("signed_date", "").strip(),
            notes=request.form.get("notes", "").strip(),
        )
        db.session.add(record)
        if user:
            user.role = record.role_requested
            user.nda_signed = record.nda_signed
            user.ip_agreement_signed = record.ip_agreement_signed
            user.security_training_completed = record.security_training_completed
            user.access_approved = record.access_approved
            user.active = record.access_approved
        safe_commit("Contractor Agreement Recorded", "ContractorAgreement", record.contractor_name, new_value=f"NDA={record.nda_signed}; IP={record.ip_agreement_signed}; Approved={record.access_approved}")
        flash("Contractor NDA/IP access record saved.", "success")
        return redirect(url_for("contractor_agreements"))
    records = ContractorAgreement.query.order_by(ContractorAgreement.created_at.desc()).all()
    return render_template("contractor_agreements.html", records=records, users=users, roles=ROLE_OPTIONS)

@app.cli.command("init-db")
def init_db_command():
    db.create_all()
    if not User.query.filter_by(username="admin").first():
        admin = User(username="broker_owner", email="broker@example.com", role="Owner/Broker", active=True, nda_signed=True, ip_agreement_signed=True, security_training_completed=True, access_approved=True); admin.set_password("Broker123!")
        advisor = User(username="realtor", email="realtor@example.com", role="Realtor / Agent", active=True, nda_signed=True, ip_agreement_signed=True, security_training_completed=True, access_approved=True); advisor.set_password("Realtor123!")
        db.session.add_all([admin, advisor]); db.session.commit()
    print("Database initialized.")

def ensure_default_data():
    db.create_all()
    if not User.query.filter_by(username="admin").first():
        admin = User(username="broker_owner", email="broker@example.com", role="Owner/Broker", active=True, nda_signed=True, ip_agreement_signed=True, security_training_completed=True, access_approved=True); admin.set_password("Broker123!")
        advisor = User(username="realtor", email="realtor@example.com", role="Realtor / Agent", active=True, nda_signed=True, ip_agreement_signed=True, security_training_completed=True, access_approved=True); advisor.set_password("Realtor123!")
        db.session.add_all([admin, advisor])
    if Lead.query.count() == 0:
        db.session.add_all([
            Lead(client_name="ABC Medical Group", contact_name="Elena Morris", email="elena@example.com", industry="Healthcare", state="FL", lead_source="LinkedIn", stage="Qualified", priority="A - Immediate", recommended_offer="Commercial Property Review", probability=0.60, estimated_value=5000.0, monthly_retainer=1000.0, next_follow_up="This week", notes="Strong fit: handles PHI, likely needs executive risk visibility."),
            Lead(client_name="Gulf Coast Legal Partners", contact_name="David Lin", email="dlin@example.com", industry="Legal Services", state="FL", lead_source="Referral", stage="Discovery Scheduled", priority="A - Immediate", recommended_offer="Property Readiness Review", probability=0.50, estimated_value=3500.0, monthly_retainer=750.0, next_follow_up="Confirm discovery call", notes="Sensitive client data and business continuity concerns."),
        ])
        db.session.commit()
    if Opportunity.query.count() == 0:
        lead = Lead.query.filter_by(client_name="ABC Medical Group").first()
        db.session.add(Opportunity(lead_id=lead.id if lead else None, company_name="ABC Medical Group", contact_name="Elena Morris", email="elena@example.com", industry="Healthcare", service_type="Commercial Property Review", opportunity_stage="Proposal Drafting", proposal_status="Drafting", estimated_value=5000.0, probability=0.60, expected_close_date="30 days", monthly_retainer=1000.0, next_step="Send proposal and sample executive report", owner="admin", notes="High-fit healthcare prospect; target assessment plus advisory retainer."))
    db.session.commit()
    if Proposal.query.count() == 0:
        opp = Opportunity.query.filter_by(company_name="ABC Medical Group").first()
        db.session.add(Proposal(opportunity_id=opp.id if opp else None, proposal_number="SOP-DEMO-001", client_name="ABC Medical Group", contact_name="Elena Morris", email="elena@example.com", industry="Healthcare", proposal_type="Commercial Property Review", status="Draft", scope=default_scope("Commercial Property Review"), deliverables=default_deliverables("Commercial Property Review"), timeline="10 business days", one_time_fee=5000.0, monthly_retainer=1000.0, payment_terms="50% Upfront / 50% Upon Delivery", valid_until="30 days", next_step="Send proposal and schedule kickoff call", prepared_by="admin", notes="Demo proposal for SentinelRE proposal workflow."))
    db.session.commit()
    if Client.query.count() == 0:
        proposal = Proposal.query.filter_by(proposal_number="SOP-DEMO-001").first()
        opp = Opportunity.query.filter_by(company_name="ABC Medical Group").first()
        lead = Lead.query.filter_by(client_name="ABC Medical Group").first()
        db.session.add(Client(lead_id=lead.id if lead else None, opportunity_id=opp.id if opp else None, proposal_id=proposal.id if proposal else None, client_name="ABC Medical Group", contact_name="Elena Morris", email="elena@example.com", phone="", industry="Healthcare", lifecycle_phase="Assessment", client_status="Active Assessment", service_package="Commercial Property Review", start_date=date.today().isoformat(), assessment_due_date="14 days", report_due_date="21 days", roadmap_review_date="30 days", next_advisory_session="45 days", renewal_date="12 months", monthly_retainer=1000.0, total_contract_value=17000.0, review_cadence="Quarterly", owner="admin", open_actions=4, risk_priority="High", notes="Demo lifecycle record showing Lead → Discovery → Proposal → Client → Assessment → Advisory → Renewal."))
    db.session.commit()
    if AdvisoryEngagement.query.count() == 0:
        client = Client.query.filter_by(client_name="ABC Medical Group").first()
        db.session.add(AdvisoryEngagement(client_id=client.id if client else None, client_name="ABC Medical Group", contact_name="Elena Morris", email="elena@example.com", service_type="Broker Advisory", status="Active", billing_status="Current", monthly_fee=1000.0, start_date=date.today().isoformat(), next_invoice_date="30 days", last_payment_date="", next_review_date="45 days", renewal_date="12 months", review_cadence="Monthly", owner="admin", open_actions=3, health_status="Stable", notes="Demo advisory engagement tracking monthly recurring revenue and review cadence."))
    db.session.commit()
    if RenewalRecord.query.count() == 0:
        client = Client.query.filter_by(client_name="ABC Medical Group").first()
        advisory = AdvisoryEngagement.query.filter_by(client_name="ABC Medical Group").first()
        db.session.add(RenewalRecord(client_id=client.id if client else None, advisory_id=advisory.id if advisory else None, client_name="ABC Medical Group", contact_name="Elena Morris", email="elena@example.com", renewal_type="Advisory Retainer Renewal", renewal_stage="Renewal Review", renewal_date="12 months", reminder_date="90 days before renewal", current_monthly_fee=1000.0, proposed_monthly_fee=1500.0, current_annual_value=12000.0, renewal_value=18000.0, probability=0.70, risk_level="Moderate", health_status="Stable", owner="admin", next_step="Schedule renewal value review and present expanded advisory option", outcome="Pending", notes="Demo renewal record for protecting and expanding advisory revenue."))
    db.session.commit()


    if RegulatoryReadinessAssessment.query.count() == 0:
        client = Client.query.filter_by(client_name="ABC Medical Group").first()
        ra = RegulatoryReadinessAssessment(
            client_id=client.id if client else None,
            organization_name="Demo Commercial Brokerage",
            contact_name="Owner/Broker",
            compliance_profile="Brokerage / CRE",
            property_name="Demo CRE Portfolio",
            property_address="South Florida",
            licensing_score=82,
            fair_housing_score=76,
            aml_score=58,
            transaction_governance_score=72,
            escrow_controls_score=64,
            records_governance_score=80,
            operational_resilience_score=68,
            overall_score=71.4,
            readiness_status="Mostly Ready",
            risk_level="Moderate",
            priority_findings="AML readiness and escrow controls require improvement before scaling transaction volume.",
            corrective_actions="Formalize beneficial ownership review, escrow exception reporting, and annual compliance training documentation.",
            owner="broker_owner",
            next_review_date="90 days",
            created_by="system"
        )
        db.session.add(ra)
        db.session.flush()
        db.session.add_all([
            ComplianceActionItem(assessment_id=ra.id, domain="AML / Transaction Integrity", requirement="Document beneficial ownership and high-risk transaction review process.", risk_level="High", status="Open", owner="broker_owner", due_date="30 days", created_by="system"),
            ComplianceActionItem(assessment_id=ra.id, domain="Escrow & Financial Controls", requirement="Create escrow exception log and review cadence.", risk_level="Moderate", status="Open", owner="broker_owner", due_date="45 days", created_by="system"),
        ])
        db.session.commit()

    if ActivityLog.query.count() == 0:
        lead = Lead.query.filter_by(client_name="ABC Medical Group").first()
        opp = Opportunity.query.filter_by(company_name="ABC Medical Group").first()
        proposal = Proposal.query.filter_by(proposal_number="SOP-DEMO-001").first()
        client = Client.query.filter_by(client_name="ABC Medical Group").first()
        advisory = AdvisoryEngagement.query.filter_by(client_name="ABC Medical Group").first()
        db.session.add_all([
            ActivityLog(lead_id=lead.id if lead else None, opportunity_id=opp.id if opp else None, activity_date=date.today().isoformat(), activity_type="Discovery Meeting", subject="Initial executive discovery completed", related_name="ABC Medical Group", contact_name="Elena Morris", outcome="Proposal Requested", priority="High", next_follow_up="Send proposal this week", owner="admin", notes="Strong fit for Commercial Property Review plus advisory retainer."),
            ActivityLog(proposal_id=proposal.id if proposal else None, client_id=client.id if client else None, activity_date=date.today().isoformat(), activity_type="Proposal Follow-Up", subject="Proposal value review", related_name="ABC Medical Group", contact_name="Elena Morris", outcome="Follow-Up Needed", priority="High", next_follow_up="Confirm decision timeline", owner="admin", notes="Discuss first-year value and advisory package."),
            ActivityLog(client_id=client.id if client else None, advisory_id=advisory.id if advisory else None, activity_date=date.today().isoformat(), activity_type="Advisory Review", subject="Monthly advisory roadmap review", related_name="ABC Medical Group", contact_name="Elena Morris", outcome="Completed", priority="Medium", next_follow_up="Next review in 30 days", owner="admin", notes="Reviewed roadmap actions and renewal path."),
        ])
    db.session.commit()

with app.app_context():
    ensure_default_data()



# SentinelRE Phase 18 – Investor Management Routes

@app.route("/investors", methods=["GET", "POST"])
@login_required
def investors():
    if request.method == "POST":
        investor = Investor(
            investor_name=request.form.get("investor_name"),
            entity_name=request.form.get("entity_name"),
            email=request.form.get("email"),
            phone=request.form.get("phone"),
            investor_type=request.form.get("investor_type"),
            accredited_status=request.form.get("accredited_status"),
            target_property_type=request.form.get("target_property_type"),
            target_market=request.form.get("target_market"),
            investment_capacity=float(request.form.get("investment_capacity") or 0),
            risk_tolerance=request.form.get("risk_tolerance"),
            notes=request.form.get("notes")
        )
        db.session.add(investor)
        db.session.commit()
        flash("Investor record created.")
        return redirect(url_for("investors"))

    investors = Investor.query.order_by(Investor.created_at.desc()).all()
    return render_template("investors.html", investors=investors, brand=BRAND)


@app.route("/investor/<int:investor_id>")
@login_required
def investor_detail(investor_id):
    investor = Investor.query.get_or_404(investor_id)
    contacts = InvestorContact.query.filter_by(investor_id=investor_id).all()
    interactions = InvestorInteraction.query.filter_by(investor_id=investor_id).order_by(InvestorInteraction.created_at.desc()).all()
    preferences = InvestorPreference.query.filter_by(investor_id=investor_id).first()
    matches = InvestorOpportunityMatch.query.filter_by(investor_id=investor_id).order_by(InvestorOpportunityMatch.match_score.desc()).all()
    reports = InvestorReport.query.filter_by(investor_id=investor_id).order_by(InvestorReport.created_at.desc()).all()
    documents = InvestorDocument.query.filter_by(investor_id=investor_id).order_by(InvestorDocument.uploaded_at.desc()).all()
    return render_template("investor_detail.html", investor=investor, contacts=contacts, interactions=interactions, preferences=preferences, matches=matches, reports=reports, documents=documents, brand=BRAND)


@app.route("/investor/<int:investor_id>/interaction", methods=["POST"])
@login_required
def investor_add_interaction(investor_id):
    interaction = InvestorInteraction(
        investor_id=investor_id,
        interaction_type=request.form.get("interaction_type"),
        subject=request.form.get("subject"),
        notes=request.form.get("notes"),
        follow_up_required=bool(request.form.get("follow_up_required")),
        follow_up_date=request.form.get("follow_up_date") or None,
        created_by=current_user.username
    )
    db.session.add(interaction)
    db.session.commit()
    flash("Investor interaction added.")
    return redirect(url_for("investor_detail", investor_id=investor_id))


@app.route("/investor/<int:investor_id>/preferences", methods=["POST"])
@login_required
def investor_preferences(investor_id):
    pref = InvestorPreference.query.filter_by(investor_id=investor_id).first()
    if not pref:
        pref = InvestorPreference(investor_id=investor_id)
        db.session.add(pref)
    pref.target_markets = request.form.get("target_markets")
    pref.target_property_types = request.form.get("target_property_types")
    pref.min_investment = float(request.form.get("min_investment") or 0)
    pref.max_investment = float(request.form.get("max_investment") or 0)
    pref.preferred_hold_period = request.form.get("preferred_hold_period")
    pref.risk_profile = request.form.get("risk_profile")
    pref.return_target = request.form.get("return_target")
    pref.financing_preference = request.form.get("financing_preference")
    pref.notes = request.form.get("notes")
    db.session.commit()
    flash("Investor preferences updated.")
    return redirect(url_for("investor_detail", investor_id=investor_id))




# SentinelRE Phase 19 – Property Risk Engine & Workflow Automation Routes

def calculate_property_risk_score(assessment):
    fields = [
        assessment.environmental_risk,
        assessment.insurance_risk,
        assessment.vacancy_risk,
        assessment.tenant_concentration_risk,
        assessment.market_risk,
        assessment.title_legal_risk,
        assessment.document_completeness_risk,
        assessment.physical_condition_risk,
        assessment.financing_risk,
        assessment.compliance_risk,
    ]
    score = sum([float(x or 0) for x in fields]) / len(fields)
    if score >= 75:
        level = "High"
    elif score >= 40:
        level = "Moderate"
    elif score > 0:
        level = "Low"
    else:
        level = "Not Scored"
    return round(score, 2), level


@app.route("/property-risk", methods=["GET"])
@login_required
def property_risk_dashboard():
    assessments = PropertyRiskAssessment.query.order_by(PropertyRiskAssessment.assessed_at.desc()).all()
    actions = PropertyRiskAction.query.filter(PropertyRiskAction.status != "Completed").order_by(PropertyRiskAction.due_date.asc()).all()
    return render_template("property_risk_dashboard.html", assessments=assessments, actions=actions, brand=BRAND)


@app.route("/property-risk/new", methods=["GET", "POST"])
@login_required
def property_risk_new():
    properties = Property.query.order_by(Property.created_at.desc()).all() if "Property" in globals() else []
    if request.method == "POST":
        assessment = PropertyRiskAssessment(
            property_id=int(request.form.get("property_id")),
            assessment_name=request.form.get("assessment_name"),
            environmental_risk=float(request.form.get("environmental_risk") or 0),
            insurance_risk=float(request.form.get("insurance_risk") or 0),
            vacancy_risk=float(request.form.get("vacancy_risk") or 0),
            tenant_concentration_risk=float(request.form.get("tenant_concentration_risk") or 0),
            market_risk=float(request.form.get("market_risk") or 0),
            title_legal_risk=float(request.form.get("title_legal_risk") or 0),
            document_completeness_risk=float(request.form.get("document_completeness_risk") or 0),
            physical_condition_risk=float(request.form.get("physical_condition_risk") or 0),
            financing_risk=float(request.form.get("financing_risk") or 0),
            compliance_risk=float(request.form.get("compliance_risk") or 0),
            executive_summary=request.form.get("executive_summary"),
            recommendations=request.form.get("recommendations"),
            assessed_by=current_user.username
        )
        assessment.overall_risk_score, assessment.risk_level = calculate_property_risk_score(assessment)
        assessment.assessment_status = "Completed"
        db.session.add(assessment)
        db.session.commit()

        if assessment.risk_level in ["High", "Moderate"]:
            action = PropertyRiskAction(
                property_id=assessment.property_id,
                assessment_id=assessment.id,
                action_title=f"Review {assessment.risk_level.lower()} property risk items",
                action_category="Risk Mitigation",
                priority="High" if assessment.risk_level == "High" else "Medium",
                assigned_to=current_user.username,
                notes=assessment.recommendations
            )
            db.session.add(action)
            db.session.commit()

        flash("Property risk assessment completed.")
        return redirect(url_for("property_risk_dashboard"))

    return render_template("property_risk_new.html", properties=properties, brand=BRAND)


@app.route("/workflows", methods=["GET", "POST"])
@login_required
def workflows():
    if request.method == "POST":
        rule = WorkflowRule(
            rule_name=request.form.get("rule_name"),
            workflow_type=request.form.get("workflow_type"),
            trigger_event=request.form.get("trigger_event"),
            condition_field=request.form.get("condition_field"),
            condition_operator=request.form.get("condition_operator"),
            condition_value=request.form.get("condition_value"),
            action_type=request.form.get("action_type"),
            action_owner=request.form.get("action_owner"),
            action_template=request.form.get("action_template"),
            active=True
        )
        db.session.add(rule)
        db.session.commit()
        flash("Workflow rule created.")
        return redirect(url_for("workflows"))

    rules = WorkflowRule.query.order_by(WorkflowRule.created_at.desc()).all()
    tasks = WorkflowTask.query.filter(WorkflowTask.status != "Completed").order_by(WorkflowTask.due_date.asc()).all()
    return render_template("workflows.html", rules=rules, tasks=tasks, brand=BRAND)


@app.route("/workflow-task/<int:task_id>/complete", methods=["POST"])
@login_required
def workflow_task_complete(task_id):
    task = WorkflowTask.query.get_or_404(task_id)
    task.status = "Completed"
    task.completed_at = datetime.utcnow()
    db.session.commit()
    flash("Workflow task completed.")
    return redirect(url_for("workflows"))




# SentinelRE Phase 20 – Client Portal & E-Signature Routes

@app.route("/client-portal")
def client_portal_login():
    return render_template("client_portal_login.html", brand=BRAND)


@app.route("/client-portal/dashboard")
@login_required
def client_portal_dashboard():
    # Internal preview route for broker/admin testing. Production portal auth should use a separate portal session.
    messages = []
    signatures = SignatureRequest.query.order_by(SignatureRequest.requested_at.desc()).limit(10).all()
    return render_template("client_portal_dashboard.html", messages=messages, signatures=signatures, brand=BRAND)


@app.route("/portal-users", methods=["GET", "POST"])
@login_required
def portal_users():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)

    if request.method == "POST":
        username = request.form.get("username")
        temp_password = request.form.get("temp_password") or "ClientTemp2026!"
        portal_user = PortalUser(
            username=username,
            email=request.form.get("email"),
            client_name=request.form.get("client_name"),
            role=request.form.get("role") or "Client",
            investor_id=request.form.get("investor_id") or None,
            property_id=request.form.get("property_id") or None,
            active=True,
            access_approved=bool(request.form.get("access_approved"))
        )
        portal_user.set_password(temp_password)
        db.session.add(portal_user)
        db.session.commit()
        flash("Portal user created.")
        return redirect(url_for("portal_users"))

    users = PortalUser.query.order_by(PortalUser.created_at.desc()).all()
    return render_template("portal_users.html", users=users, brand=BRAND)


@app.route("/signature-requests", methods=["GET", "POST"])
@login_required
def signature_requests():
    if request.method == "POST":
        req = SignatureRequest(
            related_type=request.form.get("related_type"),
            related_id=request.form.get("related_id") or None,
            signer_name=request.form.get("signer_name"),
            signer_email=request.form.get("signer_email"),
            document_title=request.form.get("document_title"),
            document_type=request.form.get("document_type"),
            file_path=request.form.get("file_path"),
            requested_by=current_user.username,
            notes=request.form.get("notes")
        )
        db.session.add(req)
        db.session.commit()
        log = SignatureAuditLog(
            signature_request_id=req.id,
            event_type="Signature Requested",
            event_details=f"Signature requested for {req.document_title}",
            ip_address=request.remote_addr
        )
        db.session.add(log)
        db.session.commit()
        flash("Signature request created.")
        return redirect(url_for("signature_requests"))

    requests = SignatureRequest.query.order_by(SignatureRequest.requested_at.desc()).all()
    return render_template("signature_requests.html", requests=requests, brand=BRAND)


@app.route("/sign/<int:signature_id>", methods=["GET", "POST"])
def sign_document(signature_id):
    req = SignatureRequest.query.get_or_404(signature_id)

    if request.method == "POST":
        if req.status == "Signed":
            flash("This document has already been signed.")
            return redirect(url_for("sign_document", signature_id=signature_id))

        signer = request.form.get("signature_text")
        consent = request.form.get("consent")
        if not consent:
            flash("You must consent to electronic signature before signing.")
            return redirect(url_for("sign_document", signature_id=signature_id))

        import hashlib
        signed_at = datetime.utcnow()
        raw = f"{req.id}|{signer}|{req.signer_email}|{signed_at}|{request.remote_addr}"
        req.status = "Signed"
        req.signed_by = signer
        req.signed_at = signed_at
        req.signature_text = signer
        req.signature_ip = request.remote_addr
        req.signature_hash = hashlib.sha256(raw.encode()).hexdigest()

        log = SignatureAuditLog(
            signature_request_id=req.id,
            event_type="Document Signed",
            event_details=f"Signed by {signer}",
            ip_address=request.remote_addr
        )
        db.session.add(log)
        db.session.commit()
        flash("Document signed successfully.")
        return redirect(url_for("sign_document", signature_id=signature_id))

    logs = SignatureAuditLog.query.filter_by(signature_request_id=signature_id).order_by(SignatureAuditLog.created_at.desc()).all()
    return render_template("sign_document.html", req=req, logs=logs, brand=BRAND)




# SentinelRE Phase 21-24 Routes

def calc_commission(gross, broker_pct, agent_pct, ops_pct, referral_pct):
    gross = float(gross or 0)
    broker = gross * float(broker_pct or 0) / 100
    agent = gross * float(agent_pct or 0) / 100
    ops = gross * float(ops_pct or 0) / 100
    referral = gross * float(referral_pct or 0) / 100
    net = gross - agent - ops - referral
    return broker, agent, ops, referral, net


@app.route("/commissions", methods=["GET", "POST"])
@login_required
def commissions():
    if request.method == "POST":
        gross = float(request.form.get("gross_commission") or 0)
        broker_pct = float(request.form.get("broker_split_percent") or 0)
        agent_pct = float(request.form.get("agent_split_percent") or 0)
        ops_pct = float(request.form.get("operations_split_percent") or 0)
        referral_pct = float(request.form.get("referral_fee_percent") or 0)
        broker, agent, ops, referral, net = calc_commission(gross, broker_pct, agent_pct, ops_pct, referral_pct)

        record = CommissionRecord(
            transaction_id=request.form.get("transaction_id") or None,
            property_id=request.form.get("property_id") or None,
            agent_name=request.form.get("agent_name"),
            broker_name=request.form.get("broker_name"),
            gross_commission=gross,
            broker_amount=broker,
            agent_amount=agent,
            operations_amount=ops,
            referral_amount=referral,
            net_company_revenue=net,
            payout_status=request.form.get("payout_status") or "Pending",
            payout_date=request.form.get("payout_date") or None,
            notes=request.form.get("notes")
        )
        db.session.add(record)
        db.session.commit()
        flash("Commission record created.")
        return redirect(url_for("commissions"))

    records = CommissionRecord.query.order_by(CommissionRecord.created_at.desc()).all()
    total_gross = sum([r.gross_commission or 0 for r in records])
    total_net = sum([r.net_company_revenue or 0 for r in records])
    return render_template("commissions.html", records=records, total_gross=total_gross, total_net=total_net, brand=BRAND)


@app.route("/real-estate-reports", methods=["GET", "POST"])
@login_required
def real_estate_reports():
    if request.method == "POST":
        report = RealEstateReport(
            report_title=request.form.get("report_title"),
            report_type=request.form.get("report_type"),
            related_type=request.form.get("related_type"),
            related_id=request.form.get("related_id") or None,
            report_status=request.form.get("report_status") or "Draft",
            prepared_by=current_user.username,
            executive_summary=request.form.get("executive_summary")
        )
        db.session.add(report)
        db.session.commit()
        flash("Real estate report created.")
        return redirect(url_for("real_estate_reports"))

    reports = RealEstateReport.query.order_by(RealEstateReport.created_at.desc()).all()
    return render_template("real_estate_reports.html", reports=reports, brand=BRAND)


@app.route("/mapping-gis", methods=["GET", "POST"])
@login_required
def mapping_gis():
    if request.method == "POST":
        geo = PropertyGeoProfile(
            property_id=request.form.get("property_id") or None,
            latitude=float(request.form.get("latitude") or 0),
            longitude=float(request.form.get("longitude") or 0),
            neighborhood=request.form.get("neighborhood"),
            market_area=request.form.get("market_area"),
            flood_zone=request.form.get("flood_zone"),
            zoning=request.form.get("zoning"),
            opportunity_zone=bool(request.form.get("opportunity_zone")),
            census_tract=request.form.get("census_tract"),
            traffic_count=request.form.get("traffic_count"),
            walkability_score=float(request.form.get("walkability_score") or 0),
            market_notes=request.form.get("market_notes")
        )
        db.session.add(geo)
        db.session.commit()
        flash("Property geo profile saved.")
        return redirect(url_for("mapping_gis"))

    profiles = PropertyGeoProfile.query.order_by(PropertyGeoProfile.created_at.desc()).all()
    layers = GISLayer.query.filter_by(active=True).all()
    return render_template("mapping_gis.html", profiles=profiles, layers=layers, brand=BRAND)


@app.route("/ai-executive-advisor", methods=["GET", "POST"])
@login_required
def ai_executive_advisor():
    response_summary = None
    if request.method == "POST":
        query_text = request.form.get("query_text")
        category = "Executive Inquiry"
        # Rule-based placeholder until full AI integration is added.
        q = (query_text or "").lower()
        if "risk" in q:
            response_summary = "Review the Property Risk Intelligence dashboard for high and moderate risk properties, then prioritize open risk actions by due date and impact."
            category = "Risk"
        elif "commission" in q or "revenue" in q:
            response_summary = "Review commission records, net company revenue, open transactions, and expected closing dates to estimate short-term revenue."
            category = "Revenue"
        elif "compliance" in q:
            response_summary = "Review Regulatory Readiness, License Compliance, AML, Transaction Governance, and Document Governance queues for overdue or incomplete items."
            category = "Compliance"
        elif "investor" in q:
            response_summary = "Review investor preferences, property matches, and pending investor reports to identify priority follow-up opportunities."
            category = "Investor"
        else:
            response_summary = "Use the Executive Dashboard, Property Risk, Workflow Tasks, and Investor Management screens to identify the next best action."

        query = AIAdvisorQuery(
            user_name=current_user.username,
            query_text=query_text,
            response_summary=response_summary,
            query_category=category,
            confidence_note="Rule-based Phase 21-24 advisor response. Full LLM integration can be added later."
        )
        db.session.add(query)
        db.session.commit()

    queries = AIAdvisorQuery.query.order_by(AIAdvisorQuery.created_at.desc()).limit(10).all()
    insights = AIAdvisorInsight.query.filter(AIAdvisorInsight.status != "Closed").order_by(AIAdvisorInsight.created_at.desc()).all()
    return render_template("ai_executive_advisor.html", queries=queries, insights=insights, response_summary=response_summary, brand=BRAND)




@app.route("/demo-dashboard")
@login_required
def demo_dashboard():
    return render_template(
        "dashboard_demo.html",
        brand=BRAND,
        page_title="SentinelRE Executive Demo Dashboard",
        property_count=4,
        transaction_count=4,
        investor_capacity="70.0M",
        projected_commission="1.19M"
    )



# SentinelRE Phase 25 – E-Signature Legal Hardening & AI Advisor Upgrade Routes

def create_signature_certificate(signature_request):
    import hashlib, uuid
    consent_text = (
        "I consent to use electronic records and electronic signatures. "
        "I understand that typing my name and submitting this form represents my electronic signature."
    )
    cert_number = f"SRE-CERT-{uuid.uuid4().hex[:10].upper()}"
    raw = f"{signature_request.id}|{signature_request.signer_email}|{signature_request.signed_at}|{signature_request.signature_ip}|{signature_request.signature_hash}"
    document_hash = hashlib.sha256(raw.encode()).hexdigest()

    cert = SignatureCertificate(
        signature_request_id=signature_request.id,
        certificate_number=cert_number,
        signer_name=signature_request.signed_by,
        signer_email=signature_request.signer_email,
        signed_at=signature_request.signed_at,
        ip_address=signature_request.signature_ip,
        user_agent=request.headers.get("User-Agent"),
        consent_text=consent_text,
        document_hash=document_hash,
        signature_hash=signature_request.signature_hash
    )
    db.session.add(cert)
    db.session.commit()
    return cert


@app.route("/signature-certificate/<int:signature_id>")
@login_required
def signature_certificate(signature_id):
    req = SignatureRequest.query.get_or_404(signature_id)
    cert = SignatureCertificate.query.filter_by(signature_request_id=signature_id).first()
    logs = SignatureAuditLog.query.filter_by(signature_request_id=signature_id).order_by(SignatureAuditLog.created_at.asc()).all()
    return render_template("signature_certificate.html", req=req, cert=cert, logs=logs, brand=BRAND)


@app.route("/legal-review")
@login_required
def legal_review_queue():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    items = LegalReviewItem.query.order_by(LegalReviewItem.created_at.desc()).all()
    return render_template("legal_review_queue.html", items=items, brand=BRAND)


@app.route("/legal-review/create-defaults", methods=["POST"])
@login_required
def legal_review_create_defaults():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    defaults = [
        ("Attorney review of e-sign consent language", "E-Signature"),
        ("Attorney review of ESIGN/UETA compliance process", "E-Signature"),
        ("Attorney review of real estate contract signature use cases", "Real Estate Legal"),
        ("Attorney review of document retention and audit certificate", "Records Retention"),
        ("Attorney review of identity verification process", "Identity Controls"),
    ]
    for title, item_type in defaults:
        item = LegalReviewItem(item_title=title, item_type=item_type, assigned_to="Broker / Counsel")
        db.session.add(item)
    db.session.commit()
    flash("Legal review checklist created.")
    return redirect(url_for("legal_review_queue"))


@app.route("/signature-email/<int:signature_id>/queue", methods=["POST"])
@login_required
def queue_signature_email(signature_id):
    req = SignatureRequest.query.get_or_404(signature_id)
    delivery = SignatureEmailDelivery(
        signature_request_id=req.id,
        recipient_email=req.signer_email,
        email_subject=f"Signature Requested: {req.document_title}",
        delivery_status="Queued",
        notes="Email delivery foundation created. Connect SMTP/provider before production use."
    )
    db.session.add(delivery)
    db.session.commit()
    flash("Signature email queued. Configure SMTP/provider before sending externally.")
    return redirect(url_for("signature_requests"))


@app.route("/ai-executive-advisor-v2", methods=["GET", "POST"])
@login_required
def ai_executive_advisor_v2():
    response_summary = None
    recommendations = []

    # Gather live platform context where models exist
    property_count = Property.query.count() if "Property" in globals() else 0
    open_risk_actions = PropertyRiskAction.query.filter(PropertyRiskAction.status != "Completed").count() if "PropertyRiskAction" in globals() else 0
    pending_signatures = SignatureRequest.query.filter(SignatureRequest.status != "Signed").count() if "SignatureRequest" in globals() else 0
    open_workflow_tasks = WorkflowTask.query.filter(WorkflowTask.status != "Completed").count() if "WorkflowTask" in globals() else 0
    projected_commission = 0
    if "CommissionRecord" in globals():
        projected_commission = sum([c.gross_commission or 0 for c in CommissionRecord.query.all()])

    if request.method == "POST":
        query_text = request.form.get("query_text")
        q = (query_text or "").lower()

        if "risk" in q:
            response_summary = f"There are {open_risk_actions} open risk actions across {property_count} properties. Prioritize high-risk property actions, document gaps, insurance issues, and title/legal exceptions."
            recommendations.append(("Review High-Risk Properties", "Risk", "High", "Open the Property Risk dashboard and resolve high-priority mitigation tasks."))
        elif "signature" in q or "sign" in q:
            response_summary = f"There are {pending_signatures} pending signature requests. Review unsigned documents and queued email delivery before closing milestones."
            recommendations.append(("Clear Pending Signature Requests", "E-Signature", "High", "Queue reminders for pending signature requests and verify identity controls."))
        elif "workflow" in q or "task" in q:
            response_summary = f"There are {open_workflow_tasks} open workflow tasks. Prioritize tasks tied to closing, probate, investor follow-up, and compliance deadlines."
            recommendations.append(("Prioritize Workflow Queue", "Operations", "Medium", "Assign due dates and owners for open workflow tasks."))
        elif "commission" in q or "revenue" in q:
            response_summary = f"Projected gross commission in the system is approximately ${projected_commission:,.2f}. Review payout status and expected close dates."
            recommendations.append(("Review Commission Forecast", "Revenue", "Medium", "Confirm projected commissions and deal close probabilities."))
        else:
            response_summary = (
                f"Current platform snapshot: {property_count} properties, {open_risk_actions} open risk actions, "
                f"{pending_signatures} pending signatures, {open_workflow_tasks} open workflow tasks, and "
                f"${projected_commission:,.2f} projected gross commission."
            )
            recommendations.append(("Review Executive Dashboard", "Executive", "Medium", "Start with risk, signatures, workflow tasks, and commission forecast."))

        query = AIAdvisorQuery(
            user_name=current_user.username,
            query_text=query_text,
            response_summary=response_summary,
            query_category="Context-Aware Advisor",
            confidence_note="Phase 25 context-aware advisor. It uses live database counts and rule-based reasoning; external LLM integration can be added later."
        )
        db.session.add(query)
        db.session.commit()

        import json
        snapshot = AIAdvisorContextSnapshot(
            query_id=query.id,
            snapshot_title="Live SentinelRE Context Snapshot",
            property_count=property_count,
            open_risk_actions=open_risk_actions,
            pending_signatures=pending_signatures,
            open_workflow_tasks=open_workflow_tasks,
            projected_commission=projected_commission,
            snapshot_json=json.dumps({
                "property_count": property_count,
                "open_risk_actions": open_risk_actions,
                "pending_signatures": pending_signatures,
                "open_workflow_tasks": open_workflow_tasks,
                "projected_commission": projected_commission
            })
        )
        db.session.add(snapshot)

        for title, rtype, priority, text in recommendations:
            rec = AIAdvisorRecommendation(
                query_id=query.id,
                recommendation_title=title,
                recommendation_type=rtype,
                priority=priority,
                recommendation_text=text
            )
            db.session.add(rec)

        db.session.commit()

    recent_queries = AIAdvisorQuery.query.order_by(AIAdvisorQuery.created_at.desc()).limit(10).all()
    recent_recs = AIAdvisorRecommendation.query.order_by(AIAdvisorRecommendation.created_at.desc()).limit(10).all()
    return render_template(
        "ai_executive_advisor_v2.html",
        response_summary=response_summary,
        recent_queries=recent_queries,
        recent_recs=recent_recs,
        property_count=property_count,
        open_risk_actions=open_risk_actions,
        pending_signatures=pending_signatures,
        open_workflow_tasks=open_workflow_tasks,
        projected_commission=projected_commission,
        brand=BRAND
    )




# SentinelRE Phase 26 – Interactive GIS Map Routes

@app.route("/gis-map")
@login_required
def gis_map():
    profiles = PropertyGeoProfile.query.order_by(PropertyGeoProfile.created_at.desc()).all() if "PropertyGeoProfile" in globals() else []
    markers = []
    for p in profiles:
        if p.latitude and p.longitude:
            markers.append({
                "property_id": p.property_id,
                "latitude": p.latitude,
                "longitude": p.longitude,
                "market_area": p.market_area or "",
                "neighborhood": p.neighborhood or "",
                "zoning": p.zoning or "",
                "flood_zone": p.flood_zone or "",
                "opportunity_zone": bool(p.opportunity_zone),
                "walkability_score": p.walkability_score or 0,
                "market_notes": p.market_notes or ""
            })
    return render_template("gis_map.html", markers=markers, brand=BRAND, page_title="Interactive GIS Map")


@app.route("/gis-map-data")
@login_required
def gis_map_data():
    profiles = PropertyGeoProfile.query.order_by(PropertyGeoProfile.created_at.desc()).all() if "PropertyGeoProfile" in globals() else []
    data = []
    for p in profiles:
        if p.latitude and p.longitude:
            data.append({
                "property_id": p.property_id,
                "latitude": p.latitude,
                "longitude": p.longitude,
                "market_area": p.market_area or "",
                "neighborhood": p.neighborhood or "",
                "zoning": p.zoning or "",
                "flood_zone": p.flood_zone or "",
                "opportunity_zone": bool(p.opportunity_zone),
                "walkability_score": p.walkability_score or 0,
                "market_notes": p.market_notes or ""
            })
    return {"markers": data}


@app.route("/gis-overlays", methods=["GET", "POST"])
@login_required
def gis_overlays():
    if request.method == "POST":
        overlay = MarketOverlay(
            overlay_name=request.form.get("overlay_name"),
            overlay_type=request.form.get("overlay_type"),
            market_area=request.form.get("market_area"),
            layer_color=request.form.get("layer_color"),
            risk_level=request.form.get("risk_level"),
            notes=request.form.get("notes"),
            active=True
        )
        db.session.add(overlay)
        db.session.commit()
        flash("Market overlay created.")
        return redirect(url_for("gis_overlays"))

    overlays = MarketOverlay.query.order_by(MarketOverlay.created_at.desc()).all()
    return render_template("gis_overlays.html", overlays=overlays, brand=BRAND, page_title="GIS Overlays")



# SentinelRE Critical Fixes – Route Aliases and Properties

@app.route("/properties", methods=["GET", "POST"])
@login_required
def properties():
    if request.method == "POST":
        prop = Property(
            property_name=request.form.get("property_name"),
            property_type=request.form.get("property_type"),
            address=request.form.get("address"),
            city=request.form.get("city"),
            state=request.form.get("state"),
            zip_code=request.form.get("zip_code"),
            county=request.form.get("county"),
            owner_name=request.form.get("owner_name"),
            broker_owner=current_user.username if current_user.is_authenticated else None,
            assigned_agent=request.form.get("assigned_agent"),
            operations_owner=request.form.get("operations_owner"),
            square_feet=float(request.form.get("square_feet") or 0),
            units=int(request.form.get("units") or 0),
            acreage=float(request.form.get("acreage") or 0),
            year_built=int(request.form.get("year_built") or 0),
            occupancy_rate=float(request.form.get("occupancy_rate") or 0),
            purchase_price=float(request.form.get("purchase_price") or 0),
            estimated_value=float(request.form.get("estimated_value") or 0),
            noi=float(request.form.get("noi") or 0),
            cap_rate=float(request.form.get("cap_rate") or 0),
            notes=request.form.get("notes")
        )
        db.session.add(prop)
        db.session.commit()
        flash("Property record created.")
        return redirect(url_for("properties"))

    property_list = Property.query.order_by(Property.created_at.desc()).all()
    return render_template("properties.html", properties=property_list, brand=BRAND, page_title="Property Command Center")


@app.route("/aml-governance")
@login_required
def aml_governance():
    return redirect(url_for("aml_transaction_governance"))




# SentinelRE Phase 27-30 Routes – Production Readiness

@app.route("/deployment-validation")
@login_required
def deployment_validation():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    results = RouteValidationResult.query.order_by(RouteValidationResult.tested_at.desc()).limit(50).all()
    return render_template("deployment_validation.html", results=results, brand=BRAND, page_title="Deployment Validation")


@app.route("/legal-readiness")
@login_required
def legal_readiness():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    controls = ESignComplianceControl.query.order_by(ESignComplianceControl.control_area.asc()).all()
    templates = LegalTemplateReview.query.order_by(LegalTemplateReview.created_at.desc()).all()
    return render_template("legal_readiness.html", controls=controls, templates=templates, brand=BRAND, page_title="Legal Readiness")


@app.route("/client-portal-security")
@login_required
def client_portal_security():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    policies = PortalAccessPolicy.query.order_by(PortalAccessPolicy.created_at.desc()).all()
    challenges = PortalMFAChallenge.query.order_by(PortalMFAChallenge.created_at.desc()).limit(25).all()
    tokens = SecureDocumentToken.query.order_by(SecureDocumentToken.created_at.desc()).limit(25).all()
    return render_template("client_portal_security.html", policies=policies, challenges=challenges, tokens=tokens, brand=BRAND, page_title="Client Portal Security")


@app.route("/ai-governance")
@login_required
def ai_governance():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)
    rules = AIDataClassificationRule.query.order_by(AIDataClassificationRule.classification.asc()).all()
    settings = AIGovernanceSetting.query.order_by(AIGovernanceSetting.setting_name.asc()).all()
    audits = AIPromptAuditLog.query.order_by(AIPromptAuditLog.created_at.desc()).limit(25).all()
    return render_template("ai_governance.html", rules=rules, settings=settings, audits=audits, brand=BRAND, page_title="AI Governance")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
