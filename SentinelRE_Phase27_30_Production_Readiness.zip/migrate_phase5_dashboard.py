"""SentinelOps Phase 5 migration: proposal approval fields for Executive KPI Dashboard.
Run from app folder: python migrate_phase5_dashboard.py
Safe to run multiple times.
"""
import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "sentinelops.db"
COLUMNS = [
    ("approval_status", "VARCHAR(100) DEFAULT 'Draft'"),
    ("executive_approval_required", "BOOLEAN DEFAULT 1"),
    ("approved_by", "VARCHAR(120)"),
    ("approved_at", "DATETIME"),
    ("approval_notes", "TEXT"),
    ("pricing_locked", "BOOLEAN DEFAULT 0"),
    ("pricing_set_by", "VARCHAR(120)"),
    ("pricing_set_at", "DATETIME"),
    ("sent_by", "VARCHAR(120)"),
    ("sent_at", "DATETIME"),
]

with sqlite3.connect(DB) as conn:
    existing = {row[1] for row in conn.execute("PRAGMA table_info(proposal)")}
    for name, ddl in COLUMNS:
        if name not in existing:
            conn.execute(f"ALTER TABLE proposal ADD COLUMN {name} {ddl}")
            print(f"Added: {name}")
        else:
            print(f"Exists: {name}")
    conn.commit()
print("Phase 5 migration complete.")
