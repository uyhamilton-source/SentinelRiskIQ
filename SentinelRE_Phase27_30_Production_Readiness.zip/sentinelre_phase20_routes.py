
# SentinelRE Phase 20 – Client Portal & E-Signature Routes

@app.route("/client-portal")
def client_portal_login():
    return render_template("client_portal_login.html", brand=BRAND)


@app.route("/client-portal/dashboard")
@login_required
def client_portal_dashboard():
    # Internal preview route for broker/admin testing. Production portal auth should use a separate portal session.
    messages = []
    signatures = SignatureRequest.query.order_by(SignatureRequest.requested_at.desc()).limit(10).all()
    return render_template("client_portal_dashboard.html", messages=messages, signatures=signatures, brand=BRAND)


@app.route("/portal-users", methods=["GET", "POST"])
@login_required
def portal_users():
    if current_user.role not in ["Owner/Broker", "Administrator"]:
        abort(403)

    if request.method == "POST":
        username = request.form.get("username")
        temp_password = request.form.get("temp_password") or "ClientTemp2026!"
        portal_user = PortalUser(
            username=username,
            email=request.form.get("email"),
            client_name=request.form.get("client_name"),
            role=request.form.get("role") or "Client",
            investor_id=request.form.get("investor_id") or None,
            property_id=request.form.get("property_id") or None,
            active=True,
            access_approved=bool(request.form.get("access_approved"))
        )
        portal_user.set_password(temp_password)
        db.session.add(portal_user)
        db.session.commit()
        flash("Portal user created.")
        return redirect(url_for("portal_users"))

    users = PortalUser.query.order_by(PortalUser.created_at.desc()).all()
    return render_template("portal_users.html", users=users, brand=BRAND)


@app.route("/signature-requests", methods=["GET", "POST"])
@login_required
def signature_requests():
    if request.method == "POST":
        req = SignatureRequest(
            related_type=request.form.get("related_type"),
            related_id=request.form.get("related_id") or None,
            signer_name=request.form.get("signer_name"),
            signer_email=request.form.get("signer_email"),
            document_title=request.form.get("document_title"),
            document_type=request.form.get("document_type"),
            file_path=request.form.get("file_path"),
            requested_by=current_user.username,
            notes=request.form.get("notes")
        )
        db.session.add(req)
        db.session.commit()
        log = SignatureAuditLog(
            signature_request_id=req.id,
            event_type="Signature Requested",
            event_details=f"Signature requested for {req.document_title}",
            ip_address=request.remote_addr
        )
        db.session.add(log)
        db.session.commit()
        flash("Signature request created.")
        return redirect(url_for("signature_requests"))

    requests = SignatureRequest.query.order_by(SignatureRequest.requested_at.desc()).all()
    return render_template("signature_requests.html", requests=requests, brand=BRAND)


@app.route("/sign/<int:signature_id>", methods=["GET", "POST"])
def sign_document(signature_id):
    req = SignatureRequest.query.get_or_404(signature_id)

    if request.method == "POST":
        if req.status == "Signed":
            flash("This document has already been signed.")
            return redirect(url_for("sign_document", signature_id=signature_id))

        signer = request.form.get("signature_text")
        consent = request.form.get("consent")
        if not consent:
            flash("You must consent to electronic signature before signing.")
            return redirect(url_for("sign_document", signature_id=signature_id))

        import hashlib
        signed_at = datetime.utcnow()
        raw = f"{req.id}|{signer}|{req.signer_email}|{signed_at}|{request.remote_addr}"
        req.status = "Signed"
        req.signed_by = signer
        req.signed_at = signed_at
        req.signature_text = signer
        req.signature_ip = request.remote_addr
        req.signature_hash = hashlib.sha256(raw.encode()).hexdigest()

        log = SignatureAuditLog(
            signature_request_id=req.id,
            event_type="Document Signed",
            event_details=f"Signed by {signer}",
            ip_address=request.remote_addr
        )
        db.session.add(log)
        db.session.commit()
        flash("Document signed successfully.")
        return redirect(url_for("sign_document", signature_id=signature_id))

    logs = SignatureAuditLog.query.filter_by(signature_request_id=signature_id).order_by(SignatureAuditLog.created_at.desc()).all()
    return render_template("sign_document.html", req=req, logs=logs, brand=BRAND)
