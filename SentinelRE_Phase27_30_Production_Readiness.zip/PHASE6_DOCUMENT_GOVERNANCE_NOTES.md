# SentinelRE Phase 6 – Document Governance Engine™

This build adds a broker-controlled real estate document vault.

## Added

- Document model
- DocumentVersion model
- DocumentAccessLog model
- DocumentCategory model
- Document Vault UI
- File upload/download
- Broker approval workflow
- Archive/disable workflow
- Role-based document permissions
- Audit logging for upload, download, approve, archive, and disable
- Document categories for real estate, CRE, probate, and transaction files

## Role Design

### Owner (Broker)
Can upload, download, approve, archive, disable, administer documents.

### Operations Coordinator
Can upload, organize, view, and download documents.

### Realtor / Agent
Can upload, view, and download permitted documents.

## Deployment

1. Upload files to server.
2. Install dependencies from requirements.txt if needed.
3. Run:

```bash
python migrate_phase6_documents.py
sudo systemctl restart sentinelre
```

If using a different service name, restart the correct Gunicorn/systemd service.

## Upload Folder

Documents are stored by default in:

```text
uploads/documents
```

Override with:

```text
DOCUMENT_UPLOAD_FOLDER=/secure/path
```

## Security Notes

- Files are not served directly by Nginx.
- Downloads go through Flask permission checks.
- Broker approval is required for formal document governance.
- Disabled documents are removed from active vault but retained for audit evidence.
