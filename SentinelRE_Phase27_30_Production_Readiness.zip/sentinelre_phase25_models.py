
# SentinelRE Phase 25 – E-Signature Legal Hardening & AI Advisor Upgrade Models

class SignatureCertificate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signature_request_id = db.Column(db.Integer, db.ForeignKey("signature_request.id"))
    certificate_number = db.Column(db.String(120))
    signer_name = db.Column(db.String(255))
    signer_email = db.Column(db.String(255))
    signed_at = db.Column(db.DateTime)
    ip_address = db.Column(db.String(100))
    user_agent = db.Column(db.Text)
    consent_text = db.Column(db.Text)
    document_hash = db.Column(db.String(255))
    signature_hash = db.Column(db.String(255))
    certificate_path = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SignatureIdentityVerification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signature_request_id = db.Column(db.Integer, db.ForeignKey("signature_request.id"))
    verification_method = db.Column(db.String(120))
    signer_email = db.Column(db.String(255))
    verification_code = db.Column(db.String(120))
    verified = db.Column(db.Boolean, default=False)
    verified_at = db.Column(db.DateTime)
    ip_address = db.Column(db.String(100))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SignatureEmailDelivery(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    signature_request_id = db.Column(db.Integer, db.ForeignKey("signature_request.id"))
    recipient_email = db.Column(db.String(255))
    email_subject = db.Column(db.String(255))
    delivery_status = db.Column(db.String(100), default="Queued")
    sent_at = db.Column(db.DateTime)
    opened_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class LegalReviewItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    item_title = db.Column(db.String(255))
    item_type = db.Column(db.String(120))
    status = db.Column(db.String(100), default="Attorney Review Needed")
    assigned_to = db.Column(db.String(120))
    reviewed_by = db.Column(db.String(120))
    reviewed_at = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorSource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    source_name = db.Column(db.String(255))
    source_type = db.Column(db.String(120))
    source_table = db.Column(db.String(120))
    source_description = db.Column(db.Text)
    enabled = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorContextSnapshot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    query_id = db.Column(db.Integer)
    snapshot_title = db.Column(db.String(255))
    property_count = db.Column(db.Integer, default=0)
    open_risk_actions = db.Column(db.Integer, default=0)
    pending_signatures = db.Column(db.Integer, default=0)
    open_workflow_tasks = db.Column(db.Integer, default=0)
    projected_commission = db.Column(db.Float, default=0)
    compliance_items_open = db.Column(db.Integer, default=0)
    snapshot_json = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class AIAdvisorRecommendation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    query_id = db.Column(db.Integer)
    recommendation_title = db.Column(db.String(255))
    recommendation_type = db.Column(db.String(120))
    priority = db.Column(db.String(50))
    related_type = db.Column(db.String(120))
    related_id = db.Column(db.Integer)
    recommendation_text = db.Column(db.Text)
    status = db.Column(db.String(100), default="Open")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
